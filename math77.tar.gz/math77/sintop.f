      SUBROUTINE SINTOP (IOPT,WORK)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C     SUBROUTINE $L1$INTOP (IOPT,WORK)
C>> 1992-03-03 SINTOP  Krogh added error messages.
C>> 1991-09-20 SINTOP  Krogh converted '(1)' dimensioning to '(*)'.
C>> 1987-12-07 SINTOP Snyder  Initial code.
C
C     ******************************************************************00001100
C
C     THIS SUBROUTINE IS USED TO SPECIFY OPTIONS FOR $L1$INT.
C     IT IS CALLED BY $L1$INT AND $L1$INTM.  IT MAY ALSO BE CALLED
C     BY THE USER DURING THE INTEGRATION TO CHANGE A RESTRICTED
C     SET OF THE OPTIONS.  IF IT IS CALLED WITH NFEVAL = 0, IT IS
C     ASSUMED THAT THE CALL CAME FROM $L1$INT OR $L1$INTM.  IN
C     THIS CASE, ALL OPTIONS ARE FIRST SET TO THEIR DEFAULT VALUES.
C     IF IT IS CALLED WITH NFEVAL .NE. 0, IT IS ASSUMED THAT THE
C     CALL CAME DIRECTLY FROM THE USER.  IN THIS CASE, ONLY A SUBSET
C     OF THE OPTIONS MAY BE CHANGED.  THE OPTIONS THAT MAY BE CHANGED   00002100
C     DO NOT REFER TO THE WORK VECTOR.  THUS WORK IS IN THIS CASE A
C     DUMMY ARGUMENT.  THE OPTIONS THAT MAY BE CHANGED CORRESPOND TO
C     NON-ZERO ELEMENTS OF THE VECTOR ICHG.
C     SEE $L1$INT OR $L1$INTM FOR A DESCRIPTION OF THE OPTIONS.
C
C     *****    SPECIALIZER VARIABLES     *******************************
C
C $   .MACH.=CONVAL($.MACH.$)='U1100'$
C $   .IMP.=CONVAL($L1$)='S'$
C $   PORT=CONVAL($PORT$)=.T.$                                          00003100
C $   F77=CONVAL($F77$)=.T.$
C     EQXRNG MEANS REAL AND DOUBLE HAVE ALMOST EQUAL EXPONENT RANGE
C     AND ADVANTAGE IS TO BE TAKEN OF THIS FACT.
C $   EQXRNG=CONVAL($IF((.SINF..GT.0.25*.DINF.).AND.(.NOT.PORT)).T.$
C $  1  .F.$)=.F.$
C $   DSTYP=CONVAL($IF(L1.EQ.'S'.OR.EQXRNG).STYPE.$.DTYPE.$)=
C $  1'REAL'$
C $   L4=CONVAL($IF(DSTYP.EQ..DTYPE.)'D'$'E'$)='E'$
C $   DE=CONVAL($IF(L1.EQ.'S')'E'$'D'$)='E'$
C $   NOMOUT=CONVAL($NOMOUT$IF(PORT)'I1MACH(2)'$.NOUT.$)='I1MACH(2)'$   00004100
C $   FERF=CONVAL($IF(L1.EQ.'S')1.E0$8.D0$)=1.0E0$
C $   FERVAL=CONVAL($IF(PORT)'EFERVL'$VALR(FERF*.EPS.,4)$)='EFERVL'$
C $*  SMALL=CONVAL($IF(PORT)'ESMALL'$VALR(2/.*D4*INF.,4)$)='ESMALL'$
C $   DELM1=CONVAL($IF(PORT)'EDELM1'$VALR(1/(.INF.*.EPS.),4)$=
C $  1'EDELM1'$
C     3.951E-2 IS THE NORMALIZED DISTANCE FROM THE END OF THE INTERVAL
C     TO THE ABSCISSA OF THE 7-POINT FORMULA NEAREST THE END.
C $   DELM2=CONVAL($IF(PORT)'EDELM2'$VALR(8/3.951E-2,4)='EDELM2'$
C $   MEPS=CONVAL($IF(PORT)'EMEPS'$VALR(.EPS.,5)$)='EMEPS'$
C $   DMEPS=CONVAL($IF(PORT)'EDMEPS'$VALR(0.5*.DEPS.,4)$)='EDMEPS'$     00005100
C $   EPSM8=CONVAL($IF(PORT)'EEPSM8'$VALR(8*.EPS.,5)$)='EEPSM8'$
C $   MEPSX=CONVAL($IF(PORT)'EMEPSX'$VALR(1.01*.EPS.,5)$)='EMEPSX'$
C $   SQEPS=CONVAL($IF(PORT)'ESQEPS'$VALR(SQRT(.EPS.),5)$)='ESQEPS'$
C $   RSQEP=CONVAL($IF(PORT)'ERSQEP'$VALR(1/SQRT(.EPS.),4)$)='ERSQEP'$
C $   RSQE6=CONVAL($IF(PORT)'ERSQE6'$VALR(1/SQRT(1.E6*.EPS.,4)$)=
C $  1'ERSQE6'$
C $   SQ2EP=CONVAL($IF(PORT)'ESQ2EP'$VALR(1/SQRT(SQRT(.EPS.)),4)$)=
C $  1'ESQ2EP'$
C $   MINF=CONVAL($IF(PORT)'EMINF'$VALR(.INF.,4)$)='EMINF'$
C $*  NZER=CONVAL($IF(PORT)'ENZER'$VALR(100/.*D4*INF.,4)$)='ENZER'$     00006100
C $/  NINF=CONVAL($IF(PORT)'ENINF'$VALR(1.0E-3*./DR/INF.,4)$)=
C $/ 1'ENINF'$
C $   SHORTA=CONVAL($IF((.NOT.PORT).AND.(.IRADIX..EQ.2)).T.$.F.$)=.F.$
C
C     *****     FORMAL ARGUMENTS     ***********************************
C
C IOPT    IS THE OPTION VECTOR (SEE $L1$INT OR $L1$INTM).
      INTEGER IOPT(*)
C WORK    IS THE WORK VECTOR (SEE $L1$INT OR $L1$INTM).
C     $.TYPE.$ WORK(*)                                                  00007100
      REAL WORK(*)
C
C     *****     EXTERNAL REFERENCES     ********************************
C
C $   COL1(PORT)
C.D1MACH  FETCHES DOUBLE PRECISION MACHINE PARAMETERS.
      DOUBLE PRECISION D1MACH
C.I1MACH  FETCHES INTEGER MACHINE PARAMETERS.
      INTEGER I1MACH
C.R1MACH  FETCHES REAL MACHINE PARAMETERS.                              00008100
C $   COL1(PORT .AND. (L1.EQ.'S'),1)
      REAL R1MACH
C
C     *****    LOCAL VARIABLES     *************************************
C
C ICHG    A VECTOR DEFINING WHICH OPTIONS MAY BE CHANGED WHEN NFEVAL
C         IS NON-ZERO.
      INTEGER ICHG(13)
C II JJ   INDICES.
C NOMOUT  THE NOMINAL OUTPUT UNIT.                                      00009100
C
C     *****    COMMON STORAGE ******************************************
C
C     COMMON /$L1$INTNC/ CONTAINS VARIABLES NOT SEPARATELY SAVED FOR
C     EACH DIMENSION OF A MULTIPLE QUADRATURE.  COMMON /$L1$INTC/
C     CONTAINS VARIABLES THAT MUST BE SAVED FOR EACH DIMENSION OF THE
C     QUADRATURE.  THE VARIABLES IN EACH COMMON BLOCK ARE STORED IN THE
C     ORDER - ALWAYS DOUBLE, DOUBLE IF DOUBLE PRECISION PROGRAM, DOUBLE
C     IF DOUBLE PRECISION PROGRAM AND EXPONENT RANGE OF DOUBLE AND
C     SINGLE VERY DIFFERENT, SINGLE, INTEGER, LOGICAL.  A PAD OF LOGICAL00009500
C     VARIABLES IS INCLUDED AT THE END OF /$L1$INTC/.  THE DIMENSION OF
C     THE PAD MAY NEED TO BE VARIED SO THAT NO VARIABLES BEYOND THE END
C     OF THE COMMON BLOCK ARE ALTERED.
C
C     DECLARATIONS OF COMMON /$L1$INTNC/ VARIABLES.
C
C     $.TYPE.$ AINIT, BINIT, FNCVAL, S, TP
      REAL             AINIT, BINIT, FNCVAL, S, TP
C     $DSTYP$  FER, FER1, RELOBT, TPS, XJ, XJP
      REAL             FER, FER1, RELOBT, TPS, XJ, XJP                  00009500
      INTEGER     FEA,       FEA1,      INC,       INC2,      IPRINT,   
     * ISTOP(2,2),JPRINT,    KDIM,      KK,        KMAXF,     NDIM,     
     * NFINDX,    NFMAX,     NFMAXM,    OUT,       RELTOL,    REVERM,   
     * REVERS,    WHEREM
      LOGICAL NEEDH
C
C     DECLARATIONS OF COMMON /$L1$INTC/ VARIABLES.
C
C     4 DOUBLE PRECISION VARIABLES
      DOUBLE PRECISION ACUM, PACUM, RESULT(2)
C     139 $.TYPE.$ VARIABLES
C     $.TYPE.$
      REAL                                                              00009500
     * AACUM,     ABSCIS,    DELMIN,    DELTA,     DIFF,      DISCX(2), 
     * END(2),    ERRINA,    ERRINB,    FAT(2),    FSAVE,     FT(17),   
     * FUNCT(24), F1,        F2,        LOCAL(4),  PAACUM,    PF1,      
     * PF2,       PHI(34),   PHISUM,    PHTSUM,    PX,        SPACE(6), 
     * STEP(2),   START(2),  SUM,       T,         TA,        TASAVE,   
     * TB,        TEND,      WORRY(2),  X,         XT(17),    X1,       
     * X2
C     29 $DSTYP$ VARIABLES
C     $DSTYP$
      REAL                                                              
     * ABSDIF,    EDUE2A,    EDUE2B,    EP,        EPNOIZ,    EPS,      
     * EPSMAX,    EPSMIN,    EPSO,      EPSR,      EPSS,      ERR,      
     * ERRAT(2),  ERRC,      ERRF,      ERRI,      ERRT(2),   ESOLD,    
     * EXTRA,     PEPSMN,    RE,        RELEPS,    REP,       REPROD,   
     * RNDC,      TLEN,      XJUMP
C     1 REAL VARIABLE
      REAL        COUNT
C     29 INTEGER VARIABLES
      INTEGER     DISCF,     DISCHK,    ENDPTS,    I,         INEW,     
     * IOLD,      IP,        IXKDIM,    J,         J1,        J1OLD,    
     * J2,        J2OLD,     K,         KAIMT,     KMAX,      KMIN,     
     * L,         LENDT,     NFEVAL,    NFJUMP,    NSUB,      NSUBSV,   
     * NXKDIM,    PART,      SEARCH,    TALOC,     WHERE,     WHERE2
C     11 TO 18 LOGICALS (7 ARE PADDING).
      LOGICAL     DID1,      FAIL,      FATS(2),   FSAVED,    HAVDIF,   
     * IEND,      INIT,      ROUNDF,    XCDOBT(2), PAD(7)
C                                                                       00009500
C     THE COMMON BLOCKS.
C
C     COMMON /$L1$INTNC/
      COMMON /SINTNC/                                                   
     * AINIT,  BINIT,  FNCVAL, S,      TP,     FER,    FER1,   RELOBT,  
     * TPS,    XJ,     XJP,    FEA,    FEA1,   INC,    INC2,   IPRINT,  
     * ISTOP,  JPRINT, KDIM,   KK,     KMAXF,  NDIM,   NFINDX, NFMAX,   
     * NFMAXM, OUT,    RELTOL, REVERM, REVERS, WHEREM, NEEDH
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * ACUM,   PACUM,  RESULT
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * AACUM,  ABSCIS, DELMIN, DELTA,  DIFF,   DISCX,  END,    ERRINA,  
     * ERRINB, FAT,    FSAVE,  FT,     FUNCT,  F1,     F2,     LOCAL,   
     * PAACUM, PF1,    PF2,    PHI,    PHISUM, PHTSUM, PX,     SPACE,   
     * STEP,   START,  SUM,    T,      TA,     TASAVE, TB,     TEND,    
     * WORRY,  X,      XT,     X1,     X2
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    00009500
     * ABSDIF, EDUE2A, EDUE2B, EP,     EPNOIZ, EPS,    EPSMAX, EPSMIN,  
     * EPSO,   EPSR,   EPSS,   ERR,    ERRAT,  ERRC,   ERRF,   ERRI,    
     * ERRT,   ESOLD,  EXTRA,  PEPSMN, RE,     RELEPS, REP,    REPROD,  
     * RNDC,   TLEN,   XJUMP
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * COUNT
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * DISCF,  DISCHK, ENDPTS, I,      INEW,   IOLD,   IP,     IXKDIM,  
     * J,      J1,     J1OLD,  J2,     J2OLD,  K,      KAIMT,  KMAX,    
     * KMIN,   L,      LENDT,  NFEVAL, NFJUMP, NSUB,   NSUBSV, NXKDIM,  
     * PART,   SEARCH, TALOC,  WHERE,  WHERE2
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * DID1,   FAIL,   FATS,   FSAVED, HAVDIF, IEND,   INIT,   ROUNDF,  
     * XCDOBT, PAD
C     SAVE /$L1$INTNC/, /$L1$INTC/
      SAVE /SINTNC/, /SINTC/
C
C $   COL1(PORT)                                                        00009700
C.    THE VARIABLES HERE DEFINE THE MACHINE ENVIRONMENT.  ALL ARE SET
C.    IN $L1$INTOP.  THE MEANING ATTACHED TO THESE VARIABLES CAN BE
C.    FOUND BY LOOKING AT THE RELATED SPECIALIZER VARIABLES DEFINED IN
C.    $L1$INTOP.
      DOUBLE PRECISION EDMEPS
C     $.TYPE.$
      REAL                                                              
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     COMMON /$L1$INTEC/
      COMMON /SINTEC/                                                   
     *  EDMEPS,                                                         
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     SAVE /$L1$INTEC/                                                  00009700
      SAVE /SINTEC/
C $   COL1(PORT, 0)
C
C     *****    Statements for Processing Messages **********************
C
      PARAMETER (MENTXT =23)
      PARAMETER (MEMDA1 =27)
      PARAMETER (MEMDA2 =28)
      PARAMETER (MERET  =51)
      PARAMETER (MEEMES =52)                                            00010500
      PARAMETER (MEIVEC =57)
      INTEGER MACT(11)
      character MTEXT(125)
      parameter (LTXTAA = 1)
      character MTXTAA*(6)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 7)
      character MTXTAB*(55)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      parameter (LTXTAC = 62)                                           00011500
      character MTXTAC*(64)
      equivalence (MTEXT(LTXTAC), MTXTAC)
C                      1 2      3  4      5  6 7 8      9 10   11
      DATA MACT / MEMDA1,0,MEMDA2, 0,MEEMES,77,4,0,MEIVEC,0,MERET /
      DATA MTXTAA/'SINT$B'/,                                            
     *MTXTAB/'Last value is IOPT specfies bad option, IOPT(1:$M) = $B'/,
     *MTXTAC/                                                           
     *'Option $M, can not be changed while integrating, IOPT(1:$M) = $B'
     */
C
C     *****    DATA STATEMENTS   ***************************************
C
C     NOTE - THE FOLLOWING ARRAY DATA STATEMENT MAY NOT BE PORTABLE.
      DATA ICHG /1,1,0,0,0,1,1,1,1,0,1,1,0/                             00012900
C
C     *****    PROCEDURES     ******************************************
C
C
C     SET OPTIONS TO DEFAULT VALUES.
C
      IOPT(1)=0
      IF(NFEVAL.EQ.0)THEN
C        OUT=$NOMOUT$
         OUT=I1MACH(2)                                                  00014000
C $      COL1(PORT .AND. (L1 .EQ. 'S'))
         EMEPS = R1MACH(4)
         EDMEPS = 0.5D0 * D1MACH(4)
         EFERVL = EMEPS
         EEPSM8 = 8.E0 * EMEPS
         EMEPSX = 1.01E0 * EMEPS
         EDELM2 = 202.48E0
         ESQEPS = SQRT(EMEPS)
         ERSQEP = 1.0E0 / ESQEPS
         ERSQE6 = 1.0E-3 * ERSQEP                                       00015000
         ESQ2EP = SQRT(ERSQEP)
         EMINF = R1MACH(2)
         ESMALL = 2.0D0*R1MACH(1)
         IF (EMINF * ESMALL .LT. 2.0E0) ESMALL = 2.0E0/EMINF
         ENZER = 50.E0 * ESMALL
         EDELM1 = ESMALL / EMEPS
         ENINF = 1.0E-3 * EMINF
C $      COL1(PORT .AND. (L1 .EQ. 'D'))
C        EMEPS = D1MACH(4)
C        EDMEPS = 0.5D0 * EMEPS                                         00016000
C        EFERVL = 8.D0 * EMEPS
C        EEPSM8 = EFERVL
C        EMEPSX = 1.01D0 * EMEPS
C        EDELM2 = 202.48D0
C        ESQEPS = DSQRT(EMEPS)
C        ERSQEP = 1.0D0 / ESQEPS
C        ERSQE6 = 1.0D-3 * ERSQEP
C        ESQ2EP = DSQRT(ERSQEP)
C        EMINF = D1MACH(2)
C        ESMALL = 2.D0*MAX(D1MACH(1),1.0D0/EMINF)                       00017000
C        ENZER = 50.D0 * ESMALL
C        EDELM1 = ESMALL / EMEPS
C        ENINF = 1.0D-3 * EMINF
C $      COL1(PORT, 0)
         EPSO=0.0
         ERRINA=0.0
         ERRINB=0.0
         FEA=0
C        FER=$FERVAL$
         FER=EFERVL                                                     00018000
         KMAXF=3
         NFINDX=0
C        RELOBT=0.75$DE$0
         RELOBT=0.75E0
         RELTOL=0
         TALOC=0
      IF(NDIM.NE.1)THEN
            JPRINT=0
            DO 10 II=1,NDIM
10             JPRINT=10*JPRINT+1                                       00019000
            REVERM=0
            NFMAXM=0
            IXKDIM=1
      ELSE
            IPRINT=1
            REVERS=0
            NFMAX=0
      END IF
      END IF
C                                                                       00020000
C     SET OPTIONS SPECIFIED IN THE OPTION VECTOR.
C
      II=2
20007 CONTINUE
         JJ=IOPT(II)
      IF (JJ.EQ.0) GO TO 20008
      IF(JJ.LT.0 .OR. JJ.GT.13)THEN
            MACT(2) = II
            MACT(8) = LTXTAB
      GO TO 20006                                                       00021100
      END IF
      IF(NFEVAL.NE.0)THEN
      IF(ICHG(JJ).EQ.0)THEN
               MACT(2) = JJ
               MACT(4) = II
               MACT(8) = LTXTAC
      GO TO 20006
      END IF
      END IF
      GO TO (20017,20018,20019,20020,20021,20022,20023,20024,20025,2002600022100
     *,20027,20028,20029), JJ
      GO TO 20016
c               No longer used.
20017 GO TO 20016
20018 IF(NDIM.EQ.1)THEN
               IPRINT=IOPT(II+1)
      ELSE
               JPRINT=IOPT(II+1)
               IF (NFEVAL.NE.0) IPRINT=MOD(JPRINT/10**(KDIM-1),10)
      END IF
      GO TO 20016
20019       RELTOL=IOPT(II+1)                                           00023200
            EPSO=WORK(RELTOL)
C           RELOBT=1.0$DE$0-MAX(0.0$DE$0,MIN(1.0$DE$0,WORK(RELTOL+1)))
            RELOBT=1.0E0-MAX(0.0E0,MIN(1.0E0,WORK(RELTOL+1)))
      GO TO 20016
20020       FEA=IOPT(II+1)
      GO TO 20016
20021       JJ=IOPT(II+1)
C           FER=MAX($FERVAL$,WORK(JJ))
            FER=MAX(EFERVL,WORK(JJ))
      GO TO 20016                                                       00024200
20022       REVERM=1
            REVERS=1
            II=II-1
      GO TO 20016
20023       KMAXF=MAX(3,MIN0(8,IOPT(II+1)))
      GO TO 20016
20024 GO TO 20016
20025       NFMAXM=IOPT(II+1)
            NFMAX=NFMAXM
      GO TO 20016                                                       00025200
20026       NFINDX=II+1
      GO TO 20016
20027       TALOC=IOPT(II+1)
      GO TO 20016
20028       ERRINA=WORK(IOPT(II+1))
            ERRINB=WORK(IOPT(II+1)+1)
      GO TO 20016
20029       IXKDIM=II+1
20016    II=II+2
      GO TO 20007                                                       00026300
20008 CONTINUE
      RETURN
20006 MACT(10) = II
      IOPT(1)=4
      CALL MESS(MACT, MTEXT, IOPT)
      RETURN
 
C
      END        

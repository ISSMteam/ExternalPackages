      SUBROUTINE DBESJN(X,ALPHA,NUM,BJ)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1992-03-13 DBESJN FTK  Removed implicit statements.
C>> 1989-08-09 DBESJN CLL  More accurate HALFPI for Cray
C>> 1986-03-18 DBESJN Lawson  Initial code.
C
C     COMPUTE THE J-BESSEL FUNCTIONS OF X FOR ORDER ALPHA THROUGH
C     ALPHA + NUM - 1 in steps of one.                                  00001200
C     STORE THE RESULT INTO BJ(I),I=1,...,NUM.
C     Require X .ge. 0, ALPHA .ge. 0, NUM .ge. 1
C
c     Original code due to E. W. Ng and W. V. Snyder, JPL, 1973.
c     Modified by Ng and S. Singletary, 1974.
C     C.Lawson & S.Chan, JPL, 1984 Apr 05:
c        Changed calling sequence.
c        Adapted to SFTRAN3 and Fortran 77.
c        Added code to avoid overflow during the recurrsion.
c        Added code to use Taylor series for small x.                   00002200
c        March 23. Improved accuracy of backward recursion.
c        Changed to use P and Q instead of R and THETA
c                in the region of large X.
C     ------------------------------------------------------------------
C
      SAVE EPS, SMALL, XPQ, BIG, HICUT
c     ----------
c     Subprograms used:  LOG10, SQRT, COS, SIN
      EXTERNAL           DGAMMA, DBESPQ, D1MACH, ERMSG, DERV1, IERV1
c     ----------                                                        00003200
      INTEGER I,I1,II,INT,J,K,M,MU,N20021,NMAX,NMIN,NPR001,NUM
      DOUBLE PRECISION ALPHA,BESV,BESVM1,BESVP1,BIG,BJ(NUM),BJNU,BOT
      DOUBLE PRECISION C11293,C16,C1P5,C59,CHI,CP6,D1MACH,DBLE,DGAMMA
      DOUBLE PRECISION DR,EM,EMU,EPS,ETA,FAC,FAC2,FK,FKM1,FKP1,FV,FVM1
      DOUBLE PRECISION FVP1,G,GNU,HALF,HALFPI,HALFX,HICUT
      DOUBLE PRECISION ONE,P,Q,SCALE,SMALL,SUM,T1,T2,TENTH,TERM
      DOUBLE PRECISION TERM1,TEST,TOP,TWO,TWODX,V,VPMU,X,XPQ,ZERO
      parameter(ZERO=0.D0, ONE=1.D0, TWO=2.D0, C16=16.D0)
      parameter( TENTH = 0.1D0, HALF = 0.5D0)
      parameter(HALFPI = 1.57079 63267 94896 61923 13216 91639 75144D0) 00004200
      parameter(C11293 = 1.1293D0, CP6 = 0.60206D0, C59 = 0.59D0)
      parameter(C1P5 = 1.5D0)
      data EPS / ZERO /
C     ------------------------------------------------------------------
C
c     Set environment parameters.  This should happen only
c     the first time this subroutine is called.
c
      IF( EPS .EQ. ZERO )THEN
         EPS = D1MACH(3)                                                00005300
         HICUT = ONE /(EPS*C16)
         XPQ = C11293 * (CP6 - LOG10(EPS)) - C59
         SMALL = C16 * D1MACH(1) / EPS
         BIG = D1MACH(2)/TWO
      END IF
C
c     Test validity of input values.
c
      IF (.NOT.(X .LT. ZERO .OR. ALPHA .LT. ZERO .OR. NUM .LT. 1)) GO TO
     * 20005
c                                                                       00006300
c     >                                                      Error 1.
        CALL ERMSG('DBESJN',1,0,                                        
     *             'REQUIRE X.GE.0, ALPHA.GE.0, NUM.GE.1',',')
      ASSIGN 20006 TO NPR001
      GO TO 30001
20006   RETURN
C
c     Begin computation.
c
20005 NMIN = INT(ALPHA)
      V = ALPHA - DBLE(NMIN)
      NMAX = NMIN + NUM - 1                                             00007500
C
      IF (.NOT.( X .LE. TENTH )) GO TO 20008
      GO TO 30002
20009 GO TO 20007
20008 IF (.NOT.( X .LT. MAX(DBLE(NMAX+1), XPQ) )) GO TO 20010
      GO TO 30003
20011 GO TO 20007
20010 IF (.NOT.( X .LT. HICUT )) GO TO 20012
      GO TO 30004
20013 GO TO 20007
c     >                                             Error 2.
20012    CALL ERMSG('DBESJN', 2, 0,                                     00008500
     *   'Cannot obtain any accuracy when X exceeds HICUT.', ',')
         CALL DERV1('HICUT', HICUT, ',')
      ASSIGN 20014 TO NPR001
      GO TO 30001
C
20014 CONTINUE
20007 RETURN
C
C     ------------------------------------------------------------------
C
C     PROCEDURE( SMALL X )
C
30002 IF (.NOT.( X .EQ. ZERO )) GO TO 20016                             00009700
c                                         Special for X .eq. 0.
      DO 20017 I = 1, NUM
            BJ(I) =  ZERO
20017 CONTINUE
         IF (ALPHA .EQ. 0) BJ(1) = ONE
      GO TO 20015
c                     Here use Taylor series for small x.
C
20016    GNU = ALPHA
         HALFX = HALF*X                                                 00010700
         FAC2 = -HALFX*HALFX
         TERM1 = (HALFX**GNU) / DGAMMA(GNU + ONE)
      I =1
      N20021=NUM
      GO TO 20022
20020 I =I +1
20022 IF ((N20021-I ).LT.0) GO TO 20021
      GO TO 30005
20023       BJ(I) = BJNU
      IF( BJNU .EQ. ZERO )THEN
C
c     Here current result has underflowed to zero, so we will
c     set the rest of the results to zero also.
c                                                                       00011700
      DO 20026 J = I+1, NUM
                  BJ(J) = ZERO
20026 CONTINUE
      GO TO 20021
      END IF
            GNU = GNU + ONE
            TERM1 = TERM1 * (HALFX / GNU)
      GO TO 20020
20021 CONTINUE
20015 GO TO 20009                                                       00012700
C
C     ------------------------------------------------------------------
c
C     PROCEDURE( SERIES FOR SMALL X )
C
c     Sums the series for the Bessel fcn J sub GNU of X given
c     in Eq 9.1.10, page 360, of AMS 55.
c     Returns the value, BJNU.
c      1984 March 9, JPL, C. L. Lawson.
c                                                                       00013700
30005 IF(TERM1 .EQ. ZERO)THEN
         BJNU = ZERO
      GO TO 31005
      END IF
c
      SUM = ZERO
      TOP = FAC2
      BOT = GNU + ONE
      T1 = ONE
      T2 = BOT                                                          00014700
      TERM = TOP/BOT
c
20031 IF( ABS(TERM) .GT. EPS )THEN
         SUM = SUM + TERM
         TOP = TOP * FAC2
         T1 = T1 + ONE
         T2 = T2 + ONE
         BOT = BOT * T1 * T2
         TERM = TOP/BOT
      GO TO 20031                                                       00015700
      END IF
c
      BJNU = TERM1 + TERM1 * SUM
31005 GO TO 20023
c
C     ------------------------------------------------------------------
C
C     PROCEDURE( MIDDLE X )
C
C     J-TYPE BESSEL FUNCTIONS FOLLOW THE RECURRENCE RELATION            00016600
C     F(V-1,X)=(2*V/X)*F(V,X)-F(V+1,X).
C
30003 TWODX = TWO / X
      MU = MAX( INT(X)+1, NMAX)
      DR = TWODX * (V+DBLE(MU))
      FKP1 = ONE
      FK =  ZERO
C
C     RECUR FORWARD UNTIL FKP1 IS GREATER THAN PRECISION OF ARITHMETIC.
C                                                                       00017600
20033 IF( EPS * ABS(FKP1) .LE. ONE )THEN
      MU = MU + 1
      DR = DR + TWODX
      FKM1 = FK
      FK = FKP1
      FKP1 = DR * FK - FKM1
      GO TO 20033
      END IF
C
C     WE ARE NOW ASSURED THAT BACKWARD RECURRENCE FROM MU WILL YIELD    00018500
C     ACCURATE RESULTS.
C
C                                        GUARANTEE EVEN MU
      IF (MOD(MU,2) .NE. 0)  MU = MU + 1
      FVM1 = SMALL
      FV = ZERO
      ETA = ONE
      SUM = FVM1
      M = MU / 2
      EM = DBLE(M)                                                      00019500
      EMU = DBLE(MU)
      FAC = (V + EMU) * TWODX
C
c     Set TEST = largest value that can be multiplied by
c     FAC without risking overflow.  The present value of
c     FAC is the largest that will occur during the recursion.
c     TEST will be used to protect against overflow during
c     the recursion.
c
      TEST = BIG / MAX(ONE, FAC)                                        00020500
C
C                             Loop while MU .GT. ZERO
C
20035 FVP1 = FV
      FV = FVM1
      IF (.NOT.( ABS(FV) .GT. TEST )) GO TO 20037
      GO TO 30006
20037 FVM1 = FAC * FV - FVP1
      MU = MU -1
      EMU = EMU - ONE                                                   00021500
      FAC = (V + EMU) * TWODX
      IF (MU .GE. NMIN .AND. MU .LE. NMAX) BJ(MU-NMIN+1) = FVM1
      IF(MOD(MU,2) .EQ. 0)THEN
      IF(V .EQ. ZERO)THEN
          SUM = SUM + FVM1
      IF(MU .EQ. 0)THEN
            SCALE = ONE / SUM
      GO TO 20036
      END IF
          SUM = SUM + FVM1                                              00022500
      ELSE
      IF(MU .NE. 0)THEN
            VPMU = V + EMU
            ETA = ETA * (EM/(V + (EM-ONE))) * (VPMU / (VPMU + TWO))
            SUM = SUM + FVM1 * ETA
            EM = EM - ONE
      ELSE
c
c           Here MU = 0 and EM = 0NE.  Thus the expression for
c           updating ETA reduces to the following simpler               00023500
c           expression.
c
            ETA = ETA / (V + TWO)
            SUM = SUM + FVM1 * ETA
            SCALE = DGAMMA(V+ONE) / ETA * SUM * TWODX ** V
            SCALE = ONE / SCALE
      GO TO 20036
      END IF
      END IF
      END IF                                                            00024500
      GO TO 20035
C
C     NORMALIZE BJ() TO GET VALUES OF J-BESSEL FUNCTION.
C
20036 DO 20046 I = 1, NUM
         BJ(I) = BJ(I) * SCALE
20046 CONTINUE
20047 GO TO 20011
C
C     ------------------------------------------------------------------00025500
C
C     PROCEDURE( RESCALE )
C
30006 FV = FV / SUM
      FVP1 = FVP1 / SUM
      I1 = MAX( 1, MU - NMIN + 1 )
      DO 20049 II = I1, NUM
         BJ(II) = BJ(II) / SUM
20049 CONTINUE
20050 SUM = ONE                                                         00026500
      GO TO 20037
C
C     ------------------------------------------------------------------
C
C     PROCEDURE( LARGE X )
C
c     >     Here we have X .ge. XPQ, and V in [0.,1.).
c     The asymptotic series for
c     the auxiliary functions P and Q can be used.
c     From these we will compute J(V,X) and J(V+1,X) and                00027500
c     then recur forward.
c     Reference: NBS AMS 55 Eqs 9.2.5 & 9.2.6
c
30004 CALL DBESPQ (X,V,  P,Q)
      CHI = X - (V + HALF) * HALFPI
      BESV = SQRT(ONE / (HALFPI*X)) * (P*COS(CHI) - Q*SIN(CHI))
C
      IF( NMAX .GT. 0 )THEN
         CALL DBESPQ (X,V+ONE,   P,Q)
         CHI = X - (V + C1P5) * HALFPI                                  00028500
         BESVP1 = SQRT(ONE / (HALFPI*X)) * (P*COS(CHI) - Q*SIN(CHI))
      END IF
c
      TWODX = TWO / X
      GO TO 30007
20054 GO TO 20013
C     ------------------------------------------------------------------
c
C     PROCEDURE( FORWARD RECURSION )
c                                                                       00029500
c     >     Given BESV = J(V,X), BESVP1 = J(V+1,X), TWODX = 2/X,
c     NMIN, NUM, NMAX = NMIN + NUM -1,
c     X, ALPHA, and BIG.
c     Recur forward and store J(NMIN+V) thru J(NMAX+V) in
c     BJ(1) thru BJ(NUM).
c     >     There should be no overflow posibility in
c     this forward recursion since NMAX .le. X - 1, and
c     in this region the magnitude of the J function is
c     less than one.
c                                                                       00030500
30007 IF( NMIN .EQ. 0 )THEN
         BJ(1) = BESV
      IF( NMAX .GT. 0 )THEN
            BJ(2) = BESVP1
      END IF
      ELSEIF( NMIN .EQ. 1 )THEN
         BJ(1) = BESVP1
      END IF
c
      IF( NMAX .GT. 1 )THEN                                             00031500
         G = V * TWODX
c
c        Note:  In the following statement, 3-NMIN can be nonpositive.
c
      DO 20062 K = 3-NMIN, NUM
            BESVM1 = BESV
            BESV   = BESVP1
            G = G + TWODX
            BESVP1 = G * BESV - BESVM1
            IF( K .GE. 1)  BJ(K) = BESVP1                               00032500
20062 CONTINUE
      END IF
      GO TO 20054
C
C     ------------------------------------------------------------------
C
C     PROCEDURE( TRANSMIT X, ALPHA, AND NUM )
C
30001   CALL DERV1('X',X,',')
        CALL DERV1('ALPHA',ALPHA,',')                                   00033500
        CALL IERV1('NUM',NUM,'.')
      GO TO NPR001,(20006,20014)
C     ------------------------------------------------------------------
      END        

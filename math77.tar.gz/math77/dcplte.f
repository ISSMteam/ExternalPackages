      DOUBLE PRECISION FUNCTION DCPLTE(EM)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1992-03-13 DCPLTE FTK  Removed implicit statements.
C>> 1985-08-02 DCPLTE Lawson  Initial code.
C
C     Complete elliptic integral E(EM). Method given by
C     W.J.CODY, Math. of Comp.,Vol.19, (1965), pp. 105-111.
C     Data are taken from Cody's table in reverse order.
C     We are using N = 5 or 9 for single precision and
C     N = 10 for double precision.
C
C     C.L.LAWSON & STELLA CHAN,JPL,1983 JUNE.
C
C     ----------------------------------------------------
C
C     POLY DEGREE     NEGATIVE LOG BASE 10 OF MAX ABS
C                     ERROR OF APPROXIMATION
C
C         N           FOR K           FOR E
C         -           -----           -----
C         5            9.50            9.44
C         9           15.87           15.84
C        10           17.45           17.42
C
C     ----------------------------------------------------
C
      INTEGER J
      DOUBLE PRECISION C(10),D(10),D1MACH,DLOG,EM,EMP,FAC,HALF
      DOUBLE PRECISION ONE,S3,S4,U,ZERO
      SAVE FAC
C
      DATA FAC,ZERO,ONE,HALF / 2*0.D0, 1.D0, .5D0 /
C
      DATA C / 1.4946621757181326771D-04,2.4685033304607227339D-03,
     *         8.6384421736040744302D-03,1.0770635039866455473D-02,
     *         7.8204040609595541727D-03,7.5950934225594322802D-03,
     *         1.1569595745295402175D-02,2.1831811676130481568D-02,
     *         5.6805194567559156648D-02,4.4314718056088952648D-01/
C
      DATA D / 3.1859195655501571800D-05,9.8983328462253847867D-04,
     *         6.4321465864383017666D-03,1.6804023346363384981D-02,
     *         2.6145014700313878932D-02,3.3478943665761626232D-02,
     *         4.2717890547383095644D-02,5.8593661255531491732D-02,
     *         9.3749999721203140658D-02,2.4999999999990177208D-01/
C
      IF (FAC .EQ. ZERO) THEN
        FAC = ONE + 2 * D1MACH(3)
      END IF
C
      IF (EM .GT. ONE) THEN
        CALL DERM1('DCPLTE',1,0,'UNDEFINED FOR EM .GT. ONE',
     *             'EM',EM,'.')
        U = ZERO
      ELSE IF (EM .LT. ZERO) THEN
        CALL DERM1('DCPLTE',2,0,'UNDEFINED FOR EM .LT. ZERO',
     *             'EM',EM,'.')
        U = ZERO
      ELSE
        EMP = HALF + (HALF- EM)
        IF (EMP .EQ. ZERO) THEN
          U = ONE
          GO TO 10
        END IF
        S3 = EMP * C(1)
        S4 = EMP * D(1)
        DO 100 J = 2, 10
          S3 = (S3 + C(J)) * EMP
          S4 = (S4 + D(J)) * EMP
  100   CONTINUE
        U = ONE + S3 + DLOG(ONE/EMP) * S4
      END IF
C
  10  DCPLTE = U * FAC
      RETURN
C
      END

      REAL             FUNCTION SMPVAL (P, NDEG, X)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1987-12-09 SMPVAL Lawson  Initial code.
C     EVALUATION OF POLYNOMIAL USING MONOMIAL BASIS AND A
C     LINEAR TRANSFORMATION OF THE ARGUMENT.
C     C.L.LAWSON, JPL, 1974 NOV 19
      REAL             P(*), X, U
      SMPVAL=0.
      U=(X-P(1))/P(2)
      J=NDEG
   10     IF (J .LT. 0)  RETURN
          SMPVAL=SMPVAL*U + P(J+3)
          J=J-1
          GO TO 10
      END

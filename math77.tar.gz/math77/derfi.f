      double precision function DERFI (X)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1987-10-29 DERFI  Snyder  Initial code.
c
c     For -1.0 .LT. X .LT. 1.0 calculate the inverse of the error
c     function.  That is, X = ERF(ERFI).
c
c     For 0.0 .LT. X .LT. 2.0 calculate the inverse of the
c     complementary error function.  that is, X = ERFC(ERFCI).  This
c     calculation is carried out by invoking the alternate entry *ERFCI.
c
c     If X is out of range, program execution is terminated by calling
c     the error message processor.
c
c     This subprogram uses approximations due to A. Strecok from
c     Mathematics of Computation 22, (1968) pp 144-158.
c
      double precision DERFCI
      double precision X
c
c     *****     Parameters     *****************************************
c
c ERRLEV  is the error level used in case DERM1 is called.
c MAX...  is the position in C of the last coefficient of a Chebyshev
c         polynomial expansion.
c MIN...  is the position in C of the first coefficient of a Chebyshev
c         polynomial expansion.
c NC      is the upper dimension of the array of coefficients.
c NDELTA  is the number of coefficients of the Chebyshev polynomial
c         expansion used to approximate R(X) in the range
c         0.9975 .LT. X .LE. 1-5.0E-16
c NLAMDA  is the number of coefficients of the Chebyshev polynomial
c         expansion used to approximate R(X) in the range
c         0.8 .LT. X .LE. 0.9975.
c NMU     is the number of coefficients of the Chebyshev polynomial
c         expansion used to approximate R(X) in the range
c         5.0E-16 .GT. 1-X .GE. 1.E-300.
c NXI     is the number of coefficients of the Chebyshev polynomial
c         expansion used to approximate DERFCI(X)/X in the
c         range 0.0 .LE. X .LE. 0.8.
c
      integer ERRLEV
      parameter (ERRLEV=0)
      parameter (MINDEL = 0)
      parameter (NDELTA = 37)
      parameter (MAXDEL = MINDEL + NDELTA)
      parameter (MINLAM = MAXDEL + 1)
      parameter (NLAMDA = 26)
      parameter (MAXLAM = MINLAM + NLAMDA)
      parameter (MINMU = MAXLAM + 1)
      parameter (NMU = 25)
      parameter (MAXMU = MINMU + NMU)
      parameter (MINXI = MAXMU + 1)
      parameter (NXI = 38)
      parameter (MAXXI = MINXI + NXI)
      parameter (NC = MAXXI)
c
c     *****     External References     ********************************
c
c D1MACH   Provides the round-off level.  Used to calculate the number
c          of coefficients to retain in each Chebyshev expansion.
c DERM1    Prints an error message and stops if X .LE. -1.0 or
c          X .GE. 1.0 (ERFI) or X .LE. 0.0 or X .GE. 2.0 (ERFCI).
c LOG      Calculates the natural logarithm.
c SQRT     Calculates the square root.
c
      double precision D1MACH
c
c     *****     Local Variables      ***********************************
c
c ARG     If ERFI or ERFCI is being approximated by a Chebyshev
c         expansion then ARG is the argument of ERFI or the argument
c         that would be used if ERFCI(X) were computed as ERFC(1-X),
c         that is, ARG = X if ERFI is being computed, or ARG = 1-X if
c         ERFCI is being computed.  If ERFI or ERFCI is being computed
c         using the initial approximation ERFI=SQRT(-LOG((1-X)*(1+X))),
c         then ARG is that initial approximation.
c C       contains the coefficients of polynomial expansions.  They are
c         stored in C in the order DELTA(0..37), LAMDA(0..26),
c         MU(0..25), XI(0..38).
c D       are used to scale the argument of the Chebyshev polynomial
c         expansion in the range 1.E-300 .LT. 1-X .LT. 0.2.
c DELTA   are coefficients of the Chebyshev polynomial expansion of R(X)
c         for 0.9975 .LT. X .LE. 1-5.0E-16.
c FIRST   is a logical SAVE variable indicating whether it is necessary
c         to calculate the number of coefficients to use for each
c         Chebyshev expansion.
c FSIGN   is X or 1.0 - X.  It is used to remember the sign to be
c         assigned to the function value.
c I, J    are used as indices.
c JIX     is an array containing MINXI, MAXXI, MINLAM, MAXLAM, MINDEL,
c         MAXDEL, MINMU, MAXMU in locations -1..6
c JMIN    is the minimum index of a coefficient in the Chebyshev
c         polynomial expansion to be used.
c LAMDA   are coefficients of the Chebyshev polynomial expansion of R(X)
c         for 0.8 .LT. X .LE. 0.9975.
c MU      are coefficients of the Chebyshev polynomial expansion of R(X)
c         for 5.0E-16 .GT. 1-X .GE. 1.E-300.
c S2      is 2.0 * S.
c S       is the argument of the Chebyshev polynomial expansion.
c SUBNAM  is the entry name.  This is used only if X is out of range.
c W1..W3  are adjacent elements of the recurrence used to evaluate the
c         Chebyshev polynomial expansion.
c XI      are coefficients of the Chebyshev polynomial expansion of
c         ERFC(X)/X for 0.0 .LE. X .LE. 0.8.
c
      double precision ARG, C(0:NC), D(6), DELTA(0:NDELTA)
      logical FIRST
      save FIRST
      double precision FSIGN
      integer I, J, JIX(-1:6)
      save JIX
      integer JMIN
      double precision LAMDA(0:NLAMDA), MU(0:NMU), S, S2
      character*6 SUBNAM
      double precision W1, W2, W3
      double precision XI(0:NXI)
c
c     *****     Equivalence Statements     *****************************
c
      equivalence (C(MINDEL),DELTA(0))
      equivalence (C(MINLAM),LAMDA(0))
      equivalence (C(MINMU),MU(0))
      equivalence (C(MINXI),XI(0))
c
c     *****     Data Statements     ************************************
c
      data D /-1.54881 30423 73261 65951 2742 D0
     2,        2.56549 01231 47816 15192 8163 D0
     3,       -.55945 76313 29832 32254 36913 D0
     4,        2.28791 57162 63357 63896 5891 D0
     5,       -9.19999 23588 30151 03127 8420 D0
     6,        2.79499 08201 24599 49376 8426 D0/
c
c     DELTA(J), J = 0..NDELTA
c
      data DELTA(0) /  .95667   97090    20492    52745    26373 D0/
      data DELTA(1) / -.02310   70043    09064    90369    99908 D0/
      data DELTA(2) / -.00437   42360    97508    40773    33218 D0/
      data DELTA(3) / -.00057   65034    22651    18548    09364 D0/
      data DELTA(4) / -.00001   09610    22307    09239    31242 D0/
      data DELTA(5) /  .00002   51085    47024    64427    87982 D0/
      data DELTA(6) /  .00001   05623    36067    94775    11955 D0/
      data DELTA(7) /  .00000   27544    12330    03063    91503 D0/
      data DELTA(8) /  .00000   04324    84498    32833    80689 D0/
      data DELTA(9) / -.00000   00205    30336    65520    86916 D0/
      data DELTA(10) / -.00000   00438    91536    66543    16784 D0/
      data DELTA(11) / -.00000   00176    84009    50808    81795 D0/
      data DELTA(12) / -.00000   00039    91289    02804    63420 D0/
      data DELTA(13) / -.00000   00001    86932    41245    59212 D0/
      data DELTA(14) /  .00000   00002    72922    73967    46077 D0/
      data DELTA(15) /  .00000   00001    32817    21315    65497 D0/
      data DELTA(16) /  .00000   00000    31834    24844    82286 D0/
      data DELTA(17) /  .00000   00000    01670    06077    51926 D0/
      data DELTA(18) / -.00000   00000    02036    46496    11537 D0/
      data DELTA(19) / -.00000   00000    00964    84681    27965 D0/
      data DELTA(20) / -.00000   00000    00219    56727    78128 D0/
      data DELTA(21) / -.00000   00000    00009    56898    13014 D0/
      data DELTA(22) /  .00000   00000    00013    70325    72230 D0/
      data DELTA(23) /  .00000   00000    00006    25385    05417 D0/
      data DELTA(24) /  .00000   00000    00001    45846    15266 D0/
      data DELTA(25) /  .00000   00000    00000    10781    23993 D0/
      data DELTA(26) / -.00000   00000    00000    07092    29988 D0/
      data DELTA(27) / -.00000   00000    00000    03914    11775 D0/
      data DELTA(28) / -.00000   00000    00000    01116    59209 D0/
      data DELTA(29) / -.00000   00000    00000    00157    70366 D0/
      data DELTA(30) /  .00000   00000    00000    00028    53149 D0/
      data DELTA(31) /  .00000   00000    00000    00027    16662 D0/
      data DELTA(32) /  .00000   00000    00000    00009    57770 D0/
      data DELTA(33) /  .00000   00000    00000    00001    76835 D0/
      data DELTA(34) / -.00000   00000    00000    00000    09828 D0/
      data DELTA(35) / -.00000   00000    00000    00000    20464 D0/
      data DELTA(36) / -.00000   00000    00000    00000    08020 D0/
      data DELTA(37) / -.00000   00000    00000    00000    01650 D0/
c
      data FIRST /.TRUE./
c
      data JIX /MINXI, MAXXI, MINLAM, MAXLAM, MINDEL, MAXDEL
     1,         MINMU, MAXMU/
c
c     LAMDA(J), J = 0..NLAMDA
c
      data LAMDA(0) /  .91215   88034    17553    77330    59200 D0/
      data LAMDA(1) / -.01626   62818    67663    69585    46661 D0/
      data LAMDA(2) /  .00043   35564    72949    44536    50589 D0/
      data LAMDA(3) /  .00021   44385    70074    45920    65205 D0/
      data LAMDA(4) /  .00000   26257    51075    76481    30176 D0/
      data LAMDA(5) / -.00000   30210    91050    10379    69912 D0/
      data LAMDA(6) / -.00000   00124    06061    83675    72157 D0/
      data LAMDA(7) /  .00000   00624    06609    29999    17380 D0/
      data LAMDA(8) / -.00000   00005    40124    79009    57858 D0/
      data LAMDA(9) / -.00000   00014    23207    89753    15910 D0/
      data LAMDA(10) /  .00000   00000    34384    02819    55305 D0/
      data LAMDA(11) /  .00000   00000    33584    87039    00138 D0/
      data LAMDA(12) / -.00000   00000    01458    42885    16512 D0/
      data LAMDA(13) / -.00000   00000    00810    21742    58833 D0/
      data LAMDA(14) /  .00000   00000    00052    53240    85874 D0/
      data LAMDA(15) /  .00000   00000    00019    71154    08612 D0/
      data LAMDA(16) / -.00000   00000    00001    74943    33828 D0/
      data LAMDA(17) / -.00000   00000    00000    48005    96619 D0/
      data LAMDA(18) /  .00000   00000    00000    05573    02987 D0/
      data LAMDA(19) /  .00000   00000    00000    01163    26054 D0/
      data LAMDA(20) / -.00000   00000    00000    00172    62489 D0/
      data LAMDA(21) / -.00000   00000    00000    00027    84973 D0/
      data LAMDA(22) /  .00000   00000    00000    00005    24481 D0/
      data LAMDA(23) /  .00000   00000    00000    00000    65270 D0/
      data LAMDA(24) / -.00000   00000    00000    00000    15707 D0/
      data LAMDA(25) / -.00000   00000    00000    00000    01475 D0/
      data LAMDA(26) /  .00000   00000    00000    00000    00450 D0/
c
c     MU(J), J = 0..NMU
c
      data MU(0) /  .98857   50640    66189    31364    60358 D0/
      data MU(1) /  .01085   77051    84599    47761    60281 D0/
      data MU(2) / -.00175   11651    02762    79524    94825 D0/
      data MU(3) /  .00002   11969    93206    56334    37984 D0/
      data MU(4) /  .00001   56648    71404    24350    87911 D0/
      data MU(5) / -.00000   05190    41686    91031    24261 D0/
      data MU(6) / -.00000   00371    35789    74267    17780 D0/
      data MU(7) /  .00000   00012    17430    86623    57429 D0/
      data MU(8) / -.00000   00001    76811    55266    13442 D0/
      data MU(9) / -.00000   00000    11937    21825    56161 D0/
      data MU(10) /  .00000   00000    00380    25053    58299 D0/
      data MU(11) / -.00000   00000    00066    01883    22362 D0/
      data MU(12) / -.00000   00000    00008    79170    55170 D0/
      data MU(13) / -.00000   00000    00000    35068    69329 D0/
      data MU(14) / -.00000   00000    00000    06972    21497 D0/
      data MU(15) / -.00000   00000    00000    01095    67941 D0/
      data MU(16) / -.00000   00000    00000    00115    36390 D0/
      data MU(17) / -.00000   00000    00000    00013    26235 D0/
      data MU(18) / -.00000   00000    00000    00002    63938 D0/
      data MU(19) /  .00000   00000    00000    00000    05341 D0/
      data MU(20) / -.00000   00000    00000    00000    22610 D0/
      data MU(21) /  .00000   00000    00000    00000    09552 D0/
      data MU(22) / -.00000   00000    00000    00000    05250 D0/
      data MU(23) /  .00000   00000    00000    00000    02487 D0/
      data MU(24) / -.00000   00000    00000    00000    01134 D0/
      data MU(25) /  .00000   00000    00000    00000    00420 D0/
c
c     XI(J), J = 0..NXI
c
      data XI(0) /  .99288   53766    18940    82314    95800 D0/
      data XI(1) /  .12046   75161    43104    48646    47846 D0/
      data XI(2) /  .01607   81993    42099    94472    57039 D0/
      data XI(3) /  .00268   67044    37162    31582    79591 D0/
      data XI(4) /  .00049   96347    30235    72629    47170 D0/
      data XI(5) /  .00009   88982    18599    12044    09911 D0/
      data XI(6) /  .00002   03918    12763    99443    37340 D0/
      data XI(7) /  .00000   43272    71617    73542    18758 D0/
      data XI(8) /  .00000   09380    81412    85934    06758 D0/
      data XI(9) /  .00000   02067    34720    86834    27411 D0/
      data XI(10) /  .00000   00461    59699    10543    00078 D0/
      data XI(11) /  .00000   00104    16679    70271    46217 D0/
      data XI(12) /  .00000   00023    71500    99959    21222 D0/
      data XI(13) /  .00000   00005    43928    40684    71390 D0/
      data XI(14) /  .00000   00001    25548    98640    97987 D0/
      data XI(15) /  .00000   00000    29138    18036    63201 D0/
      data XI(16) /  .00000   00000    06794    94218    08797 D0/
      data XI(17) /  .00000   00000    01591    23433    31469 D0/
      data XI(18) /  .00000   00000    00374    02505    85245 D0/
      data XI(19) /  .00000   00000    00088    20877    62421 D0/
      data XI(20) /  .00000   00000    00020    86508    97725 D0/
      data XI(21) /  .00000   00000    00004    94880    41039 D0/
      data XI(22) /  .00000   00000    00001    17663    94740 D0/
      data XI(23) /  .00000   00000    00000    28038    55725 D0/
      data XI(24) /  .00000   00000    00000    06695    06638 D0/
      data XI(25) /  .00000   00000    00000    01601    65495 D0/
      data XI(26) /  .00000   00000    00000    00383    82583 D0/
      data XI(27) /  .00000   00000    00000    00092    12851 D0/
      data XI(28) /  .00000   00000    00000    00022    14615 D0/
      data XI(29) /  .00000   00000    00000    00005    33091 D0/
      data XI(30) /  .00000   00000    00000    00001    28488 D0/
      data XI(31) /  .00000   00000    00000    00000    31006 D0/
      data XI(32) /  .00000   00000    00000    00000    07491 D0/
      data XI(33) /  .00000   00000    00000    00000    01812 D0/
      data XI(34) /  .00000   00000    00000    00000    00439 D0/
      data XI(35) /  .00000   00000    00000    00000    00106 D0/
      data XI(36) /  .00000   00000    00000    00000    00026 D0/
      data XI(37) /  .00000   00000    00000    00000    00006 D0/
      data XI(38) /  .00000   00000    00000    00000    00002 D0/
c
c     *****     Procedures     *****************************************
c
c     Decide which approximation to use, and calculate the argument of
c     the Chebyshev polynomial expansion.
c
      fsign = x
      arg = abs(x)
      if (arg.lt.0.0d0 .or. arg.ge.1.0d0) go to 998
      if (arg.eq.0.0d0) then
         derfi = 0.0d0
         return
      end if
      if (arg.le.0.8d0) then
         s = 3.125d0*arg*arg - 1.0d0
         j = -1
      else
         if (arg.le.0.9975d0) then
            j = 1
         else
            j = 3
         end if
         arg = sqrt(-log((1.0d0-arg)*(1.0d0+arg)))
         s = d(j)*arg + d(j+1)
      end if
      go to 100
c
c     *****     entry ERFCI     ****************************************
c
      entry DERFCI (X)
c
c     Calculate the inverse of the complementary error function.
c
c     Decide which approximation to use, and calculate the argument of
c     the Chebyshev polynomial expansion.
c
      if (x.le.0.0d0 .or. x.ge.2.0d0) go to 999
      if (x.eq.1.0d0) then
         derfi = 0.0d0
         return
      end if
      fsign = 1.0d0 - x
      arg = abs(fsign)
      if (arg.le.0.8d0) then
         s = 3.125d0*arg*arg - 1.0d0
         j = -1
      else
         arg = 2.0d0 - x
         if (x.lt.1.0d0) then
            s = x
         else
            s = arg
         end if
         arg = sqrt(-log(x*arg))
         if (s.lt.5.0d-16) then
            j = 5
            s = d(5)/sqrt(arg) + d(6)
         else
            if (s.ge.0.0025d0) then
               j = 1
            else if (s.ge.5.0d-16) then
               j = 3
            end if
            s = d(j)*arg + d(j+1)
         end if
      end if
c
c     If this is the first call, calculate the degree of each expansion.
c
100   if (first) then
         first = .false.
         s2 = 0.5d0*d1mach(3)
         do 120 jmin = -1, 5, 2
            do 110 i = jix(jmin), jix(jmin+1)
               if (abs(c(i)).lt.s2) then
                  jix(jmin+1) = i
                  go to 120
               end if
110         continue
120      continue
      end if
c
c     Evaluate the Chebyshev polynomial expansion.
c
      s2 = s + s
      w1 = 0.0d0
      w2 = 0.0d0
      jmin = jix(j)
      j = jix(j+1)
200      w3 = w2
         w2 = w1
         w1 = (s2*w2 - w3) + c(j)
         j = j - 1
         if (j.gt.jmin) go to 200
      derfi = sign(arg*((s*w1 - w2) + c(jmin)), fsign)
      return
c
998   subnam = 'DERFI'
      go to 1000
999   subnam = 'DERFCI'
1000  call derm1 (subnam,1,errlev,'Argument out of range','X',x,'.')
c     In case the error level is zero, or shifted to zero by the caller:
      derfi = 0.0d0
      return
c
      end

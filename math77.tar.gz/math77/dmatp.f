      SUBROUTINE DMATP (A,LDA,M,N,TEXT)
c     DMATP..  Print a matrix.
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1992-04-22 CLL
C>> 1990-01-23 CLL removed extraneous "60 continue"
C>> 1985-09-20 CLL
C>> 1983-07-05 Kris Stewart For MATH77
C>> 1981-07-23 Kris Stewart Improve portability.
C>> 1969-00-00 C. L. Lawson, JPL, Original code: MOUT/VOUT
C     ------------------------------------------------------------------
C  A( )      MATRIX TO BE OUTPUT
C  LDA       Leading dimension of array A().
C  M         NO. OF ROWS IN A MATRIX
C  N         NO. OF COLS IN A MATRIX
c  TEXT   Character string to be printed as a title.
c         First character in TEXT controls line spacing before title on
c         an impact printer.  For output to be viewed on a screen it is
c         safest to always use ' '.
c         ' ' = normal single space.
c         '0' = double space.
c         '1' = page advance.
c         '+' = suppress space, i.e., overprint.
C     ------------------------------------------------------------------
      integer I, J, J1, J2, LAST, LDA, M, MAXCOL, N, NBLOCK, NCOL
      DOUBLE PRECISION A(LDA,N)
      CHARACTER*(*) TEXT
      CHARACTER*3 COL
      DATA MAXCOL/6/,COL/'COL'/
C     ------------------------------------------------------------------
      WRITE(*,'(A)') TEXT
      NBLOCK=N /MAXCOL
      LAST=N -NBLOCK*MAXCOL
      NCOL=MAXCOL
      J1=1
C
C                            MAIN LOOP STARTS HERE
C
   20 IF(NBLOCK .GT.0) GO TO 30
      IF(LAST .LE. 0) RETURN
      NCOL=LAST
      LAST=0
C
   30 J2=J1+NCOL-1
      WRITE(*,'(/12X,6(6X,A3,I5,6X)/1X)') (COL,J,J=J1,J2)
           DO 50 I=1,M
   50      WRITE(*,'(a,I4,4X,1P,6G20.12)') ' ROW',I,(A(I,J),J=J1,J2)
      J1=J1+MAXCOL
      NBLOCK=NBLOCK-1
      GO TO 20
      END

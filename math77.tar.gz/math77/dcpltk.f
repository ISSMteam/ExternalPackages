      DOUBLE PRECISION FUNCTION DCPLTK(EM)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1992-03-13 DCPLTK FTK  Removed implicit statements.
C>> 1985-08-02 DCPLTK Lawson  Initial code.
C
C     Complete elliptic integral K(EM). Method given by
C     W.J.CODY, Math. of Comp.,Vol.19, (1965), pp. 105-111.
C     Data are taken from Cody's table in reverse order.
C     We are using N = 5 or 9 for single precision and
C     N = 10 for double precision.
C
C     C.L.LAWSON & STELLA CHAN,JPL,1983 JUNE.
C
C     ----------------------------------------------------
C
C     POLY DEGREE     NEGATIVE LOG BASE 10 OF MAX ABS
C                     ERROR OF APPROXIMATION
C
C         N           FOR K           FOR E
C         -           -----           -----
C         5            9.50            9.44
C         9           15.87           15.84
C        10           17.45           17.42
C
C     ----------------------------------------------------
C
      INTEGER J
      DOUBLE PRECISION A(10),B(10),D1MACH,DLOG,EM,EMP,FAC,HALF
      DOUBLE PRECISION ONE,S1,S2,U,VL,ZERO
      SAVE FAC
C
C     VL = LOG(4)
      DATA VL/ .138629436111989061883D+01/
C
      DATA FAC,ZERO,ONE,HALF / 2*0.D0, 1.D0, .5D0 /
C
      DATA A / 1.3930878570066467279D-04,2.2966348983969586869D-03,
     *         8.0030039806499853708D-03,9.8489293221768937682D-03,
     *         6.8479092826245051197D-03,6.1796274460533176084D-03,
     *         8.7898018745550646778D-03,1.4938013532687165242D-02,
     *         3.0885146271305189866D-02,9.6573590280856255384D-02/
C
      DATA B / 2.9700280966555612066D-05,9.2155463496324984638D-04,
     *         5.9739042991554291551D-03,1.5530941631977203877D-02,
     *         2.3931913323110790077D-02,3.0124849012898930266D-02,
     *         3.7377739758623604144D-02,4.8828041906862397978D-02,
     *         7.0312499739038352054D-02,1.2499999999990808051D-01/
C
C
      IF (FAC .EQ. ZERO) THEN
        FAC = ONE + 2 * D1MACH(3)
      END IF
C
      IF (EM .GE. ONE) THEN
        CALL DERM1('DCPLTK',1,0,'INFINITE VALUE WHEN EM .EQ. 1' //
     *             ' AND UNDEFINED FOR EM .GT. 1','EM',EM,'.')
        U = ZERO
      ELSE IF (EM .LT. ZERO) THEN
        CALL DERM1('DCPLTK',2,0,'UNDEFINED FOR EM .LT. ZERO',
     *             'EM',EM,'.')
        U = ZERO
      ELSE
        EMP = HALF + (HALF- EM)
        S1 = EMP * A(1)
        S2 = EMP * B(1)
        DO 100 J = 2, 10
          S1 = (S1 + A(J)) * EMP
          S2 = (S2 + B(J)) * EMP
  100   CONTINUE
        U = VL + S1 + DLOG(ONE/EMP) * (HALF + S2)
      END IF
C
      DCPLTK = U * FAC
      RETURN
C
      END

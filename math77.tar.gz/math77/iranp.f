      integer function IRANP(XMEAN)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-03-16 CLL
c>> 1991-11-26 CLL Reorganized common. Using RANCM[A/D/S].
c>> 1991-11-22 CLL Added call to RAN0, and SGFLAG in common.
c>> 1991-01-15 CLL Reordered common contents for efficiency.
C>> 1990-01-23 CLL  Making names in common same in all subprogams.
C>> 1987-04-23 IRANP  Lawson  Initial code.                             00001200
c        Returns one pseudorandom integer from the Poisson distribution
c     with mean and variance = XMEAN.
c        The probability of occurrence of the nonnegative integer k in
c     the Poisson distribution with mean XMEAN is
 
c                P(k) = exp(-XMEAN) * XMEAN**k / k!
 
c        Let SUM(n) denote the sum for k = 0 to n of P(k).
c     Let U be a random sample from a uniform
c     distribution on [0.0, 1.0].  The returned value of IRANP will be  00002200
c     the smallest integer such that S(IRANP) .ge. U.
c     This variable has mean and variance = XMEAN.
c     Reference: Richard H. Snow, Algorithm 342, Comm ACM, V. 11,
c     Dec 1968, p. 819.
c     Code based on subprogram written for JPL by Stephen L. Ritchie,
c     Heliodyne Corp. and Wiley R. Bunton, JPL, 1969.
c     Adapted to Fortran 77 for the JPL MATH77 library by C. L. Lawson &
c     S. Y. Chiu, JPL, Apr 1987.
c     ------------------------------------------------------------------
c                    Subprogram argument and result                     00003200
c
c     XMEAN [in]  Mean value for the desired distribution.
c           Must be positive and not so large that exp(-XMEAN)
c           will underflow.  For example, on a machine with underflow
c           limit 0.14E-38, XMEAN must not exceed 88.
c
c     IRANP [Returned function value]  Will be set to a nonnegative
c           integer value if computation is successful.
c           Will be set to -1 if XMEAN is out of range.
c     ------------------------------------------------------------------00004200
c     Intrinsic functions referenced: EXP, LOG, MIN, NINT, REAL
c     MATH77 subprograms referenced: R1MACH, SERM1, SERV1, SRANUA, RAN0
c     Other MATH77 subprograms needed: ERMSG, ERFIN, I1MACH
c     Common referenced: /RANCMS/, /RANCMA/
c     ------------------------------------------------------------------
      integer M, NMAX
      parameter(M = 97, NMAX = 84)
      real    SNUMS(M), ELIMIT, MONE, R1MACH, S, SPREV, SUM(0:NMAX)
      real    TERM, TLAST, TWO
      real    U, XMEAN, XMSAVE, ZERO                                    00005200
      integer LAST, N, NMID
      logical FIRST
      parameter(ZERO = 0.0E0, MONE = -1.0E0, TWO = 2.0E0)
      common/RANCMS/SNUMS
c
      integer DPTR, SPTR
      logical DGFLAG, SGFLAG
      common/RANCMA/DPTR, SPTR, DGFLAG, SGFLAG
c
      save   /RANCMA/, /RANCMS/                                         00006200
      save    ELIMIT, FIRST, LAST, NMID, SUM, TLAST, XMSAVE
      data    FIRST / .true. /
      data    ELIMIT / ZERO /
c     ------------------------------------------------------------------
      IF (.NOT.(FIRST)) GO TO 20003
      ASSIGN 20004 TO NPR001
      GO TO 30001
20004    FIRST = .false.
         call RAN0
      GO TO 20002
20003 IF (.NOT.(XMEAN .ne. XMSAVE)) GO TO 20005
      ASSIGN 20006 TO NPR001                                            00007300
      GO TO 30001
20006 CONTINUE
20005 CONTINUE
c
20002 GO TO 30002
c
20007 IF (.NOT.(U .gt. SUM(LAST))) GO TO 20009
      GO TO 30003
20010 GO TO 20008
20009 GO TO 30004
20011 CONTINUE
20008 return
c     ------------------------------------------------------------------00008400
C     procedure( SET FOR NEW XMEAN )
c
c     R1MACH(1) gives the underflow limit.
c     ELIMIT gives a limit for arguments to the exponential function
c     such that if XMEAN .le. ELIMIT,  exp(-XMEAN) should not
c     underflow.
c
30001 if(ELIMIT .eq. ZERO) ELIMIT = -log(R1MACH(1) * TWO)
      IF(XMEAN .le. ZERO  .or.  XMEAN .gt. ELIMIT)THEN
         call SERM1('IRANP',1, 0,'Require 0 .lt. XMEAN .le. ELIMIT',    00009400
     *      'XMEAN',XMEAN,',')
         call SERV1('ELIMIT',ELIMIT,'.')
         IRANP = -1
         return
      END IF
      LAST = 0
      TLAST = exp(-XMEAN)
      SUM(0) = TLAST
      XMSAVE = XMEAN
      NMID = nint(XMEAN)
      GO TO NPR001,(20004,20006)                                        00010500
c     ------------------------------------------------------------------
C     procedure ( SET U = UNIFORM RANDOM NUMBER )
c
30002 SPTR = SPTR - 1
      IF(SPTR .eq. 0)THEN
         call SRANUA(SNUMS,M)
         SPTR = M
      END IF
      U = SNUMS(SPTR)
      GO TO 20007                                                       00011500
c     ------------------------------------------------------------------
C     procedure( COMPUTE MORE SUMS )
c
30003    N = LAST
         SPREV = SUM(LAST)
         TERM = TLAST
20016       N = N + 1
            TERM = TERM * XMEAN / real(N)
            S = SPREV + TERM
      IF(S .eq. SPREV)THEN                                              00012600
               IRANP = N
      GO TO 20017
      END IF
      IF(N .le. NMAX)THEN
               LAST = N
               SUM(LAST) = S
               TLAST = TERM
      END IF
      IF(U .le. S)THEN
               IRANP = N                                                00013600
      GO TO 20017
      END IF
            SPREV = S
      GO TO 20016
20017 GO TO 20010
c     ------------------------------------------------------------------
C     procedure( SEARCH THROUGH STORED SUMS )
c
c     Here we already know that U .le. SUM(LAST).
c     It is most likely that U will be near SUM(NMID).                  00014600
c
30004 IF(NMID .lt. LAST)THEN
      IF( U .gt. SUM(NMID) )THEN
      DO 20028 N = NMID+1, LAST
      IF(U .le. SUM(N))THEN
                     IRANP = N
      GO TO 31004
      END IF
20028 CONTINUE
      END IF                                                            00015600
      END IF
c
      DO 20033 N = min(NMID, LAST)-1, 0,-1
      IF(U .gt. SUM(N))THEN
               IRANP = N+1
      GO TO 31004
      END IF
20033 CONTINUE
         IRANP = 0
31004 GO TO 20011                                                       00016600
      end                

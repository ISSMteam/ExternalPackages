      subroutine SCONMC(N, COEFF)
c     .  Copyright (C) 1992, California Institute of Technology.
c     .  All rights reserved.  U. S. Government sponsorship under
c     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-06-04 SCONMC Krogh  Corrected line below.
c>> 1992-01-31 SCONMC Krogh  Initial Code.
c
c Converts COEFF in monomial basis to the Chebyshev basis.
c
      real             COEFF(0:N), TP
c
      if (N .le. 0) return
      TP = .5E0**(N-1)
      COEFF(N) = TP * COEFF(N)
      COEFF(N-1) = TP * COEFF(N-1)
      do 20 J = N-2, 0, -1
         TP = 2.E0 * TP
         COEFF(J) = TP * COEFF(J)
         COEFF(J+1) = 2.E0 * COEFF(J+1)
         do 10 I = J, N-2
            COEFF(I) = COEFF(I) + COEFF(I+2)
   10    continue
   20 continue
      return
      end

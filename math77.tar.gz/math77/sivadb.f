c$$   START( SIVADB, ROOT = 'SIVA', $ROOT$DB)
c     .  Copyright (C) 1989, California Institute of Technology.
c     .  All rights reserved.  U. S. Government sponsorship under
c     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-03-10 SIVADB Krogh  Fixed value for KDIM
c>> 1992-02-17 SIVADB Krogh   Made tabs depend on # digits output.
c>> 1991-11-04 SIVADB Krogh   Switched to use MESS, SMESS
c>> 1990-03-08 SIVADB Krogh   Unused stiff vars. set to 0.
c>> 1989-07-21 SIVADB Krogh   Code for integrating discontinuities
c>> 1988-06-07 SIVADB Krogh   Dim. of IVC2 and DVC2 upped by 1 (old bug)
c>> 1987-12-07 SIVADB Krogh   Initial code.
c$$   KDIMDT   = CONVAL($ KDIMDT $ IF (L1 .EQ. 'D') 20 $ 14 $) =20$
c$$   KMAXO    = CONVAL( $KMAXO$ )=2$
c$$   MAXKQD   = CONVAL( $MAXKQD$ )=1$
      subroutine SIVADB(LPRINT, TSPECS, Y, F, KORD, NTEXT)
c SUBROUTINE TO GIVE DEBUG PRINT FOR VARIABLE ORDER INTEGRATOR
c ========== THIS PROGRAM HAS BEEN SPECIALIZED ==========
c
c  LET ABS(LPRINT)=  10*N1 + N2     (N1,N2 DIGITS)
c    N1=1   DO NOT PRINT ANY VARIABLES EXTERNAL TO THE INTEGRATOR
c    N1=2   PRINT  TSPECS, CURRENT Y, PAST Y, CURRENT F,
c           ALL PERTINENT CONTENTS OF KORD, AND TOL.
c    N1=3   ABOVE + DIFFERENCE TABLES UP TO HIGHEST DIFFERENCE USED
c    N1=4   SAME AS N1=1 + ALL IN STORAGE ALLOCATED FOR DIFFERENCES
c
c    N2=1   DO NOT PRINT ANY VARIABLES INTERNAL TO THE INTEGRATOR
c    N2=2   PRINT ALL SCALAR VARIABLES IN INTERPOLATION COMMON BLOCK
c    N2=3   ABOVE + ALL SCALAR VARIABLES IN MAIN INTEG. COMMON BLOCK
c    N2=4   SAME AS N1=3 + ALL USED IN ARRAYS XI,BETA,ALPHA, FIRST
c           COLUMN OF G, GS,RBQ,SIGMA
c    N2=5   SAME AS N1=4 + ALL USED IN ARRAYS G,D,DS,V
c
      integer LPRINT, KORD(*)
      character NTEXT*(*)
      integer IVC1(12), IVC2(65)
      real             DVC2(14), RVC2(7), TNEQ(1), EVC(8)
      real             Y(*)
      real             TSPECS(*), F(*)
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6)
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c
c.    SPECIFICATION OF ENVIRONMENTAL CONSTANTS.
      real             EEPS10, EEPS16, EROV10, EEPS2
      real             EEPT75, EOVEP2, OVTM75, OVD10
      common / SIVAEV / EEPS2, EEPT75, EOVEP2, OVTM75, OVD10, EEPS10,
     1   EEPS16, EROV10
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
      equivalence (IVC1(1), IOPST), (IVC2(1), ICF)
      equivalence (TNEQ, TN)
      equivalence (RVC2(1), DNOISE), (DVC2(1), HC), (EVC(1), EEPS2)
c
c                      Declarations for error message processing.
c     
      parameter (MEDDIG =12)
      parameter (NEDDIG =-MEDDIG)
      parameter (METDIG =22)
      parameter (METABS =32)
      parameter (MERET  =51)
      parameter (METEXT =53)
      parameter (METXTF =54)
      parameter (METABL =55)
      parameter (MEIVEC =57)
      parameter (MEFVEC =61)
      parameter (MEFMAT =62)
      integer MACT0(5), MACT1(2), MACT2(7), MACT3(7), MACT4(8),
     1   MACT5(11), MACT6(3), MACT7(14), MACTFV(4)
      character MTEXT(1308)
      parameter (LTXTAA = 1)
      character MTXTAA*(13)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 14)
      character MTXTAB*(13)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      parameter (LTXTAC = 27)
      character MTXTAC*(13)
      equivalence (MTEXT(LTXTAC), MTXTAC)
      parameter (LTXTAD = 40)
      character MTXTAD*(13)
      equivalence (MTEXT(LTXTAD), MTXTAD)
      parameter (LTXTAE = 53)
      character MTXTAE*(20)
      equivalence (MTEXT(LTXTAE), MTXTAE)
      parameter (LTXTAF = 73)
      character MTXTAF*(14)
      equivalence (MTEXT(LTXTAF), MTXTAF)
      parameter (LTXTAG = 87)
      character MTXTAG*(15)
      equivalence (MTEXT(LTXTAG), MTXTAG)
      parameter (LTXTAH = 102)
      character MTXTAH*(6)
      equivalence (MTEXT(LTXTAH), MTXTAH)
      parameter (LTXTAI = 108)
      character MTXTAI*(7)
      equivalence (MTEXT(LTXTAI), MTXTAI)
      parameter (LTXTAJ = 115)
      character MTXTAJ*(9)
      equivalence (MTEXT(LTXTAJ), MTXTAJ)
      parameter (LTXTAK = 124)
      character MTXTAK*(52)
      equivalence (MTEXT(LTXTAK), MTXTAK)
      parameter (LTXTAL = 176)
      character MTXTAL*(56)
      equivalence (MTEXT(LTXTAL), MTXTAL)
      parameter (LTXTAM = 232)
      character MTXTAM*(12)
      equivalence (MTEXT(LTXTAM), MTXTAM)
      parameter (LTXTAN = 244)
      character MTXTAN*(56)
      equivalence (MTEXT(LTXTAN), MTXTAN)
      parameter (LTXTAO = 300)
      character MTXTAO*(57)
      equivalence (MTEXT(LTXTAO), MTXTAO)
      parameter (LTXTAP = 357)
      character MTXTAP*(54)
      equivalence (MTEXT(LTXTAP), MTXTAP)
      parameter (LTXTAQ = 411)
      character MTXTAQ*(60)
      equivalence (MTEXT(LTXTAQ), MTXTAQ)
      parameter (LTXTAR = 471)
      character MTXTAR*(60)
      equivalence (MTEXT(LTXTAR), MTXTAR)
      parameter (LTXTAS = 531)
      character MTXTAS*(57)
      equivalence (MTEXT(LTXTAS), MTXTAS)
      parameter (LTXTAT = 588)
      character MTXTAT*(53)
      equivalence (MTEXT(LTXTAT), MTXTAT)
      parameter (LTXTAU = 641)
      character MTXTAU*(55)
      equivalence (MTEXT(LTXTAU), MTXTAU)
      parameter (LTXTAV = 696)
      character MTXTAV*(58)
      equivalence (MTEXT(LTXTAV), MTXTAV)
      parameter (LTXTAW = 754)
      character MTXTAW*(59)
      equivalence (MTEXT(LTXTAW), MTXTAW)
      parameter (LTXTAX = 813)
      character MTXTAX*(57)
      equivalence (MTEXT(LTXTAX), MTXTAX)
      parameter (LTXTAY = 870)
      character MTXTAY*(28)
      equivalence (MTEXT(LTXTAY), MTXTAY)
      parameter (LTXTAZ = 898)
      character MTXTAZ*(51)
      equivalence (MTEXT(LTXTAZ), MTXTAZ)
      parameter (LTXTBA = 949)
      character MTXTBA*(19)
      equivalence (MTEXT(LTXTBA), MTXTBA)
      parameter (LTXTBB = 968)
      character MTXTBB*(46)
      equivalence (MTEXT(LTXTBB), MTXTBB)
      parameter (LTXTBC = 1014)
      character MTXTBC*(54)
      equivalence (MTEXT(LTXTBC), MTXTBC)
      parameter (LTXTBD = 1068)
      character MTXTBD*(46)
      equivalence (MTEXT(LTXTBD), MTXTBD)
      parameter (LTXTBE = 1114)
      character MTXTBE*(55)
      equivalence (MTEXT(LTXTBE), MTXTBE)
      parameter (LTXTBF = 1169)
      character MTXTBF*(29)
      equivalence (MTEXT(LTXTBF), MTXTBF)
      parameter (LTXTBG = 1198)
      character MTXTBG*(4)
      equivalence (MTEXT(LTXTBG), MTXTBG)
      parameter (LTXTBH = 1202)
      character MTXTBH*(10)
      equivalence (MTEXT(LTXTBH), MTXTBH)
      parameter (LTXTBI = 1212)
      character MTXTBI*(9)
      equivalence (MTEXT(LTXTBI), MTXTBI)
      parameter (LTXTBJ = 1221)
      character MTXTBJ*(55)
      equivalence (MTEXT(LTXTBJ), MTXTBJ)
      parameter (LTXTBK = 1276)
      character MTXTBK*(33)
      equivalence (MTEXT(LTXTBK), MTXTBK)
      parameter (LOCF1 = 400 + 10000 * (LTXTBG - LTXTBE + 1))
      parameter (MODF2 = -1 - 10000 * (LTXTBH - LTXTBE + 1))
      parameter (LOCF2 = -1301 - 10000 * (LTXTBI - LTXTBE + 1))
      parameter (LAHAG = LTXTAH - LTXTAG + 1)
      parameter (LAIAG = LTXTAI - LTXTAG + 1)
c
      data MACT0 / METXTF, 0, METABS, 10, MERET /
      data MACT1 / METEXT, MERET /
c                       1       2  3       4       5  6      7
      data MACT2 / METEXT, MEIVEC, 3, METEXT, MEIVEC, 0, MERET /
c                       1       2  3       4       5  6      7
      data MACT3 / METEXT, MEIVEC, 0, METEXT, MEFVEC, 0, MERET /
c                       1       2  3  4  5       6       7
      data MACT4 / METEXT, MEFMAT, 0, 0, 0, LAIAG, LAHAG, MERET /
c                       1   2       3       4   5       6  7       8
      data MACT5 / METABS, 12, METEXT, METABS, 18, METDIG, 5, METEXT,
     1             METABS, 0, MERET /
c                       9 10     11
      data MACT6 / NEDDIG, 0, MERET /
c                         2 3 4     5 6 7 8 9    10    11   12 13 14
      data MACT7 / METABL,0,0,0,LOCF1,0,0,0,0,LOCF2,LOCF2,LOCF2,0,0 /
c                        1       2  3      4
      data MACTFV / METEXT, MEFVEC, 3, MERET /
c
      DATA MTXTAA/'$NKORD:    $B'/,MTXTAB/'Int. Ord.: $B'/,
     1MTXTAC/'D.E. Ord.: $B'/,MTXTAD/'Meth.Type: $B'/,
     2MTXTAE/'Tolerance Groups: $B'/,MTXTAF/'Tolerances: $B'/,
     3MTXTAG/'$NDifferences$B'/,MTXTAH/'Eq. $M'/,MTXTAI/'Ord. $M'/,
     4MTXTAJ/'$NTN=$F$E'/,
     5MTXTAK/'$NIOPST=$I$TKORDI=$I$TKQMAXD=$I$TKQMAXI=$I$TLDT=$I$T'/,
     6MTXTAL/
     7'MAXDIF=$I$TMAXINT=$I$TNKDKO=$I$TNTE=$I$TNYNY=$I$TNDTF=$I'/,
     8MTXTAM/'$TNUMDT=$I$E'/,
     9MTXTAN/'$NICF=$I$TICS=$I$TIGFLG=$I$TIGTYPE(1)=$I$TIGTYPE(2)=$I$T'/
      DATA MTXTAO/
     1'IGSTOP(1)=$I$TIGSTOP(2)=$I$TILGREP=$I$TINGS=$I$TIOP3=$I$T'/,
     2MTXTAP/'IOP4=$I$TIOP5=$I$TIOP6=$I$TIOP7=$I$TIOP8=$I$TIOP9=$I$T'/,
     3MTXTAQ/
     4'IOP10=$I$TIOP11=$I$TIOP12=$I$TIOP13=$I$TIOP14=$I$TIOP15=$I$T'/,
     5MTXTAR/
     6'IOP16=$I$TIOP17=$I$TIOP18=$I$TIOP19=$I$TIOP20=$I$TIOP21=$I$T'/,
     7MTXTAS/
     8'IOP22=$I$TIOP21S=$I$TITOLEP=$I$TIY=$I$TKEMAX=$I$TKIS=$I$T'/,
     9MTXTAT/'KMARK=$I$TKORD1I=$I$TKORD2I=$I$TKPRED=$I$TKQDCON=$I$T'/
      DATA MTXTAU/
     1'KQICON=$I$TKQMAXS=$I$TKQMXDS=$I$TKQMXIL=$I$TKQMXIP=$I$T'/,
     2MTXTAV/
     3'KQMXIS=$I$TKSC=$I$TKSOUT=$I$TKSSTRT=$I$TKSTEP=$I$TLEX=$I$T'/,
     4MTXTAW/
     5'LINC=$I$TLINCD=$I$TLINCQ=$I$TLSC=$I$TMAXKQD=$I$TMAXKQI=$I$T'/,
     6MTXTAX/
     7'METHOD=$I$TNE=$I$TNEPTOL=$I$TNG=$I$TNGTOT=$I$TNOISEQ=$I$T'/,
     8MTXTAY/'NOUTKO=$I$TNTOLF=$I$TNY=$I$E'/,
     9MTXTAZ/'$NDNOISE=$F$TEAVE=$F$TEIMAX=$F$TEIMIN=$F$TEMAX=$F$T'/
      DATA MTXTBA/'EREP=$F$TROBND=$F$E'/,
     1MTXTBB/'$NHC=$F$THDEC=$F$THINC=$F$THINCC=$F$THMAX=$F$T'/,
     2MTXTBC/'HMAXP9=$F$THMIN=$F$TTG(1)=$F$TTG(2)=$F$TTGSTOP(1)=$F$T'/,
     3MTXTBD/'TGSTOP(2)=$F$TTMARK=$F$TTMARKX=$F$TTOUT=$F$N$E'/,
     4MTXTBE/'K$HXI(K)$HBETA(K)$HALPHA(K)$HG(K,1)$HRBQ(K)$HSIGMA(K)$H'/,
     5MTXTBF/'GS(K)$HV(K)$HG(K,2..MAXINT)$H'/,MTXTBG/'(I4)'/,
     6MTXTBH/'(1PExx.xx)'/,MTXTBI/'(1PE13.5)'/,
     7MTXTBJ/'$NEEPS2=$F$TEEPT75=$F$TEOVEP2=$F$TOVTM75=$F$TOVD10=$F$T'/,
     8MTXTBK/'EEPS10=$F$TEEPS16=$F$TEROV10=$F$E'/
c
c ********
c START OF CODE -- PRINT NTEXT AND SET INDEX FOR F
c ********
c$$   COL1(.NOT.STIFF)
      KQDCON = 0
      KQMXDS = 0
      MAXKQD = 0
      J = 0
      MACT0(2) = len(NTEXT)
      call MESS(MACT0, NTEXT, IDAT)
c
   10 N1 = LPRINT / 10
      N2 = LPRINT - 10 * N1
      if (N1 .le. 1) go to 80
c ********
c PRINT ALL EXTERNAL VARIABLES EXCEPT FOR THE DIFFERENCES
c ********
      MACTFV(3) = max(IOP5, 4)
      call SMESS(MACTFV, '$NTSPECS:$B', KORD, TSPECS)
      MACTFV(3) = NY
      call SMESS(MACTFV, 'Y:$B', KORD, Y)
      call SMESS(MACTFV, 'YN:$B', KORD, Y(NYNY))
      MACTFV(3) = NTE
      call SMESS(MACTFV, 'F:$B', KORD, F)
      MACT2(6) = NTE
      call MESS(MACT2, MTEXT, KORD)
      if (NKDKO .gt. 0) call MESS(MACT2(4), MTEXT(LTXTAC), KORD(NKDKO))
      if (IOPST .gt. 0) call MESS(MACT2(4), MTEXT(LTXTAD), KORD(IOPST))
c WRITE TOL
   60 K = IOP16
   70 if (KORD(K) .lt. 0) K = K + 1
      K = K + 1
      if (KORD(K - 1) .lt. NTE) go to 70
      MACT3(3) = K - IOP16
      MACT3(6) = MACT3(3)
      call SMESS(MACT3, MTEXT(LTXTAE), KORD(IOP16), F(NTOLF))
      if (N1 .eq. 2) go to 80
c ********
c WRITE THE DIFFERENCE TABLES
c ********
      K = NUMDT
      if (N1 .eq. 3) K = KQMAXS
      MACT4(3) = NUMDT
      MACT4(4) = -K
      MACT4(5) = NTE
      call SMESS(MACT4, MTEXT(LTXTAG), KORD, F(NDTF))
c
   80 if (N2 .le. 1) return
c ********
c WRITE SCALARS IN COMMON
c ********
      call SMESS(MACT1, MTEXT(LTXTAJ), KORD, TNEQ)
c
c ===== COMMON 1  -- INTEGER
c
      call MESS(MACT1, MTEXT(LTXTAK), IVC1)
      if (N2 .eq. 2) return
      call MESS(MACT6, MTEXT, IDAT)
      MACT5(10) = MACT6(2) + 14
c
c ===== COMMON 2  -- INTEGER AND FLOATING POINT
c
      call SMESS(MACT5, MTEXT(LTXTAN), IVC2, RVC2)
      call SMESS(MACT1, MTEXT(LTXTBB), IVC2, DVC2)
      if (N2 .eq. 3) return
c
      J = MACT6(2) + 8
      write(MTXTBH(5:9), '(I2,''.'',I2)') J, MACT6(2)
      J = 100*J
      MACT7(2) = 1
      MACT7(3) = KQMAXS + 1
      MACT7(4) = 8
      do 90 K = 6, 9
         MACT7(K) = MODF2 - J
   90 continue
      if (N2 .gt. 0) then
         MACT7(4) = 8 + MAXINT
         MACT7(13) = MACT7(6)
         L = min(MAXINT, 4)
         MACT7(14) = MACT7(6) - J * (L-2)
      end if
      do 100 K = 1, MACT7(3)
         FDAT(1) = XI(K)
         FDAT(2) = BETA(K)
         FDAT(3) = ALPHA(K)
         FDAT(4) = G(K, 1)
         FDAT(5) = RBQ(K)
         FDAT(6) = SIGMA(K)
         FDAT(7) = GS(K)
         if (N2 .gt. 4) then
            FDAT(8) = V(K)
            do 95 J = 2, L
               FDAT(7+J) = G(K, J)
   95       continue
         end if
         call SMESS(MACT7, MTEXT(LTXTBE), IDAT, FDAT)
  100 continue
c$$   COL1(STIFF)
c     if (MAXDIF .le. 0) return
c        Need to define MACT8 and set values
c     call SMESS(MACT8, 'D$B', IDAT, D)
c     call SMESS(MACT8, 'DS$B', IDAT, DS)
c$$   COL1(STIFF,0)
c
      call SMESS(MACT1, MTEXT(LTXTBJ), IDAT, EVC)
      return
c$$   END   DEBUG SUBROUTINE -IVADB
      end

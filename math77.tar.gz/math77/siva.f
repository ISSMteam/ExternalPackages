c$$   START( SIVA , ROOT = 'SIVA', $ROOT$ )
c     .  Copyright (C) 1989, California Institute of Technology.
c     .  All rights reserved.  U. S. Government sponsorship under
c     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-10-13 SIVA  Krogh  Fixed G-Stop/discontinuity code interaction.
c>> 1992-09-21 SIVA  Krogh  Fixed bug in discontinuity code.
c>> 1992-09-09 SIVA  Krogh  Fixed bug - Var. Eqs. with discontinuities.
c>> 1992-08-07 SIVA  Krogh  Storage map printed only if option 10 .ne. 0
c>> 1992-07-16 SIVA  Krogh  Restored correct discontinuity code.
c>> 1992-06-16 SIVA  Krogh  Eliminate reuse of storage for option 12.
c>> 1992-04-08 SIVA  Krogh  Removed unused labels, 1020, 2120.
c>> 1992-03-30 SIVA  Krogh  Fixed bug in SIVAOP error message.
c>> 1992-03-12 SIVA  Krogh  Simplified SIVABU, more digits in B's.
c>> 1992-01-16 SIVA  Krogh  Fixed minor bug in error messages.
c>> 1991-12-03 SIVA  Krogh  Major change for improved error checks.
c>> 1991-06-17 SIVA  Krogh  Fixed bug in checking storage allocation.
c>> 1991-04-11 SIVA  Krogh  Fixed minor bug re. option 12 in SIVAOP.
c>> 1991-03-28 SIVA  Krogh  Removed check at label 650 for KORD2I<0.
c>> 1991-02-08 SIVA  Krogh  Changed some floats to dble's (for SIVA).
c>> 1990-11-08 SIVA  Krogh  Fixed bug on TSPECS on discon.
c>> 1990-09-14 SIVA  Krogh  Fixed bug when discon. and sol. save.
c>> 1990-09-13 SIVA  Krogh  Increased dimension of BETA by 1.
c>> 1990-09-13 SIVA  Krogh  Added one more poss. on rel. error test.
c>> 1990-09-11 SIVA  Krogh  Recent change messed up getting dump output.
c>> 1990-06-05 SIVA  Krogh  Fixed bug in noise test, comments in IVACOM.
c>> 1990-05-08 SIVA  Krogh  Fixed new bug when TMARK hit in SIVAG.
c>> 1990-04-17 SIVA  Krogh  Fixed minor problem in SIVAIN error msg.
c>> 1990-04-10 SIVA  Krogh  Fixed interaction between discon. & dump.
c>> 1990-03-23 SIVA  Krogh  Fixed bug on option "-2", see 1989-12-07.
c>> 1990-03-20 SIVA  Krogh  Fixed rarely occuring loop.
c>> 1990-01-29 SIVA  Krogh  Removed unneeded labels.
c>> 1989-12-14 SIVA  Krogh  Saved common block SIVAEV.
c>> 1989-12-07 SIVA  Krogh  Added option "2" to SIVAOP.
c>> 1989-11-09 SIVA  Krogh  Made GG a save var. in SIVAHC
c>> 1989-08-21 SIVA  Krogh  Fix out of bounds ref. to V in SIVABU
c>> 1989-07-26 SIVA  Krogh  Fix bug in initial dim. check
c>> 1989-07-21 SIVA  Krogh  Code for integrating discontinuities
c>> 1987-12-07 SIVA  Krogh  Initial code.
c
c ## On type conversion -- change KDIM value, and EIBND() and B() data.
c
c  SUBROUTINE TO INITIALIZE DIFFERENTIAL EQUATION PACKAGE
c     -ODE  OR  -IVA
c$$   KDIMDT   = CONVAL($ KDIMDT $ IF (L1 .EQ. 'D') 20 $ 14 $) =14$
c$$   KMAXO    = CONVAL( $KMAXO$ )=2$
c$$   MAXKQD   = CONVAL( $MAXKQD$ )=1$
c$$   STIFF    = CONVAL( $STIFF$ )=.F.$
c$$   INTEGO   = CONVAL( $INTEGO$ )=.T.$
c$$   VAREQ    = CONVAL( $VAREQ$ ) =.T.$
c$$   ARGM     = CONVAL( $ARGM$ ) =.F.$
c$$   ERRSTO   = CONVAL( $ERRSTO$)=.F.$
c$$   OUTPUT   = CONVAL( $OUTPUT$)=.T.$
c$$   DUMP     = CONVAL( $DUMP$ )=.T.$
c$$   GSTOP    = CONVAL( $GSTOP$ )=.T.$
c$$   EXTRAP   = CONVAL( $EXTRAP$ )=.T.$
c
      subroutine SIVA(TSPECS, Y, F, KORD, NEQ, DERIVS, OUTPUT, IDIMT,
     1   IDIMY, IDIMF, IDIMK, IOPT)
c
      integer NEQ, IDIMT, IDIMY, IDIMF, IDIMK
      integer KORD(*), IOPT(*)
      real             TSPECS(*), F(*)
      external DERIVS, OUTPUT
      real             Y(*)
c
c *********************** Internal Variables ***************************
c
c Comments for varibles used in this package can be found in the file
c   IVACOM.
c
c *********************** Type Declarations ****************************
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6), IOPIVA(2)
      save IOPIVA
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c
      integer KGO, INTCHK(0:30), NXTCHK
      equivalence (INTCHK(1), NXTCHK)
      real             CM1, C1
      parameter (CM1 = (-1.E0))
      parameter (C1 = 1.E0)
c.    SPECIFICATION OF ENVIRONMENTAL CONSTANTS.
      real             EEPS10, EEPS16, EROV10, EEPS2
      real             EEPT75, EOVEP2, OVTM75, OVD10
      common / SIVAEV / EEPS2, EEPT75, EOVEP2, OVTM75, OVD10, EEPS10,
     1   EEPS16, EROV10
      save / SIVAEV /
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
c
c                      Declarations for error message processing.
c     
      parameter (MENTXT =23)
      parameter (MEIDAT =24)
      parameter (MEMDA1 =27)
      parameter (MECONT =50)
      parameter (MERET  =51)
      parameter (MEEMES =52)
      parameter (METEXT =53)
      parameter (MEIVEC =57)
c
      integer MACT(16), MLOC(11), MACT1(4)
      character MTEXT(704)
      parameter (LTXTAA = 1)
      character MTXTAA*(6)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 7)
      character MTXTAB*(64)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      parameter (LTXTAC = 71)
      character MTXTAC*(57)
      equivalence (MTEXT(LTXTAC), MTXTAC)
      parameter (LTXTAD = 128)
      character MTXTAD*(51)
      equivalence (MTEXT(LTXTAD), MTXTAD)
      parameter (LTXTAE = 179)
      character MTXTAE*(43)
      equivalence (MTEXT(LTXTAE), MTXTAE)
      parameter (LTXTAF = 222)
      character MTXTAF*(64)
      equivalence (MTEXT(LTXTAF), MTXTAF)
      parameter (LTXTAG = 286)
      character MTXTAG*(55)
      equivalence (MTEXT(LTXTAG), MTXTAG)
      parameter (LTXTAH = 341)
      character MTXTAH*(56)
      equivalence (MTEXT(LTXTAH), MTXTAH)
      parameter (LTXTAI = 397)
      character MTXTAI*(54)
      equivalence (MTEXT(LTXTAI), MTXTAI)
      parameter (LTXTAJ = 451)
      character MTXTAJ*(27)
      equivalence (MTEXT(LTXTAJ), MTXTAJ)
      parameter (LTXTAK = 478)
      character MTXTAK*(28)
      equivalence (MTEXT(LTXTAK), MTXTAK)
      parameter (LTXTAL = 506)
      character MTXTAL*(43)
      equivalence (MTEXT(LTXTAL), MTXTAL)
      parameter (LTXTAM = 549)
      character MTXTAM*(36)
      equivalence (MTEXT(LTXTAM), MTXTAM)
      parameter (LTXTAN = 585)
      character MTXTAN*(38)
      equivalence (MTEXT(LTXTAN), MTXTAN)
      parameter (LTXTAO = 623)
      character MTXTAO*(47)
      equivalence (MTEXT(LTXTAO), MTXTAO)
      parameter (LTXTAP = 670)
      character MTXTAP*(35)
      equivalence (MTEXT(LTXTAP), MTXTAP)
      DATA MTXTAA/'SIVA$B'/,
     1MTXTAB/
     2'The interval [1, 10**6], bounds the allowed values for NTE=$I.$E'
     3/,MTXTAC/
     4'For option $I, the interval [$I, $I], bounds the allowed '/,
     5MTXTAD/'values for the integration order which is set to $I'/,
     6MTXTAE/'Option 16 must be used for error control.$E'/,
     7MTXTAF/
     8'F($I) = $F, but it must be -1.0 when skipping the error check.$E'
     9/
      DATA MTXTAG/
     1'KORD values for this option starting at KORD($M) are:$E'/,
     2MTXTAH/
     3'For option $I, the interval [$I, $I] bounds the allowed '/,
     4MTXTAI/'values for KORD($I)=$I, which is used to specify an $B'/,
     5MTXTAJ/'output type for printing.$E'/,
     6MTXTAK/'output group for printing.$E'/,
     7MTXTAL/'equation group for variational equations.$E'/,
     8MTXTAM/'order for a differential equation.$E'/,
     9MTXTAN/'equation group for diagnostic print.$E'/
      DATA MTXTAO/'equation group for integration order control.$E'/,
     1MTXTAP/'equation group for error control.$E'/
c
c        for KGO =     1      2      3      4      5      6      7
      data MLOC / LTXTAL,LTXTAN,LTXTAO,LTXTAP,LTXTAM,LTXTAJ,LTXTAK,
     2            LTXTAB,LTXTAC,LTXTAE,LTXTAF /
c           KGO        8      9     10     11
c
c                      1  2  3 4       5  6       7       8       9 10
      data MACT / MEEMES,38,24,0, MENTXT, 0, METEXT, MECONT, MEMDA1,0,
     1  METEXT, MEIDAT,0, MEIVEC,0, MECONT /
c           11      12 13     14 15     16
      data MACT1 / METEXT, MEIVEC, 0, MERET /
      data IOPIVA(1) / 1111 /
c
c ************** START OF EXECUTABLE CODE ******************
c
c     **** TEST IF CONTINUING AN INTEGRATION
      if (KORD(1) .ne. 0) go to 330
c     **** INITIALIZE VARIOUS SCALARS
      KSTEP = 0
      KORD2I = -5
      KORD(2) = -1
      NTE = NEQ
      NE = NTE
c
c     **** SET UP OPTIONS
      if (IOPT(1) .ne. 0) call SIVAOP(IOPT, F)
      call SIVAOP(IOPIVA, F)
      if (IOPT(1) .eq. 0) IOPIVA(2) = 1
c
      if ((NE .le. 0) .or. (NE .gt. 1000000)) then
         IDAT(1) = NE
         KGO = 8
         go to 650
      end if
c                         Set up diagnostic print on storage allocation.
      INTCHK(0) = 245
      if (IOP10 .ne. 0) INTCHK(0) = 247
c
c     **** CHECK TSPECS STORAGE ALLOCATION
      INTCHK(2) = IDIMT
      INTCHK(3) = 4
      NXTCHK = 4
      if (IOP5 .ne. 0) then
         INTCHK(4) = 5
         INTCHK(5) = 5
         if (IOP5 .gt. 0) then
            INTCHK(6) = IOP5 - 4
         else
            IHI = -IOP5
            JL = 4
            do 15 IHI = IHI, IDIMK-3, 3
               J = abs(KORD(IHI))
               if (J .eq. 0) go to 20
               if (abs(KORD(IHI + 2)) .gt. 1) then
                  IDAT(2) = -1
                  IDAT(3) = 1
                  KGO = 6
                  go to 600
               end if
               if ((J .le. JL) .or. (J .gt. KORD(IHI+1))) then
                  KGO = 7
                  IDAT(2) = JL + 1
                  IDAT(3) = KORD(IHI+1)
                  go to 610
               end if
               JL = KORD(IHI+1)
   15       continue
            if (KORD(IHI) .ne. 0) IHI = IHI + 3
   20       INTCHK(6) = JL - 4
         end if
         NXTCHK = 7
      end if
   25 call OPTCHK(INTCHK, IOPT, 'SIVA / TSPECS$E')
      if (NXTCHK .lt. 0) KORD2I = -4
c
c     **** CHECK KORD STORAGE ALLOCATION
      INTCHK(2) = IDIMK
      INTCHK(3) = NE + 3
      NXTCHK = 4
      if (IOP5 .lt. 0) then
         INTCHK(4) = 5
         INTCHK(5) = -IOP5
         INTCHK(6) = IHI + IOP5
         NXTCHK = 7
      end if
c
c$$   COL1( VAREQ )
      if (IOP18 .ne. 0) then
         NE = abs(KORD(IOP18))
         INTCHK(NXTCHK) = 18
         ILOW = IOP18
         KGO = 1
c.       **** CHECK OPTION FOR VALID INPUT
         go to 430
      end if
c$$   COL1( VAREQ, 0)
   30 continue
      if (NKDKO .ne. 0) then
c                        **** STORAGE ALLOCATED FOR ODE ORDERS
         INTCHK(NXTCHK) = 17
         INTCHK(NXTCHK+1) = NKDKO
         INTCHK(NXTCHK+2) = NTE
         NXTCHK = NXTCHK + 3
      end if
c$$   COL1( STIFF, 6)
c     IF (IOPST .ne. 0) then
c        INTCHK(NXTCHK) = 17
c        INTCHK(NXTCHK+1) = IOPST
c        INTCHK(NXTCHK+2) = NTE
c        NXTCHK = NXTCHK + 3
c     end if
c
c **** SET INITIAL INTEGRATION ORDERS, TEST ODE ORDERS ****
c
      MAXINT = 0
      MAXDIF = 0
      NY = 0
      do 80 K = 1, NTE
         if (NKDKO .ne. 0) KORDI = KORD(NKDKO + K - 1)
         NY = NY + abs(KORDI)
c$$   COL1( STIFF )
c     IF (IOPST .EQ. 0) GO TO 60
c.    **** CHECK FOR POTENTIAL STIFF EQUATION
c     JS = abs(KORD(IOPST+K-1)) - 1
c     IF ( JS ) 52,60,54
c.    **** EQUATION IS NOT ACTIVE
c  52 KQQ = 0
c     GO TO 56
c.    **** EQUATION USES IMPLICIT METHOD
c  54 KQQ = -1
c     IF (JS .GT. abs(KORDI)) then
c       Set up an error message.
c     end if
c     MAXINT = max(MAXINT, abs(KORDI) - JS)
c  56 IF (KORDI .GE. 0) GO TO 70
c     KORDI = -1 - KORDI
c     JS = JS - 1
c     MAXDIF = max(MAXDIF, JS, 1)
c     GO TO 70
c$$   COL1( STIFF, 0)
c     **** EQUATION IS TO USE AN EXPLICIT METHOD
   60    KQQ = 1
         MAXINT = max(MAXINT, KORDI)
   70    if ((KORDI .gt. MAXORD) .or. (KORDI .le. 0)) then
c                    Set up error message.  KORDI is out of range.
            IDAT(1) = 17
            IDAT(2) = 1
            IDAT(3) = MAXORD
            if (NKDKO .ne. 0) then
               KGO = 5
               ILOW = NKDKO
               IHI = NKDKO + K - 1
               go to 640
            else
               KGO = 9
               IDAT(4) = KORDI
               go to 650 
            end if
         end if
         KORD(K + 3) = KQQ
   80 continue
c     **** SET FLAGS WHICH DEPEND ON METHOD USED
c$$   COL1( STIFF )
c     METHOD = 1
c     IF (MAXINT .GT. 0) IF (MAXDIF) 85,90,85
c     METHOD = -1
c  85 CONTINUE
c     KPRED = 5
c     GO TO 100
c$$   COL1(STIFF, 0)
   90 METHOD = 0
      KPRED = 1
  100 continue
c
c ******* CHECK KORD FOR DIAGNOSTIC OUTPUT CONTROL *********
c
c$$   COL1( OUTPUT )
      if (IOP10 .gt. 0) then
         if (NOUTKO .ne. 0) then
            INTCHK(NXTCHK) = 10
            ILOW = NOUTKO
c.    **** Check option for valid input
            KGO = 2
            go to 430
         end if
      end if
c$$   COL1( OUTPUT, 0)
  110 continue
c
c ********** CHECK KORD FOR INTEGRATION ORDER CONTROL ******
c
c$$   COL1( INTEGO )
      if (IOP19 .ne. 0) then
c.           **** Check option for valid input
         INTCHK(NXTCHK) = 19
         ILOW = IOP19
         JLIM = -30
         KGO = 3
         go to 430
      end if
c$$   COL1( INTEGO, 0)
  120 continue
c
c ********** CHECK SET UP FOR ERROR TOLERANCES *************
c
      INTCHK(NXTCHK) = 16
      ILOW = IOP16
      JLIM = -5
      KGO = 4
      if (IOP16 .ne. 0) go to 430
c.                      **** IN CURRENT CODE, IOP16=0 IS AN ERROR
      KGO = 10
      go to 650
  150 continue
c     **** CHECK KORD STORAGE ALLOCATION
      call OPTCHK(INTCHK, IOPT, 'SIVA / KORD$E')
      if (NXTCHK .lt. 0) KORD2I = -4
c
c     ******** DONE CHECKING KORD STORAGE ALLOCATION *******
c
c     **** CHECK  Y  STORAGE ALLOCATION
      INTCHK(2) = IDIMY
      INTCHK(3) = NY + NY
      NXTCHK = 4
      NYNY = NY + 1
      call OPTCHK(INTCHK, IOPT, 'SIVA / Y$E')
      if (NXTCHK .lt. 0) KORD2I = -4
c
c     **** CHECK  F  STORAGE ALLOCATION
      INTCHK(2) = IDIMF
      INTCHK(3) = NTE
      NXTCHK = 4
      if (IOP16 .ne. 0) then
c                                Error tolerance info.
         INTCHK(4) = 16
         INTCHK(5) = NTOLF
         INTCHK(6) = IHI - IOP16 + 1
         NXTCHK = 7
      end if
      if (IOP12 .ne. 0) then
         INTCHK(NXTCHK) = 12
         INTCHK(NXTCHK+1) = IOP12
         INTCHK(NXTCHK+2) = 4
         NXTCHK = NXTCHK + 3
      end if
c
c$$   COL1(ERRSTO)
c     IF (IOP20 .ne. 0) then
c.                                Space for saving error estimates
c        INTCHK(NXTCHK) = 20
c        INTCHK(NXTCHK) = IOP20
c        INTCHK(NXTCHK) = NTE
c        NXTCHK = NXTCHK + 3
c     end if
c$$   COL1(STIFF)
c     if (IOP21 .gt. 0) then
c.                               Info. for stiff equations
c        INTCHK(NXTCHK) = 21
c        INTCHK(NXTCHK+1) = IOP21
c        INTCHK(NXTCHK+2) = IOP21S
c        NXTCHK = NXTCHK + 3
c     end if
c     MAXKQD = min(MAXKQI, 6)
c$$   COL1(STIFF, 0)
c                          Set aside space for the difference tables.
      INTCHK(NXTCHK) = 0
      INTCHK(NXTCHK+1) = -KDIM * NTE
      INTCHK(NXTCHK+2) = 0
      NXTCHK = NXTCHK + 3
      INTCHK(NXTCHK) = -5 * NTE
      call OPTCHK(INTCHK, IOPT, 'SIVA / F$E')
      if (NXTCHK .lt. 0) then
         KORD2I = -4
      else if (KORD2I .ne. -4) then
         do 290 K = NXTCHK+1, INTCHK(NXTCHK)
            if (INTCHK(INTCHK(K)) .eq. 0) then
               NDTF = INTCHK(INTCHK(K)+1)
               NUMDT = min(KDIM, (INTCHK(INTCHK(K)+2)-NDTF+1) / NTE)
               MAXKQI = NUMDT - 1
            else
c         Take a quick return if needed space was not specified by user.
               KORD2I = -4
            end if
  290    continue
      end if
  320 continue
      if ((KORD2I .eq. -4) .or. (IOP10 .ne. 0)) then
         MACT1(3) = IOPIVA(2)
         call MESS(MACT1, 'IOPT()= $B', IOPT)
         KORD1I = 24
         KORD(1) = 24
      end if
      TMARK = TSPECS(1)
c
c     **** DONE WITH INITIALIZATION AND CHECKING INPUTS
      if (IOP13 + IOP14 + IOP15 .ne. 0) return
  330 call SIVAA(TSPECS, Y, F, KORD, DERIVS, OUTPUT)
      return
c
c ************ LOOP TO CHECK OPTION SPECIFICATIONS *********
c
  430 JL = 0
      do 560 IHI = ILOW, IDIMK
         J = KORD(IHI)
         go to (460, 480, 490, 490), KGO
c     **** CHECK ON VARIATIONAL EQUATIONS
  460    continue
c$$   COL1( VAREQ )
         if (J - NTE) 470, 565, 620
  470    if (J .eq. 0) go to 560
         if (J .le. JL) go to 620
c$$   COL1( VAREQ, 0)
c     **** Check on diagnostic output option
  480    continue
c$$   COL1( OUTPUT )
c.    **** CHECK IF DONE
         if (J .ge. NTE) go to 565
         if (J .le. JL) go to 620
         go to 550
c$$   COL1( OUTPUT, 0)
  490    continue
c     **** Check integration order control (KGO=3) and
c     **** error tolerance equation grouping (KGO=4).
         if (J - NTE) 500, 565, 620
  500    if (J) 510, 530, 540
  510    if ((JL .le. 0) .and. (IHI .ne. ILOW)) go to 620
         if (J .lt. JLIM) then
c                         Output an error message.
            IDAT(2) = JLIM
            IDAT(3) = 0
            go to 630
         end if
  520    JL = -JL
         go to 560
  530    if (KGO .eq. 3) go to 520
         KFERR = NTOLF + IHI - ILOW
         if (F(KFERR) .eq. CM1) go to 510
c                         Set up error message, TOL must be -1.
            IDAT(1) = KFERR
            KGO = 11
            go to 650
  540    if (abs(JL) .ge. abs(J)) go to 620
  550    JL = J
  560    continue
  565 NXTCHK = NXTCHK + 3
      INTCHK(NXTCHK-2) = ILOW
      INTCHK(NXTCHK-1) = IHI - ILOW + 1
      go to (30, 110, 120, 150), KGO
c
c     **** AN ERROR HAS BEEN MADE
c                  Error in setting up TSPECS for extra output
  600 IHI = IHI + 2
  610 ILOW = -IOP5
      go to 630
c                  Error in KORD indices
  620 IDAT(2) = abs(JL) + 1
      IDAT(3) = NTE
c                  Set up for print of message about KORD
  630 IDAT(1) = INTCHK(NXTCHK)
  640 IDAT(4) = IHI
      IDAT(5) = KORD(IHI)
c
c ***************** Process Errors *************************************
c
  650 KORD2I = -4
      MACT(4) = LTXTAH
      if (KGO .ge. 8) MACT(4) = -1
      MACT(6) = MLOC(KGO)
      CALL SMESS(MACT, MTEXT, IDAT, FDAT)
      if (KGO .lt. 8) then
         MACT(10) = ILOW
         MACT(13) = ILOW
         MACT(15) = -min(IHI+2, IDIMK)
         CALL MESS(MACT(9), MTEXT(LTXTAG), KORD)
         if (KGO .le. 4) go to 565
      end if
c              5   6   7    8    9   10   11
      go to (100, 25, 25, 320, 100, 150, 660), KGO - 4
  660 KGO = 4
      go to 565
c$$   END  -IVA    (SET UP INTEGRATION OF DIFF. EQ.)
      end
c>> 19890224 SIVAA  Krogh   Big error with BETA(2)=1+epsilon -- looped
c>> 19880727 SIVAA  Krogh   Fixed to allow restart on a restart.
c>> 19880307 SIVAA  Krogh   Initial code.
c$$   START(SIVAA,ROOT='SIVA',$ROOT$A)
      subroutine SIVAA(TSPECS, Y, F, KORD, DERIVS, OUTPUT)
c ==========THIS PROGRAM HAS BEEN SPECIALIZED =========
c
c  MAIN SUBROUTINE FOR VARIABLE ORDER INTEGRATION OF ORDINARY
c  DIFFERENTIAL EQUATIONS
c
      real             TSPECS(*), F(*)
      real             Y(*)
      integer KORD(*)
      external DERIVS, OUTPUT
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6)
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c
      real             CMP75, C0, C1M5, C1M3, C2P5M3, C8M3, CP0625, CP1
      real             CP25, CP3, CP4, CP5, CP875, C1, C1P125, C1P3, C2
      real             C6, C10, C16, C4096
      parameter (CMP75 = (-.75E0))
      parameter (C0 = 0.E0)
      parameter (C1M5 = 1.E-5)
      parameter (C1M3 = 1.E-3)
      parameter (C2P5M3 = 2.5E-3)
      parameter (C8M3 = 8.E-3)
      parameter (CP0625 = .0625E0)
      parameter (CP1 = .1E0)
      parameter (CP25 = .25E0)
      parameter (CP3 = .3E0)
      parameter (CP4 = .4E0)
      parameter (CP5 = .5E0)
      parameter (CP875 = .875E0)
      parameter (C1 = 1.E0)
      parameter (C1P125 = 1.125E0)
      parameter (C1P3 = 1.3E0)
      parameter (C2 = 2.E0)
      parameter (C6 = 6.E0)
      parameter (C10 = 10.E0)
      parameter (C16 = 16.E0)
      parameter (C4096 = 4096.E0)
c
      real             TP, TP1, TP2, TP3, TMARKA(2), HH, DISADJ
      real             SIGMAS, TPS1, TPS2, EIMINO, EXR
c
c                      Declarations for error message processing.
c     
      parameter (MENTXT =23)
      parameter (MERET  =51)
      parameter (MEEMES =52)
      parameter (METEXT =53)
c
      character MTEXT(555)
      parameter (LTXTAA = 1)
      character MTXTAA*(7)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 8)
      character MTXTAB*(32)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      parameter (LTXTAC = 40)
      character MTXTAC*(40)
      equivalence (MTEXT(LTXTAC), MTXTAC)
      parameter (LTXTAD = 80)
      character MTXTAD*(49)
      equivalence (MTEXT(LTXTAD), MTXTAD)
      parameter (LTXTAE = 129)
      character MTXTAE*(59)
      equivalence (MTEXT(LTXTAE), MTXTAE)
      parameter (LTXTAF = 188)
      character MTXTAF*(48)
      equivalence (MTEXT(LTXTAF), MTXTAF)
      parameter (LTXTAG = 236)
      character MTXTAG*(35)
      equivalence (MTEXT(LTXTAG), MTXTAG)
      parameter (LTXTAH = 271)
      character MTXTAH*(30)
      equivalence (MTEXT(LTXTAH), MTXTAH)
      parameter (LTXTAI = 301)
      character MTXTAI*(39)
      equivalence (MTEXT(LTXTAI), MTXTAI)
      parameter (LTXTAJ = 340)
      character MTXTAJ*(48)
      equivalence (MTEXT(LTXTAJ), MTXTAJ)
      parameter (LTXTAK = 388)
      character MTXTAK*(64)
      equivalence (MTEXT(LTXTAK), MTXTAK)
      parameter (LTXTAL = 452)
      character MTXTAL*(29)
      equivalence (MTEXT(LTXTAL), MTXTAL)
      parameter (LTXTAM = 481)
      character MTXTAM*(47)
      equivalence (MTEXT(LTXTAM), MTXTAM)
      parameter (LTXTAN = 528)
      character MTXTAN*(28)
      equivalence (MTEXT(LTXTAN), MTXTAN)
c
      integer MACT(17), MLOC(8)
c
c.    SPECIFICATION OF ENVIRONMENTAL CONSTANTS.
      real             EEPS10, EEPS16, EROV10, EEPS2, EEPT75, EOVEP2
      real             OVTM75, OVD10
      common / SIVAEV / EEPS2, EEPT75, EOVEP2, OVTM75, OVD10, EEPS10,
     1   EEPS16, EROV10
      save / SIVAEV /
c     real             EEPS10, EEPS2, EEPT75, EOVEP2, OVTM75
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
      equivalence (G(1, 1), HH), (TMARKA(1), TMARK)
      equivalence (KEXIT, IOP17)
      save EIMINO, EXR, SIGMAS, TP, TP1, TP2, TP3, TPS1, TPS2, DISADJ,
     1   LDIS
c
      parameter (LOCM = 32 * 256)
      parameter (MLOCAC = 23 + 32 * (99 + 256 * LTXTAC))
      parameter (MLOCAD = 13 + 32 * (38 + 256 * LTXTAD))
      parameter (MLOCAE = 22 + 32 * (38 + 256 * LTXTAE))
      parameter (MLOCAF =  3 + 32 * (14 + 256 * LTXTAF))
      parameter (MLOCAG = 21 + 32 * (38 + 256 * LTXTAG))
      parameter (MLOCAH =  2 + 32 * (25 + 256 * LTXTAH))
      parameter (MLOCAI = 11 + 32 * (38 + 256 * LTXTAI))
      parameter (MLOCAJ = 12 + 32 * (38 + 256 * LTXTAJ))
      data MLOC / MLOCAC, MLOCAD, MLOCAE, MLOCAF, MLOCAG, MLOCAH,
     1   MLOCAI, MLOCAJ /
c
c                      1 2 3 4       5 6       7       8 9      10 
      data MACT / MEEMES,0,0,0, MENTXT,0, METEXT, MENTXT,0, METEXT,
     1  MENTXT, 0, METEXT, MENTXT, LTXTAN, METEXT, MERET /
c           11 12      13      14      15      16     17
      DATA MTXTAA/'SIVAA$B'/,MTXTAB/'At: TN=$F, KSTEP=$I, with H=$F$E'/,
     1MTXTAC/'A previously reported error was fatal.$E'/,
     2MTXTAD/'Print points not properly ordered: TSPEC($I)=$F$E'/,
     3MTXTAE/
     4'An error tolerance of 0 requires setting special flags.  $B'/,
     5MTXTAF/'Step size reduced too fast, doing a restart.  $B'/,
     6MTXTAG/'H is so small that TN + H = TN.  $B'/,
     7MTXTAH/'Error tolerance too small.  $B'/,
     8MTXTAI/'Step size at end of start < HMIN=$F, $B'/,
     9MTXTAJ/'Error estimates require a stepsize < HMIN=$F, $B'/
      DATA MTXTAK/
     1'(Estimated Error) / (Requested Error) for equation $I is $F.  $B'
     2/,MTXTAL/'Tolerance $I is F($I) = $F.$B'/,
     3MTXTAM/'Tolerance $I is F($I) * F($I) = $F * $F = $F.$B'/,
     4MTXTAN/'  Replacing F($I) with $F.$E'/
c
      data EXR, EIMINO / CP1, C8M3 /
      data LDIS / 0 /
c
c ************** START OF EXECUTABLE CODE ******************************
c
  660 if (KORD2I) 670, 1380, 1840
  670 if (KORD2I .eq. -1) go to 2140
      if (KORD2I .eq. -5) go to 720
      if (KORD2I+8) 1840, 710, 1840
c     **** SPECIAL OUTPUT CASE (EXTRAPOLATION OR GSTOP)
  680 go to (1220, 1190, 830, 690, 690, 2190), KEXIT
c     **** RESET TMARK BEFORE GOING WHERE DIRECTED BY KEXIT
  690 KEXIT = KEXIT - 2
      go to 1890
c     **** USER HAS REQUESTED A RESTART
  700 KORD2I = -5
      IGFLG = 0
      if (KORD(2) .ge. 2) KORD2I = -8
      if ((KORD1I .le. 3) .or. (KORD1I .eq. 5)) go to 1890
      if (KORD2I .eq. -5) go to 720
c                Set up for a discontinuity
  710 TP = TSPECS(1)
      if (KORD(2) .eq. 3) then
c                Adjust for discontinuity in Y
         J = 0
         do 712 I = 1, NTE
            if (NKDKO .ne. 0) KORDI = KORD(NKDKO + I -1)
            K = 1
            J = J + KORDI
            TP1 = Y(J)
  711       Y(NYNY + J - K) = Y(NYNY + J - K) + TP1
            if (K .lt. KORDI) then
               TP1 = Y(J-K) + (TN - TP) * TP1 / real(K)
               K = K + 1
               go to 711
            end if
  712    continue
      else
         IGFLG = -3
      end if
      DISADJ = HH
      TP1 = (TP - TN) / XI(1)
      if (TP1 .lt. CP25) then
         K = 1
         if (TP1 .lt. CMP75) K = 2
         TSPECS(1) = TN - XI(K)
         TSPECS(2) = 2.D0*(TN - TSPECS(1))
         call SIVAIN(TSPECS(1), Y, F, KORD)
         do 713 J = 1, NY
            Y(NYNY + J - 1) = Y(J)
  713    continue
c          Move difference tables back one step
         TN = TSPECS(1)
  714    call SIVABU(F, KORD)
         if (K .eq. 2) then
            KSC = max(KSC - 1, 1)
            do 715 K = max(1, KSC), IOP11-1
               BETA(K+1) = BETA(K) * (XI(K) / (XI(K+1) - XI(1)))
  715       continue
            K = 0
            go to 714
         end if
      end if
c      Take step to discontinuity.
      HH = (TP - TN)
      EREP = -abs(EREP)
      KIS = 1000
      LDIS = 1
      LSC = 0
      LINC = 0
      HINCC = C1P125
      KSSTRT = KSTEP + 2
      go to 1115
c ********
c INITIALIZE FOR STARTING AN INTEGRATION
c ********
  720 IGFLG = 0
  725 HH = TSPECS(2)
      LSC = 8
      LINC = -5
      LINCD = 64
      LDT = -4
      KQMAXI = 0
      EIMIN = CP3
      EAVE = C10
      XI(1) = C0
      IGFLG = 0
      KIS = 0
c GO COMPUTE INITIAL DERIVATIVES
  730 KORD2I = -6
c$$   COL1(VAREQ, 1)
      ICF = NE
  740 KORD1I = KPRED
      go to 1360
c   RETURN AFTER COMPUTING INITIAL (OR NOISE TEST) DERIVATIVES
  750 continue
c$$   COL1(VAREQ)
      if (IOP18 .eq. 0) go to 790
c.    **** SPECIAL LOGIC TO COMPUTE VARIATIONAL DERIVATIVES
  760 if (KORD1I .eq. 3) go to 770
      KORD1I = 3
      KORD(3) = 0
  770 if (ICF .eq. NTE) go to 790
      ICS = ICF + 1
  780 KORD(3) = KORD(3) + 1
      ICF = IOP18 + KORD(3)
      ICF = abs(KORD(ICF))
      if (ICF) 1360, 780, 1360
c$$   COL1(VAREQ,0)
  790 ICS = 1
      ICF = NE
c$$   COL1(VAREQ,1)
      if (KORD2I .eq. 0) if (EREP) 2220, 2220, 1430
      if (LINC + 5) 1490, 810, 1490
c END OF SPECIAL CODE FOR INITIALIZATION AT THE START
c ********
c UPDATE VARIABLES TO PREPARE FOR NEXT STEP
c ********
  800 LDT = 0
      EIMIN = C2P5M3+EIMIN*(C6*EAVE+EIMAX)/((EIMIN+C1)*(C6*EIMAX+EAVE))
  810 do 820 J = 1, NY
  820    Y(NYNY + J - 1) = Y(J)
      TN = TSPECS(1)
c ********
c TEST FOR VARIOUS TYPES OF OUTPUT
c ********
c     TEST FOR END OF STEP OUTPUT (OR IF DUMP OUTPUT TO BE TESTED FOR)
      if (IOP6 .eq. 0) go to 840
c   SET UP FOR END OF STEP OUTPUT
      KORD1I = 6
      go to 1810
c     SET UP AFTER OTHER COMPUTATIONS HAVE BEEN MADE (TSPECS(1).NE.TN)
  830 KORD1I = 6
      go to 860
c     TEST FOR AN OUTPUT POINT
  840 if (HH * (TMARK - TN)) 1760, 1760, 850
c     TEST FOR TOO MANY STEPS OUTPUT
  850 continue
      if (KSOUT .gt. KSTEP) go to 890
      KORD1I = 4
  860 if (TSPECS(1) .eq. TN) go to 1810
c     GO INTERPOLATE VALUES AT END OF LAST STEP
  870 TSPECS(1) = TN
      go to 1780
c     CONTINUE AFTER TOO MANY STEPS OUTPUT
  880 continue
      KSOUT = KSTEP + IOP4
  890 continue
c$$   COL1(DUMP)
      if (IOP9 .eq. 0) go to 920
c$$   COL1( (DUMP.AND.STIFF) )
c     KQMXDS=KQMAXD
c$$   COL1(DUMP)
      KQMXIS = KQMAXI
      KIS = KIS + 1
      if (KIS .ne. 0) go to 920
c.   TIME TO DUMP THE SOLUTION
  900 KORD1I = 9
c.    SET TO UPDATE THE DIFFERENCE TABLE
      if (LDT .eq. 1) go to 1810
      LDT = -2
      go to 1780
c$$   COL1(DUMP,0)
c RETURN AFTER DUMPING THE SOLUTION
  910 continue
c$$   COL1(DUMP)
      KIS = 2
c.    TEST IF SOLUTION DUMP DUE TO RESTART, END, OR
c.    DROP IN INTEG. ORDER
      if (LINC .lt. 0) if (LINC + 6) 1860, 1750, 1180
c$$   COL1(DUMP, 0)
c END OF TESTING FOR VARIOUS TYPES OF OUTPUT
c   TEST IF STEPSIZE MAY BE INCREASED OR IF TESTS SHOULD BE MADE
c   FOR DECREASING THE STEPSIZE (OR IF STARTING OR USER SELECTING H)
  920 KSTEP = KSTEP + 1
      if (LINC) 930, 980, 940
  930 continue
c     **** ONLY POSSIBLE VALUES AT THIS POINT ARE
c          LINC = -2 OR -5
      if (LINC + 5) 1120, 1110, 1120
c ********
c ERROR ESTIMATES INDICATE STEPSIZE CAN BE INCREASED
c ********
  940 HC = HINCC
      if (LINC .gt. 1) HC = HC ** LINC
      HH = HC * HH
c     TEST IF NEW STEPSIZE IS TOO BIG
      if (abs(HH) .gt. HMAX) if (HMAX) 970, 970, 960
  950 EAVE = EIMAX
      ROBND = CP3 + HINCC
      go to 1110
c     NEW STEPSIZE IS TOO BIG
  960 if (abs(XI(1)) .ge. HMAXP9) go to 970
      HH = sign(HMAX, HH)
      go to 950
c     RESTORE THE OLD STEPSIZE
  970 HH = XI(1)
      LINC = 0
      go to 1150
c END OF CODE FOR CASE WHEN ERROR ESTIMATES INDICATE STEPSIZE INCREASE
c ********
c TEST IF ESTIMATED ERRORS INDICATE STEPSIZE SHOULD BE DECREASED
c ********
  980 ROBND = C1P3
      if (EIMAX .le. EAVE) go to 990
      EAVE = EAVE + CP4 * (EIMAX - EAVE)
      if ((EIMAX * EMAX) - C1M3) 1000, 1010, 1010
  990 EAVE = EIMAX
      if ((EIMAX * EMAX) .ge. EIMIN) go to 1010
 1000 ROBND = CP3 + (SIGMA(KQMAXS)/SIGMA(KQMAXS-1))
      go to 1180
c     TEST IF STEPSIZE SHOULD BE REDUCED
 1010 if (EMAX * EIMAX .lt. EXR * EAVE) go to 1180
c ********
c ERROR ESTIMATES INDICATE STEPSIZE SHOULD BE REDUCED
c ********
      HC = HDEC
      if (EIMIN .le. EIMINO) go to 1030
      EIMIN = EIMINO
      HC = CP875
 1030 HH = HC * XI(1)
      if (LSC - 1) 1040, 1080, 1090
 1040 if (abs(HH) .ge. HMIN) go to 1090
      if (abs(CP875*XI(1)) .le. HMIN) if (LINC) 1050, 970, 970
      HH = sign(HMIN, HH)
      go to 1090
c     STEPSIZE IS TOO SMALL TO BE REDUCED
c     SET UP ERROR INDICATORS AND PREPARE FOR RETURN TO USER
 1050 KORD1I = 8
      go to 2240
c     PROCEED WITH CURRENT STEPSIZE DESPITE ERROR BEING TOO BIG
 1070 HH = XI(1)
      TSPECS(2) = HH
      EMAX = C0
      LINC = 0
      if (KORD1I - 2) 1420, 1430, 1430
c     SET LSC TO END STARTING PHASE
 1080 LSC = 2
c     CHECK IF REPEATING A STEP
 1090 if (LINC .ne. -1) go to 1110
c   WHEN REPEATING A STEP, BACK UP THE DIFFERENCES AND STEPSIZE INFO.
 1100 call SIVABU(F, KORD)
c   TEST IF NOISE TEST (LINC = -7) OR IF H IS NOT
c     BEING CHANGED (LINC = -4)
      if (LINC + 4) 1780, 1180, 1110
c ********
c STEPSIZE IS TO BE CHANGED
c ********
 1110 continue
c MODIFY STEPSIZE TO REDUCE ROUNDOFF ERROR IN ACCUMULATING INDEP. VAR.
      TP = C2 * abs(TN) + C4096 * abs(HH)
      TP = (TP + abs(HH)) - TP
      if (TP .ne. C0) HH = sign(TP, HH)
c     TEST IF NEW STEPSIZE SELECTED ACTUALLY GIVES A CHANGE
      if (HH .eq. TSPECS(2)) go to 1140
 1115 TSPECS(2) = HH
      if (IOP8 .eq. 0) go to 1140
c     SETUP TO TELL USER ABOUT STEPSIZE CHANGE (OR TO CHANGE STEPSIZE)
 1120 KORD1I = 8
      go to 860
c     RETURN AFTER TELLING USER ABOUT STEPSIZE CHANGE
 1130 HH = TSPECS(2)
 1140 if (HH .ne. XI(1)) KQICON = -1
 1150 HC = min(EOVEP2, abs(HH)) / EEPS2
c ********
c PREPARE FOR BEGINNING A NEW STEP
c ********
      if (LINC .gt. 0) then
         LINC = min(LINC, LINCQ) + LINCQ
         go to 1190
      end if
 1180 LINC = LINCD
 1190 if (HC .gt. abs(TN)) go to 1200
c     **** GIVE SINGULARITY DIAGNOSTIC
      KORD1I = 5
      go to 2240
 1200 TSPECS(1) = TN + HH
      if (LEX .eq. 0) go to 1250
      if (HH * (TSPECS(1) - TMARKX) .lt. C0) go to 1250
      TSPECS(1) = TMARKX
      HH = TMARKX - TN
      LINC = 64
      if (LEX .gt. 0) go to 1240
      if ((LSC .lt. 4) .and. (HH / XI(1) .lt. CP3)) go to 1230
 1220 HH = CP875 * HH
      go to 1110
c     **** GIVE OUTPUT AT CURRENT TMARK (WITH EXTRAPOLATION)
 1230 KORD1I = -KMARK
      go to 1770
c     **** INTEGRATE TO TMARKX
 1240 KQICON = -1
c   TEST IF SUBROUTINE FOR COMPUTING INTEGRATION COEFF. SHOULD BE CALLED
 1250 continue
c$$   COL1(STIFF,1,1)
c     IF ((KQMAXI .LT. KQICON) .OR. (KQMAXD .LT. KQDCON)) GO TO 1320
      if (KQMAXI .lt. KQICON) go to 1320
c   GO COMPUTE COEFFICIENTS REQUIRED FOR THE INTEGRATION
c     TEST IF STARTING
      if (LSC .lt. 7) go to 1310
 1260 KQMAXI = 2
c$$   COL1(STIFF)
c     IF (METHOD) 1262,1270,1264
c1262 KQMAXI=0
c1264 KQMAXD=max(MAXDIF,2)
c     CALL SIVAHC
c.  SET UP TO GO DO INITIALIZATION FOR CASE OF STIFF EQUATIONS
c     KORD1I=5
c     GO TO 1350
c$$   COL1(STIFF,0)
c   INITIALIZE FOR EQUATIONS WHICH ARE NOT STIFF
 1270 KQMAXD = 0
      call SIVAHC
      J = NDTF
      do 1300 I = 1, NTE
         if (KORD(I + 3) .le. 0) go to 1290
         KORD(I + 3) = 1
c     INITIALIZE THE DIFFERENCE TABLE
         if (LDT .eq. -4) F(J) = F(I)
         F(J + 1) = C0
         F(J + 2) = C0
 1290    continue
         J = J + NUMDT
 1300    continue
      if (LSC .eq. 5) go to 1340
      LSC = 7
      LDT = 1
      go to 1330
c   INTEGRATION IS NOT BEING STARTED
 1310 K = KORD(KEMAX + 3)
      SIGMAS = SIGMA(K)
      call SIVAHC
c     **** ADJUST EAVE
      TPS1 = BETA(K)
      if (TPS1 .gt. C1) TPS1 = CP5 * TPS1 + CP5
      EAVE = EAVE * TPS1 * (SIGMA(K) / SIGMAS)
c     TEST BELOW USED TO GET SAME RESULTS WITH/WITHOUT EXTRA EQUATIONS
      if (K .gt. KQICON) LSC = max(LSC, -3)
c END OF SPECIAL LOGIC FOR CASE WHEN INTEG. COEFF. ROUTINE IS CALLED
 1320 continue
c ********
c PREDICT Y
c ********
 1330 continue
c$$   COL1( (.NOT. ARGM),1,1)
      call SIVAPR(Y, Y(NYNY), F, KORD)
c     CALL SIVAPE
c     GO GET PREDICTED DERIVATIVES
 1340 KORD1I = KPRED
c ********
c CALL DERIVS  (OR RETURN)
c ********
 1350 KORD2I = 0
 1360 KORD(1) = KORD1I
      KORD(2) = 0
      if (IOP13 .ne. 0) return
      call DERIVS(TSPECS(1), Y, F, KORD(1))
c     TEST FOR SPECIAL USER RETURN
 1380 if (KORD(1) .lt. 0) go to 2130
c     TEST FOR SPECIAL CASE
      if (KORD2I .ne. 0) go to 660
c ********
c TRANSFER CONTROL TO PROPER PLACE AFTER COMPUTING DERIVATIVES
c ********
      if (KORD1I - 2) 1400, 800, 1390
 1390 continue
c$$   COL1(VAREQ,1)
      if (ICS - ICF) 1410, 1410, 760
c ********
c PREPARE FOR CORRECTING, AND CORRECT Y
c ********
 1400 ITOLEP = 0
      ILGREP = 0
      IY = 1
      EIMAX = C1M5
      EMAX = C0
      KQMAXI = 2
      KQMAXS = 2
c$$   COL1(STIFF)
c     IF (METHOD) 1404,1410,1406
c1404 KQMAXI=0
c1406 KQMAXD=2
c$$   COL1(STIFF,0)
 1410 continue
c$$   COL1( (.NOT. ARGM),1,1)
      call SIVACR(Y, F, KORD, F(NTOLF), KORD(IOP16))
c     CALL SIVACE
c     TEST IF ESTIMATED ERROR IS TOO BIG (OR IF DIAGNOSTIC CALLED FOR)
      if (EMAX .gt. EREP) if (EREP) 2210, 2210, 1670
 1420 continue
c$$   COL1(VAREQ,1)
      if (IOP18 .ne. 0) go to 760
 1430 KORD1I = 2
c     TEST IF NOISE APPEARS TO LIMIT PRECISION
      if (EMAX .lt. C0) go to 1470
c$$   COL1( (.NOT. STIFF),1,1)
      if (LSC) 1450, 1360, 1610
c     IF (LSC) 1450,1460,1610
c     SET LSC=0 IF NOISE NO LONGER APPEARS TO LIMIT PRECISION
c     OR IF THE END OF THE STARTING PHASE HAS BEEN REACHED
 1450 LSC = 0
 1460 if (METHOD) 800, 1350, 1350
c ********
c NOISE APPEARS TO BE LIMITING PRECISION
c ********
 1470 continue
      if (LSC .le. 0) LSC = LSC - 1
      if (LSC .eq. -1) go to 1460
      if (abs(EMAX) .lt. EXR) go to 1590
      LINC = -7
      TPS2 = (C1 + BETA(NOISEQ - 1)) ** NOISEQ
      if (SNOISE .lt. EEPS10 * TPS2) go to 1550
      TP = sign(EEPT75 * abs(TN) + OVTM75, HH)
      if (abs(TP) .gt. abs(HH)) go to 1550
      TSPECS(1) = TN + TP
      KORD1I = 0
c     **** GO TO BACK UP THE DIFFERENCES AND GET F(TSPECS(1))
      go to 1100
c     **** SOLUTION HAS BEEN INTERPOLATED AND F COMPUTED
 1490 continue
c     WRITE(6,9999) TN,F(NDTF+KEMAX*NUMDT-NUMDT, KSTEP,KEMAX,NOISEQ,
c    1   BETA(NOISEQ),TSPECS(1),F(KEMAX),SNOISE,DNOISE,
c    2   (Y(IO), IO = 1,NY), (Y(NYNY+IO-1), IO = 1, NY)
c9999 FORMAT('1TN=',1PD25.18,'  DT =',D25.18,'  KSTEP =' ,I4,
c    1   '  KEMAX =', I2, '  NOISEQ =', I2, '  BETA =',D15.8/
c    2   '  T=',D25.18, '   F =', D25.18, '  SNOISE=' E15.8,
c    3   '  DNOISE =', E15.8/'  Y=', 2(4E26.18/4X))
      KORD1I = 0
      LINC = LINC - 1
      if (LINC + 9) 1510, 1520, 1500
 1500 TSPECS(1) = TN + (TP + TP)
      TP1 = F(KEMAX)
      TP2 = F(NDTF + NUMDT * KEMAX - NUMDT)
      go to 1780
c     **** COMPUTE 2-ND DIFFERENCE AT CLOSE SPACED T VALUES
 1510 TP2 = TP3
 1520 TP3 = F(KEMAX)
      TPS1 = abs((TP3 - TP1) - (TP1 - TP2))
      if ((C16 * TPS1 * TPS2) .ge. DNOISE) if (LINC + 9) 1550, 870, 1550
 1530 TPS1 = EEPS10
      TPS2 = CP25 * SNOISE / RBQ(NOISEQ)
      do 1540 K = 2, NUMDT
         TPS1 = TPS1 + TPS1
         RBQ(K) = max(TPS1, TPS2 * RBQ(K))
 1540    continue
      LINC = 0
      HH = CP875 * HH
      go to 1040
c     **** SET UP TO GIVE NOISE DIAGNOSTIC
 1550 KORD1I = 6
      go to 2240
c     **** AFTER GIVING NOISE DIAGNOSTIC
 1560 KORD1I = 2
      if (KORD(2) .ge. 0) go to 1530
c     **** SET NEW VALUE FOR OFFENDING TOL
      F(NTOLF + ITOLEP - 1) = FDAT(7)
      if (LINC + 7) 1180, 1570, 1180
 1570 LINC = 0
 1580 if (LSC) 1460, 1460, 1610
c     **** CHANGE HINCC AND ADJUST SIGMA( )
 1590 if (LSC .ne. -4) go to 1580
      if (HINCC .eq. C1P125) go to 1580
      TPS1 = C1P125 / HINCC
      TPS2 = 1.0
      do 1600 K = 2, IOP11
         TPS2 = TPS2 * TPS1
         SIGMA(K) = SIGMA(K) * TPS2
 1600    continue
      EAVE = EAVE / TPS2
      LINCD = 6
      LINCQ = 12
      HINCC = C1P125
      go to 1460
c   END OF CODE FOR CASE WHEN NOISE APPEARS TO LIMIT PRECISION
c ********
c SPECIAL LOGIC FOR STARTING THE INTEGRATION
c ********
 1610 if (LSC .eq. 1) go to 800
      LSC = LSC - 1
      if (LSC - 2) 1620, 1640, 1650
 1620 if (EIMAX .le. (CP0625*EAVE*(SIGMA(KQMAXS)/SIGMAS)*(BETA(KQMAXS+
     1   1))**2)) go to 800
 1630 KSSTRT = KSTEP + 2
c   TEST IF STEPSIZE IS TOO SMALL BEFORE ENDING STARTING PHASE
      if (abs(HH) .ge. HMIN) go to 1450
c     GIVE DIAGNOSTIC FOR STEPSIZE TOO SMALL AT END OF START
      KORD1I = 7
      go to 2240
c   SET LSC TO DO ONE DERIVATIVE EVAL. PER STEP
 1640 LSC = 1
      go to 800
c     TEST IF FIRST TIME THROUGH THE FIRST STEP
 1650 if (LSC .eq. 6) go to 1340
c     END STARTING PHASE IF CONVERGENCE OF CORRECTOR ITERATES TOO SLOW
      if (LDT .eq. -5) go to 1660
      LSC = min(LSC, 4)
      go to 800
 1660 LDT = 0
      if (LSC - 4) 1260, 1630, 1260
c END OF SPECIAL LOGIC FOR STARTING THE INTEGRATION
c ********
c ESTIMATED ERROR IS TOO BIG
c ********
 1670 if (BETA(2) - C1) 1690, 1730, 1680
 1680 HC = C1 / BETA(2)
      if (BETA(2) .ge. C1P125) go to 1740
 1690 if (BETA(2) .gt. CP3) go to 1730
c   REQUIRED STEPSIZE REDUCTION IS TOO RAPID -- GIVE A DIAGNOSTIC
      KORD1I = 4
      go to 2240
c
c     TEST KORD(2) AFTER ABOVE DIAGNOSTIC OR A DISCONTINUITY DIAGNOSTIC
 1700 continue
      if (KORD(2) .eq. 0) go to 1730
c  TEST IF SOLUTION MUST BE DUMPED BEFORE A RESTART
 1710 LINC = -1
c$$   COL1(DUMP)
      if (IOP9 .eq. 0) go to 1750
      if (KIS .eq. 2) go to 1750
      LINC = -6
c.    GO DUMP SOLUTION BEFORE REPEATING THE STEP
 1720 KQMAXI = KQMXIS
c$$   COL1( (DUMP .AND. STIFF) )
c     KQMAXD=KQMXDS
c$$   COL1(DUMP,2)
      call SIVABU(F, KORD)
      go to 900
c   SET UP TO REPEAT THE STEP
 1730 HC = CP5
 1740 LINC = -1
      if (LSC .le. 3) go to 1030
c   RESTART THE INTEGRATION IF ERROR IS TOO BIG ON FIRST OR SECOND STEP
c LOOP TO SELECT A NEW INITIAL STEPSIZE
 1750 LSC = 7
 1755 HH = HH * CP5
      EMAX = EMAX * CP25
      if (EMAX .ge. CP3) go to 1755
      go to 1090
c   END OF SELECTING A NEW INITIAL STEPSIZE
c END OF LOGIC FOR CASE WHEN ESTIMATED ERROR IS TOO BIG
c ********
c INTEGRATION HAS REACHED AN OUTPUT POINT
c ********
 1760 if (KMARK .eq. 0) go to 1920
      KORD1I = min(KMARK, 5)
      KORD(3) = KMARK
      if (TSPECS(1) .eq. TMARK) go to 1790
 1770 TSPECS(1) = TMARK
 1780 call SIVAIN(TSPECS(1), Y, F, KORD)
 1790 continue
      if (KORD1I) 1800, 730, 1810
c   OUTPUT POINT IS OBTAINED BY EXTRAPOLATION
 1800 continue
c$$   COL1(EXTRAP)
      KORD1I = -KORD1I
      KORD2I = -7
      KEXIT = 4
c.  TEST IF GSTOP-S ARE PRESENT
c$$   COL1(EXTRAP .AND. GSTOP)
      if (NGTOT .eq. 0) go to 1820
      IGFLG = 4
      KEXIT = 2
      KORD1I = 7
      if (IOP7) 740, 1820, 740
c$$   COL1(EXTRAP .AND. GSTOP,0)
c ********
c CALL OUTPUT  (OR RETURN)
c ********
 1810 KORD2I = 1
 1820 KORD(1) = KORD1I
      KORD(2) = 1
      if (IOP14 .ne. 0) return
      call OUTPUT(TSPECS(1), Y, F, KORD(1))
c     TEST FOR SPECIAL USER RETURN OR FOR A RESTART
c$$   COL1(.NOT. DUMP, 1, 100)
c1840 IF (KORD(1)) 2130,700,1880
 1840 if (KORD(1) .gt. 0) go to 1880
 1850 if (IOP9 .eq. 0) go to 1870
c.    **** GO DUMP THE SOLUTION
      LINC = -7
      ITOLEP = KORD(1)
      IDAT(1) = KORD(2)
      NEPTOL = KORD1I
      go to 900
 1860 LINC = min(0, LINCD)
      KORD1I = NEPTOL
      KORD(1) = ITOLEP
      KORD(2) = IDAT(1)
 1870 if (KORD(1)) 2130, 700, 2100
c$$   COL1(DUMP, 0)
 1880 if (KORD2I .lt. 0) go to (2140, 1810, 1350, 2110, 720, 750, 680,
     1   710), -KORD2I
      if (KORD2I .eq. 0) go to 1380
c ********
c TRANSFER CONTROL TO PROPER PLACE AFTER OUTPUT
c ********
 1890 if (KORD1I - 5) 1910, 1930, 1900
 1900 if (KORD1I - 8) 840, 1130, 910
 1910 if (KORD1I - 3) 1920, 1930, 880
c   GET NEW TOUT
 1920 TOUT = TSPECS(1) + TSPECS(3)
c GET NEW TMARK (NEXT INDEP. VAR. OUTPUT POINT)
 1930 TP = TMARK
      K = KMARK
      TMARK = TOUT
      KMARK = 2
      LEX = 0
      if (IOP5) 1940, 1980, 1970
 1940 I = -IOP5
 1950 I = I + 3
      J1 = KORD(I - 3)
      if (J1) 1950, 1980, 1960
 1960 J2 = KORD(I - 2)
      L = KORD(I - 1)
      go to 1990
 1970 J1 = 5
      J2 = IOP5
      L = 0
      if (J2 .ge. J1) go to 1990
 1980 J1 = 4
      J2 = 4
      L = IOP3
c
c     **** LOOP TO SET NEW TMARK (AND TMARKX)
 1990 do 2060 J = J1, J2
c        **** TEST IF EXTRAPOLATION NOT POSSIBLE
         if (L .eq. 0) go to 2010
         LX = 2
         if (LEX) 2020, 2030, 2020
 2000    LEX = L
 2010    LX = 1
 2020    if (HH * (TSPECS(J) - TMARKA(LX))) 2030, 2060, 2060
 2030    if (J .eq. 4) go to 2050
         if (HH * (TSPECS(J) - TP)) 2060, 2040, 2050
 2040    if ((K .ge. J) .or. (K .eq. 3)) go to 2060
 2050    TMARKA(LX) = TSPECS(J)
         if (LX .eq. 2) go to 2000
         KMARK = J
 2060    continue
      if (IOP5 .lt. 0) go to 1950
      if (J1 .ne. 4) go to 1980
      if (KMARK .eq. 4) KMARK = 3
c     **** TEST IF NEW TMARK IS ACCEPTABLE
      if (HH * (TP - TMARK)) 2070, 2080, 2090
 2070 if (KORD2I - 1) 670, 840, 670
 2080 if (K .ne. KMARK) go to 2070
c$$   COL1(DUMP, 1, 1)
      if (KORD1I .eq. 3) if (KORD2I + 5) 1850, 2100, 1850
c     IF (KORD1I .EQ. 3) GO TO 1400
 2090 if (KORD1I .eq. 13) go to 2190
c SETUP TO INDICATE ERROR IN SPECIFICATION OF OUTPUT POINTS
      KORD1I = 2
      IDAT(2) = KMARK
      if (KMARK .le. 3) IDAT(2) = KMARK + 1
      FDAT(3) = TSPECS(IDAT(2))
      go to 2240
c     SET KORD1I=1 TO INDICATE THAT END OF INTEGRATION HAS BEEN REACHED
 2100 KORD1I = 1
c ********
c RETURN TO USER
c ********
 2110 KORD2I = -1
      KORD(1) = KORD1I
 2130 KORD(2) = -1
      return
c ********
c TRANSFER CONTROL TO PROPER PLACE AFTER RETURN TO USER
c ********
 2140 if (KORD1I - 2) 2150, 1560, 2160
 2150 KORD2I = 1
      go to 1930
 2160 if (KORD1I - 4) 1700, 2200, 2170
 2170 if (KORD1I - 13) 2180, 1930, 2190
 2180 if (abs(HH) .ge. HMIN) if (KORD1I - 11) 1030, 1450, 1030
      if (KORD(2) .eq. 0) if (KORD1I - 11) 1070, 800, 1070
c   ERROR MESSAGES HAVE BEEN IGNORED -- COMPUTATION CAN NOT CONTINUE
 2190 KORD1I = 1
      go to 2240
c
c        AFTER A DISCONTINUITY RETURN
 2200 LINC = -4
      if (KORD(2)) 1710, 1730, 1100
c ********
c PROBLEM ENCOUNTERED WHEN CORRECTING
c ********
 2210 if (LDIS .eq. 0) go to 2230
c           Extra checks when had a user specified discontinuity.
c$$   COL1(VAREQ,1)
      if (IOP18 .ne. 0) go to 760
 2220 KORD1I = 2
      LDIS = LDIS + 1
      TP = DISADJ / HH
      if (KIS .ge. 1000) then
         if (LDIS .eq. 2) then
            HH = HH*min(TP, TP**2, (CP25 * EXR/EMAX)**.333333333E0)
            if (KQMAXI .le. 3) then
               LDIS = 0
               EREP = abs(EREP)
               TSPECS(2) = HH
               go to 725
            end if
            LINC = -5
            if (IOP9 .eq. 0) KIS = 1001
            go to 800
         end if
         if (IOP9 .eq. 0) KIS = KIS + 1
         if (KQMAXI .le. LDIS + 2) KIS = LDIS + 1
         LINC = min(LINC, LDIS-2)
      end if
      if (LDIS .gt. 2*KQMAXI) then
         EREP = abs(EREP)
         LDIS = 0
         if (EMAX .gt. EREP) go to 1670
         go to 1430
      end if
      if (TP .ge. HINCC**(LINC+2)) then
         if ((LDIS .ne. 3) .and. (TP .gt. real(KQMAXI))) LSC = 1
         EIMIN = CP5
         EAVE = EAVE * TP**8
      end if
      if (LSC .eq. 2) go to 1630
      if (EMAX .gt. EXR) go to 1730
      go to 1430
c
 2230 EREP = abs(EREP)
c$$   COL1(DUMP,1)
      if (LINC .lt. -3) go to 1720
c     BAD TOL
      KORD1I = 3
c ********
c ERROR PROCESSING
c ********
 2240 FDAT(1) = TSPECS(1)
      FDAT(2) = HH
      IDAT(1) = KSTEP
      ITOLEP = max(NEPTOL, -NEPTOL - 1)
      J = 3
      if (KORD1I .ge. 7) then
         J = 4
         FDAT(3) = HMIN
      end if
      if (KORD1I .le. 3) then
         if (KORD1I .lt. 3) then
            K = 8
         else
            MACT(9) = LTXTAL
            FDAT(3) = C0
            IDAT(2) = ITOLEP
            IDAT(3) = ITOLEP + NTOLF - 1
            K = 11
         end if
      else
         MACT(9) = LTXTAK
         FDAT(J) = EMAX
         IDAT(2) = KEMAX
         IDAT(3) = ITOLEP
         IDAT(4) = ITOLEP + NTOLF - 1
         FDAT(J+1) = F(IDAT(4))
         K = 14
         if (KORD1I .eq. 6) then
            K = 17
            IDAT(5) = IDAT(4)
            FDAT(7) = 32.E0 * abs(EMAX) * FDAT(J+1)
            FDAT(J+2) = FDAT(7)
         end if
         MACT(12) = LTXTAL
         if (NEPTOL .lt. 0) then
            MACT(12) = LTXTAM
            IDAT(6) = IDAT(4)
            IDAT(5) = IDAT(4) + 1
            FDAT(J+2) = F(IDAT(5))
            FDAT(J+3) = FDAT(J+1) * FDAT(J+2)
         end if
      end if
c Set the location for the first part of the message that varies, set
c the error severity, and the index number, print the error and
c return or stop.
      L = MLOC(KORD1I)
      MACT(6) = L / LOCM
      MACT(2) = (L - MACT(6) * LOCM) / 32
      KORD1I = mod(L, 32)
      MACT(3) = KORD1I
      MACT(K) = MERET
      call SMESS(MACT, MTEXT, IDAT, FDAT)
      MACT(K) = MENTXT
      go to 2110
c
c 
c
c$$   END      OF -IVAA INTEGRATION SUBROUTINE
      end
c$$   START( SIVABU, ROOT = 'SIVA', $ROOT$BU)
c>> 1987-12-07 SIVABU Krogh   Initial code.
      subroutine SIVABU(F, KORD)
c  ======= THIS PROGRAM HAS BEEN SPECIALIZED ==========
c THIS SUBROUTINE RESTORES THE DIFFERENCE TABLE TO ITS STATE
c AT THE BEGINNING OF THE CURRENT STEP.  IF THE INTEGRATION ORDER
c WAS INCREASED, IT IS REDUCED. THE COMMON ARRAY XI IS ALSO
c RESTORED TO ITS STATE AT THE BEGINNING OF THE STEP. IF THE
c STEPSIZE IS NOT BEING CHANGED, THE ARRAY V USED TO COMPUTE
c INTEGRATION COEFFICIENTS IS RESTORED.
c
      real             F(*)
      integer KORD(*)
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6)
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c
      real             TPD, C0, C2
      parameter (C0 = 0.E0)
      parameter (C2 = 2.E0)
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
c ********* START OF EXECUTABLE CODE **********
c
c ********
c BEGIN LOOP TO BACK UP DIFFERENCE TABLES
c ********
      L = NDTF - 1
      do 2410 I = 1, NTE
         KQQ = KORD(I + 3)
c$$   COL1(STIFF)
c        IF (KQQ) 2302,2400,2310
c.           EQUATION IS STIFF
c2302    IF (LINC.GE.0) GO TO 2310
c        IF (F(L+1+I)) 2306,2308,2304
c.     ORDER WAS INCREASED, AND THUS MUST BE DECREASED (KQQ.LT.0)
c2304    KQQ=KQQ+1
c        KORD(I+3) = KQQ
c        GO TO 2308
c.     ORDER WAS DECREASED
c2306    KQQ=KQQ-1
c2308    KQQ=max(2,-KQQ)
c        GO TO 2350
c$$   COL1(STIFF,0)
c     EQUATION IS NOT STIFF
 2310    if (KQQ .gt. 2) then
            if (F(L + KQQ) .eq. C0) then
c                 ORDER WAS INCREASED, AND THUS MUST BE DECREASED
               KQQ = KQQ - 1
               KORD(I + 3) = KQQ
            end if
         end if
         J = min(KQQ, KSC)
         KQMAXI = max(KQMAXI, KQQ)
         if (KQQ .ne. 1) F(L + KQQ + 1) = 0.
c           BACK UP FOR BACKWARD DIFFERENCES
         do 2360 K = 1, J
            F(L + K) = F(L + K) - F(L + K + 1)
 2360    continue
         if (KQQ .gt. KSC) then
c           BACK UP FOR MODIFIED DIVIDED DIFFERENCES
            do 2390 K = J+1, KQQ
               F(L + K) = (F(L+K) - F(L+K+1)) / BETA(K)
 2390       continue
         end if
 2400    F(L + KQQ + 1) = F(L + KQQ + 1) / BETA(KQQ + 1)
         L = L + NUMDT
 2410 continue
c END OF LOOP TO BACK UP DIFFERENCE TABLES
c ********
c BACK UP XI TO BEGINNING OF THE STEP
c ********
      I = KSC + 1
      if (I - IOP11 - 1) 2420, 2440, 2450
 2420 TPD = XI(1)
c                Check below needed when starting?
      if (TPD .eq. XI(2)) go to 2450
      do 2430 K = I, IOP11
 2430    XI(K - 1) = XI(K) - TPD
 2440 XI(IOP11) = C2 * XI(IOP11 - 1)
      if (IOP11 .ne. 2) XI(IOP11) = XI(IOP11) - XI(IOP11 - 2)
 2450 KQICON = -1
      ICF = NE
      ICS = 1
      LDT = 1
      return
c$$   END  OF -IVABU INTEGRATION PROGRAM
      end
c$$   START(SIVACO,ROOT = 'SIVA',$ROOT$C0)
c>> 1987-12-07 SIVACO Krogh   Initial code.
      subroutine SIVACO(ID, RD)
c
c ========== THIS PROGRAM HAS BEEN SPECIALIZED ==========
c
c THIS SUBROUTINE RETURNS THE FOLLOWING DATA FROM COMMON
c ID(1) = KEMAX  =  INDEX OF EQUATION WITH LARGEST ERROR ESTIMATE
c ID(2) = KSTEP  =  CURRENT STEP NUMBER
c ID(3) = NUMDT  =  NUMBER OF DIFFERENCES USED FOR EACH EQUATION
c ID(4) =           RESERVED FOR FUTURE USE
c ID(5) =           RESERVED FOR FUTURE USE
c RD(1) = EMAX   =  MAX. RATIO OF ESTIMATED ERROR TO REQUESTED ERROR
c RD(2) =           RESERVED FOR FUTURE USE
c RD(3) =           RESERVED FOR FUTURE USE
c
      integer ID(5)
      real             RD(3)
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6)
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
c
      ID(1) = KEMAX
      ID(2) = KSTEP
      ID(3) = NUMDT
      RD(1) = EMAX
      return
c$$   END OF  -IVACO INTEGRATION SUBROUTINE
      end
c$$   START(SIVACR,ROOT = 'SIVA',$ROOT$CR)
c>> 1988-08-25 SIVACR Krogh   Fix bug in relative error test.
c>> 1988-01-15 SIVACR Krogh   Initial code.
      subroutine SIVACR(Y, F, KORD, TOL, LGROUP)
c
c ========== THIS PROGRAM HAS BEEN SPECIALIZED ==========
c THIS SUBROUTINE
c   1. CORRECTS Y FOR EQUATIONS WHICH ARE NOT STIFF
c   2. ESTIMATES ERRORS
c   3. SELECTS INTEGRATION ORDERS
c   4. TESTS IF NOISE LIMITS THE PRECISION
c
c     Y = VECTOR OF PREDICTED VALUES ON ENTRY, AND OF CORRECTED
c         VALUES WHEN THE RETURN IS MADE.
c LGROUP= VECTOR INDICATING HOW ERROR TOLERANCES ARE TO BE GROUPED
c         (AND POSSIBLY HOW INTEGRATION ORDERS ARE TO BE GROUPED).
c   TOL = VECTOR CONTAINING ERROR TOLERANCES (AND POSSIBLY RELATIVE
c         ERROR FACTORS).
c     F = VECTOR GIVING PREDICTED DERIVATIVE VALUES AND DIFF. TABLES.
c    KD = VECTOR GIVING ORDERS OF THE DIFFERENTIAL EQUATIONS
c         (IF EQUATIONS HAVE DIFFERENT ORDERS).
c    KQ = VECTOR OF INTEGRATION ORDERS.
c
      integer LGROUP(*), KORD(*)
      real             Y(*)
      real             TOL(*), F(*)
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6)
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c
      real             CM8, CM2, CMP5, C0, CQ3125, CP1, CP125, CP25, CP5
      real             CP75, CP8, CP9375, C1, C1P4, C2, C4, C10, C20
      real             C1000, C40
      parameter (CM8 = -8.E0)
      parameter (CM2 = -2.E0)
      parameter (CMP5 = -.5E0)
      parameter (C0 = 0.E0)
      parameter (CQ3125 = .03125E0)
      parameter (CP1 = .1E0)
      parameter (CP125 = .125E0)
      parameter (CP25 = .25E0)
      parameter (CP5 = .5E0)
      parameter (CP75 = .75E0)
      parameter (CP8 = .8E0)
      parameter (CP9375 = .9375E0)
      parameter (C1 = 1.E0)
      parameter (C1P4 = 1.4E0)
      parameter (C2 = 2.E0)
      parameter (C4 = 4.E0)
      parameter (C10 = 10.E0)
      parameter (C20 = 20.E0)
      parameter (C40 = 40.E0)
      parameter (C1000 = 1000.E0)
      real             TPP, HH, E, EI, EPS, ERCOEF, RND, RNOISE, S
      real             TPS1, TPS2, TPS3, TPS4, TPS5, TPS6, TPS7
c$$   COL1(STIFF,1)
      real             REF(4)
      real             EIBND(KDIM-1)
c$$   COL1(INTEGO,1)
      real             TEMPA(4), TEMPAO(4)
c.    SPECIFICATION OF ENVIRONMENTAL CONSTANTS.
      real             EEPS10, EEPS16, EROV10, EEPS2, EEPT75, EOVEP2
      real             OVTM75, OVD10
      common / SIVAEV / EEPS2, EEPT75, EOVEP2, OVTM75, OVD10, EEPS10,
     1   EEPS16, EROV10
      save / SIVAEV /
c     real             EEPS2
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
      save LKQMAX
      equivalence (TPS1,TEMPA(1)), (TPS2,TEMPA(2)), (TPS3,TEMPA(3)),
     1   (TPS4, TEMPA(4))
      equivalence (G(1, 1), HH)
c             Parameters for Interface to MESS and SMESS
      parameter (MERET  =51)
      parameter (METEXT =53)
      parameter (METABL =55)
      character MTEXT(262)
      parameter (LTXTAA = 1)
      character MTXTAA*(48)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 49)
      character MTXTAB*(47)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      parameter (LTXTAC = 96)
      character MTXTAC*(17)
      equivalence (MTEXT(LTXTAC), MTXTAC)
      parameter (LTXTAD = 113)
      character MTXTAD*(32)
      equivalence (MTEXT(LTXTAD), MTXTAD)
      parameter (LTXTAE = 145)
      character MTXTAE*(55)
      equivalence (MTEXT(LTXTAE), MTXTAE)
      parameter (LTXTAF = 200)
      character MTXTAF*(63)
      equivalence (MTEXT(LTXTAF), MTXTAF)
      integer MACT1(2), MACT2(12)
      DATA MTXTAA/'KSTEP=$(I6) T=$(1PE15.8) H=$(1PE12.5) LSC=$(I3) '/,
     1MTXTAB/'EIMIN=$(1PE8.2) EAVE=$G KSC=$(I2) SIGMA($J)=$G '/,
     2MTXTAC/'RQ=$(1PE11.5)$G$E'/,
     3MTXTAD/'I$HKQ$HLI$HE$HEI$HEPS$HF$H$H$H$H'/,
     4MTXTAE/'HIGH ORDER PREDICTED DIFFERENCES$HRNOISE$HSTIFF$HBETA$H'/,
     5MTXTAF/
     6'(I4)(2I3)(1P3E8.1)(1PE15.7)(1P4E11.3)(1PE9.1)(1PE10.2)(1PE12.5)'/
c
      data MACT1 / METEXT, MERET /
c (F=loc. format; W=width; R=repeat) FFFWWRR  FFFWWRR  FFFWWRR
      data MACT2 / METABL, 1, 0, 14,  880401,  920302, -970803,
     1   -1061501, -1151104, -1250901, -1331001, -1421201 /
c         FFFWWRR   FFFWWRR   FFFWWRR   FFFWWRR   FFFWWRR
c          End of stuff for interface to message processor
c       
      data REF(1), REF(2), REF(3), REF(4) / C1, CP9375, CP75, CP5 /
      data EIBND(1) / .1E0 / EIBND(2) / .1E0 /, EIBND(3) / .14E0 /
      data EIBND(4) / .19E0 /
      data EIBND(5) / .26E0 /
      data EIBND(6) / .36E0 /
      data EIBND(7) / .50E0 /
      data EIBND(8) / .69E0 /
      data EIBND(9) / .94E0 /
c$$   COL1(.T., KDIMDT - 10, 21 - KDIMDT)
      data EIBND(10) / C1 /
      data EIBND(11) / C1 /
      data EIBND(12) / C1 /
      data EIBND(13) / C1 /
c     data EIBND(14) / C1 /
c     data EIBND(15) / C1 /
c     data EIBND(16) / C1 /
c     data EIBND(17) / C1 /
c     data EIBND(18) / C1 /
c     data EIBND(19) / C1 /
c     data EIBND(20) / C1 /
c
c$$   COL1(ARGM,2)
c     RETURN
c     ENTRY SIVACE
c ********
c START OF CODE
c ********
      L = NDTF - 1
      if (ICS .ne. 1) L = L + (ICS - 1) * NUMDT
      do 3340 I = ICS, ICF
         if (NKDKO .ne. 0) KORDI = KORD(NKDKO + I - 1)
         IY = IY + abs(KORDI)
         KQL = KORD(I + 3)
         KQN = abs(KQL)
         KQD = max(2, KQN)
c ********
c OBTAIN ERROR TOLERANCE SPECIFIED BY THE USER
c ********
         if (I .le. ILGREP) if (KQL) 2600, 3310, 2610
         ITOLEP = abs(ITOLEP) + 1
         EPS = TOL(ITOLEP)
         ILGREP = LGROUP(ITOLEP)
c   TEST IF SIMPLE ABSOLUTE ERROR TEST IS BEING USED
         if (ILGREP .gt. 0) go to 2580
         JLGREP = ILGREP
c     GET OLD RELATIVE ERROR FACTOR
         TPS6 = TOL(ITOLEP + 1)
         ILGREP = LGROUP(ITOLEP + 1)
         ITOLEP = -ITOLEP - 1
c
         if (JLGREP + 1) 2540, 2570, 2510
c   NO CHECK ON THE ERROR ESTIMATE IS TO BE MADE
 2510    if (EPS + C1) 2520, 2590, 2520
c   ERROR TOLERANCE IS SPECIFIED IMPROPERLY
 2520    KEMAX = I
         NEPTOL = ITOLEP
         LINC = -3
         EREP = -abs(EREP)
         return
c   COMPUTE NEW RELATIVE ERROR FACTOR
 2540    continue
         TPS1 = C0
         do 2550 J = I, ILGREP
            TPS1 = TPS1 + abs(F(J))
 2550       continue
         TPS1 = abs(HH) * TPS1 / real(ILGREP - I + 1)
         if (LSC .le. 2) go to 2560
c     ON FIRST 3 STEPS INCREASE TPS6 WHEN COMPUTING REL. ERROR FACTOR
         TPS6 = max(C4 * TPS1, TPS6)
c     ON 1-ST TIME THROUGH THE FIRST STEP, REL. ERR. FAC. IS NOT STORED
         if (LSC .eq. 7) go to 2570
 2560    continue
         TPS6 = max(TPS1, TPS6)
c   STORE NEW RELATIVE ERROR FACTOR
         TOL(-ITOLEP) = TPS6 * REF(-JLGREP - 1)
c   COMPUTE ABSOLUTE ERROR TOLERANCE
 2570    EPS = EPS * TPS6
 2580    if (EPS .le. C0) go to 2520
 2590    if (KQL) 2600, 3330, 2610
c END OF OBTAINING ERROR TOLERANCE
c ********
c OBTAIN INFORMATION USED FOR ERROR ESTIMATION, ORDER SELECTION, ETC.
c ********
c EQUATION IS STIFF
 2600    continue
c$$   COL1(STIFF)
c     JS=abs(KORD(NJSKO+I-1))-1
c     JSI=JS
c     TPP=C0
c     TPS4=F(L+KQD+2)
c     TPS3=F(L+KQD+1)
c     TPS2=F(L+KQD)
c     TPS1=F(L+KQD-1)
c     IF (KQD.EQ.2) TPS1=Y(IY-1)
c     E=ABS(TPS3)+ABS(TPS4)
c     EI=E+ABS(TPS2)
c     RND=EI
c     IF (KORDI.GE.0) GO TO 2604
c.    EQUATION IS IMPLICIT
c     JSI=JSI-1
c     IF (JSI.NE.0) GO TO 2604
c     IF (KORDI.EQ.-1) GO TO 2602
c     ERCOEF=GS(KQN+1)
c     GO TO 2606
c2602 ERCOEF=.5E0*DS(KQD,1)
c     JSI=1
c     GO TO 2606
c.    END OF SPECIAL CODE FOR IMPLICIT EQUATIONS
c2604 ERCOEF = DS(KQD,JSI)
c2606 ERCOEF = ABS(ERCOEF) / EPS
c     IF (LSC.LE.2)  GO TO 2710
c     IF (LSC-5) 2650,2710,2710
c.  END OF CODE FOR STIFF EQUATIONS
c$$   COL1(STIFF,0)
c
c EQUATION IS NOT STIFF
 2610    TPP = F(I) - F(L + 1)
         TPS3 = TPP
         TPS4 = TPP - F(L + KQD + 1)
         TPS2 = TPP + F(L + KQD)
         TPS1 = TPP + F(L + KQD - 1)
         E = abs(TPS3) + abs(TPS4)
         RND = E
         EI = E + abs(TPS2)
         ERCOEF = abs(GS(KQN + 1)) / EPS
         if (KQL .ge. 4) go to 2710
c   TEST IF STARTING OR IF INTEGRATION ORDER IS ONE
         if (LSC .le. 2) if (KQL - 2) 2660, 2710, 2710
c ********
c LOGIC ASSOCIATED WITH STARTING THE INTEGRATION
c ********
         TPS4 = C0
         if (LSC - 4) 2650, 2640, 2620
c FIRST STEP
 2620    E = E * CQ3125
         TPS3 = C0
c   TEST IF FIRST TIME THROUGH THE FIRST STEP
         if (LSC .eq. 7) go to 2690
c   COMPUTE S=ESTIMATE OF H * EIGENVALUE OF JACOBIAN = 2*(F(A)-F(B))/
c   (F(B)-F(C)) WHERE F(A)=CURRENT F(I), AND F(B) AND F(C) PRECEDING
c   VALUES OR ESTIMATES OF F(I)
         TPP = F(I) - F(L + 5)
         TPS4 = TPP
         E = C2 * abs(TPS4)
         S = F(L + 4)
         F(L + 4) = C0
         if (S .ne. C0) S = (TPS4 + TPS4) / S
         if (S + CP125) 2630, 2700, 2700
c     SET LDT=-5  TO INDICATE POSSIBLE PROBLEMS DUE TO INSTABILITY
 2630    LDT = -5
         go to 2690
c   ADJUST CORRECTION MADE ON SECOND STEP
 2640    TPP = CP8 * TPP
c   ADJUST ESTIMATED ERRORS ON SECOND AND THIRD STEPS
 2650    E = abs(TPS3)
         RND = C4 * E
         go to 2710
c END OF SPECIAL LOGIC FOR STARTING
c ********
c INTEGRATION ORDER =1 IS TREATED AS A SPECIAL CASE
c ********
 2660    TPP = TPP + F(L + 2)
         if (BETA(2) .ge. C1P4) EI = EI * C1000
c   ESTIMATE NEW VALUE FOR S
         S = F(L + 4)
         if (S .eq. C0) go to 2680
         S = max(CM8, C2 * BETA(2) * (TPS1 - TPS2 - F(L + 5)) / S)
         if (S .ge. CMP5) go to 2670
c   MODIFY TPP (TO GET BETTER STABILITY CHARACTERISTICS)
         TPP = TPP * max(CP25, (CM2 - C2 * S) / (S * S))
 2670    TPS4 = TPS4 * abs(S)
 2680    E = CP25 * (E + abs(TPS4))
         EI = EI + abs(TPS4 * S)
c     STORE INFORMATION REQUIRED TO ESTIMATE S ON NEXT STEP
 2690    F(L + 4) = TPP
 2700    F(L + 5) = F(I)
c END OF SPECIAL CODE FOR INTEGRATION ORDER =1
c ********
c CODE FOR NOISE TEST AND GETTING ERROR ESTIMATE
c ********
 2710    E = E * ERCOEF
         TPS5 = abs(F(L + 2)) + abs(F(I))
         if (TPS5 .ne. C0) go to 2720
         RNOISE = C0
         go to 2760
 2720    RNOISE = RND / TPS5
         if (RNOISE .gt. RBQ(KQD)) if (RNOISE - C1) 2760, 2750, 2750
c   NOISE IS APPARENTLY SLOWING CONVERGENCE OF THE DIFFERENCES
c     REDUCE EI
         EI = RND
         TPS5 = abs(EEPS2 * Y(IY - 1)) / EPS
         if (TPS5 .lt. abs(E)) if (LSC) 2730, 2730, 2760
         E = TPS5
         RNOISE = C0
 2730    E = -abs(E)
         if (EIMIN .gt. CP1) EI = (C10 * EIMIN) * EI
c     COMPUTE REDUCTION TO BE MADE IN EI
         if (RNOISE .gt. (C20 * RBQ(KQD))) go to 2760
         K = -6 - LSC
 2740    if (K .le. 0) go to 2760
c     REDUCE EI WHEN NOISE APPARENTLY LIMITS PRECISION
         K = K - 1
         EI = CP5 * EI
         if (EI .gt. EIMIN) go to 2740
         go to 2760
 2750    TPS4 = 1.1 * RND
         TPS3 = RND
 2760    continue
c
c   TEST FOR STIFFNESS GOES HERE WHEN IMPLEMENTED
c *       INGREDIENTS OF TEST MAY INCLUDE --
c *       RNOISE, WHETHER (ABS(TPS4).GT.ABS(TPS3)),
c *       WHETHER EMAX IS INCREASING, RESULT OF TEST ON
c *       PREVIOUS STEPS, ETC.
c
c ********
c COMPUTE ERROR ESTIMATES AND INFORMATION FOR SELECTING THE STEPSIZE
c ********
         if (E .ge. abs(EMAX)) go to 2770
         if (E .ge. C0) go to 2780
         if (EPS .lt. C0) go to 2810
         if (abs(E) .le. abs(EMAX)) go to 2780
         SNOISE = RNOISE
         DNOISE = RND
         NOISEQ = KQD
c   STORE PARAMETERS ASSOCIATED WITH LARGEST VALUE OF E
 2770    EMAX = E
         KEMAX = I
         NEPTOL = ITOLEP
c   DETERMINE HOW MUCH STEPSIZE CAN BE INCREASED
 2780    EI = EI * ERCOEF * SIGMA(KQD)
         EIMAX = max(EIMAX, EI)
         if (LINC .le. 0) go to 2810
         K = 0
 2790    if (EI .ge. min(EIMIN, EIBND(KQN))) go to 2800
         K = K + 1
         if (K .eq. LINC) go to 2810
         EI = EI * SIGMA(KQD)
         go to 2790
 2800    LINC = K
c END OF COMPUTING ERROR ESTIMATES
 2810    continue
c$$   COL1(ERRSTO)
c     IF (IOP20 .EQ. 0) GO TO 780
c.********
c.STORE ERROR ESTIMATE (OPTIONAL)
c.********
c     F(IOP20+I-1)=TPS3*GS(KQN+1)
c.END OF STORING ERROR ESTIMATE
c$$   COL1(INTEGO.OR.ERRSTO)
         if (IOP19 .eq. 0) go to 3090
c.********
c.EQUATIONS ARE GROUPED TO USE SAME INTEGRATION METHOD (OPTIONAL)
c.********
c$$   COL1(INTEGO)
         if (I .gt. 1) if (I - ILGROR) 2900, 2900, 2830
         ITOLOR = IOP19
 2830    JLGROR = KORD(ITOLOR)
         ITOLOR = ITOLOR + 1
         if (JLGROR .gt. 0) go to 2870
         ILGROR = KORD(ITOLOR)
         ITOLOR = ITOLOR + 1
         if (JLGROR + 1) 2840, 2850, 2890
 2840    if (JLGROR .lt. -2) if (KQD + JLGROR) 2850, 2880, 2880
c.INITIALIZE FOR ACCUMULATING VARIABLES USED IN ORDER SELECTION
 2850    IORD = I
         KQLORD = KQL
         do 2860 K = 1, 4
 2860       TEMPAO(K) = abs(TEMPA(K))
         go to 2930
c.ORDERS IN CURRENT GROUP CAN BE DIFFERENT
 2870    ILGROR = JLGROR
         go to 3090
c.ORDER IS NOT GOING TO BE CHANGED
 2880    JLGROR = 0
 2890    if (KQL) 3240, 3270, 3270
c.TAKE ACTION FOR EQUATION WHICH IS NOT THE FIRST IN THE GROUP
 2900    if (JLGROR) 2910, 2890, 3090
c.ACCUMULATE VARIABLES USED IN ORDER SELECTION
 2910    do 2920 K = 1, 4
 2920       TEMPAO(K) = TEMPAO(K) + abs(TEMPA(K))
c.    TEST IF THIS IS LAST EQUATION IN THE GROUP
 2930    if (I .ne. ILGROR) if (KQL) 3310, 3290, 3290
c.SET UP TO GO SELECT INTEGRATION ORDER
         KQL = 0
         do 2940 K = 1, 4
 2940       TEMPA(K) = TEMPAO(K)
         go to 3090
c.INTEGRATION ORDER HAS BEEN SELECTED
c$$   COL1(INTEGO.OR.STIFF)
 2950    continue
c$$   COL1(INTEGO)
         KQL = KQLORD
         if (KQN - abs(KQL)) 2960, 2980, 3020
c.  TEST IF ORDER CAN BE DECREASED
 2960    if (JLGROR .ge. -2) if (KQL) 3010, 3040, 3040
c.    INTEGRATION ORDER WAS SELECTED OUTSIDE PERMITTED RANGE
 2970    KQN = abs(KQL)
c.    INTEGRATION ORDER IS NOT GOING TO BE CHANGED
 2980    if ((KQL .ne. 1) .or. (LSC .gt. 0)) if (KQL) 3030, 3040, 3040
c.    SET  4-TH ENTRY IN DIFFERENCE TABLES SO THAT STANDARD ADAMS
c.    METHOD IS USED WHEN KQL=1
 2990    do 3000 K = IORD, I
 3000       F(NDTF + K*NUMDT - NUMDT + 3) = C0
         go to 3270
c.  ORDER FOR STIFF EQUATION WAS REDUCED
 3010    continue
c$$   COL1(INTEGO.AND.STIFF)
c     IF (KQN.LT.JSI) GO TO 990
c     TPP=-C1
c     GO TO 1090
c.  TEST IF ORDER CAN BE INCREASED
c$$   COL1(INTEGO)
 3020    if (JLGROR .eq. -2) go to 2970
c$$   COL1(INTEGO.AND.STIFF)
c     IF (KQL.GE.0) GO TO 1140
c     IF ((JSI.NE.0).AND.(KQN.GT.(MAXKQD+JSI))) GO TO 990
c     TPP=C1
c.  STORE RESULTS FOR STIFF EQUATIONS
c$$   COL1(INTEGO)
 3030    continue
c$$   COL1(INTEGO.AND.STIFF)
c     DO 3035 K=IORD,I
c     KORD(K+3) = -KQN
c3035 F(NDTF+K*NUMDT-NUMDT)=TPP
c     GO TO 3245
c.  STORE RESULTS FOR EQUATIONS WHICH ARE NOT STIFF
c$$   COL1(INTEGO)
 3040    LL = NDTF + NUMDT * IORD - NUMDT
         do 3080 J = IORD, I
            KORD(J + 3) = KQN
            if (KQN - KQL) 3050, 3070, 3060
 3050       F(LL + KQD - 1) = F(LL + KQD - 1) + (F(J) - F(LL))
            go to 3080
 3060       F(LL + KQN) = F(LL + KQD)
 3070       F(LL + KQD) = C0
 3080       LL = LL + NUMDT
         if (KQN - 1) 3270, 2990, 3270
c$$   COL1(INTEGO,0)
c.********
c.SELECT INTEGRATION ORDER
c.********
 3090    if (LSC .le. 0) go to 3120
c. SPECIAL ORDER SELECTION WHEN STARTING
         if (LSC - 3) 3110, 3210, 3100
 3100    if (LSC .eq. 5) if (S + .125E0) 3160, 3130, 3130
         if (LSC - 6) 3130, 3130, 3210
 3110    if (C40 * min(abs(TPS4), abs(TPS3)) .gt. abs(TPS2)) LSC = 2
         if (abs(TPS4) .lt. abs(TPS3)) if (C4 * abs(TPS4) - abs(TPS2))
     1      3130, 3130, 3210
c.  CHECK IF ORDER CAN BE INCREASED OR SHOULD BE DECREASED
 3120    TPS5 = ROBND * abs(TPS4)
         TPS6 = ROBND * (TPS5 + abs(TPS3))
         TPS7 = abs(TPS1) + abs(TPS2)
         if (TPS5 .ge. abs(TPS3)) go to 3140
         if (TPS6 .ge. TPS7) go to 3210
 3130    if (KQN .ge. MAXKQI) go to 3210
c.    INCREASE THE INTEGRATION ORDER
         KQN = KQN + 1
c$$   COL1(INTEGO.OR.STIFF,1,1)
         if (KQL) 3230, 2950, 3250
c     GO TO 3250
c.  CHECK IF ORDER SHOULD BE DECREASED
 3140    if (TPS6 .lt. TPS7) go to 3210
         if (TPS5 .lt. abs(TPS3 - TPS4)) go to 3210
         if ((TPS3.eq.TPS4) .and. (LSC.le.0)) go to 3210
         if (KQN - 2) 3210, 3160, 3180
 3160    KQN = 1
c$$   COL1(INTEGO.OR.STIFF,1)
         if (KQL) 3220, 2950, 3170
c.    WHEN ORDER IS REDUCED TO 1 WITH ADAMS METHOD SET F(L+4)=0
 3170    F(L + 4) = C0
         go to 3260
c.    DECREASE THE INTEGRATION ORDER
 3180    KQN = KQN - 1
c$$   COL1(INTEGO.OR.STIFF,1)
         if (KQL) 3220, 2950, 3200
 3200    F(L+KQD) = F(L+KQD) + TPP
         go to 3260
c   NO CHANGE IN INTEGRATION ORDER IS BEING MADE
 3210    continue
c$$   COL1(INTEGO,1,1)
         if (KQL) 3240, 2950, 3270
c     GO TO 1530
c END OF SELECTING INTEGRATION ORDER
c ********
c COMPUTE MAXIMUM INTEGRATION ORDERS AND SET NEW ONES (IF ANY)
c ********
c EQUATION IS STIFF
c     ORDER WAS DECREASED
c$$   COL1(INTEGO.OR.STIFF)
 3220    continue
c$$   COL1(STIFF)
c     IF (KQN.LT.JSI) GO TO 3236
c     F(L+1)=-C1
c     GO TO 3233
c.    ORDER WAS INCREASED
c$$   COL1( INTEGO .OR. STIFF )
 3230    continue
c$$   COL1(STIFF)
c     IF ((JSI.NE.0).AND.(KQN.GT.(MAXKQD+JSI))) GO TO 3236
c     F(L+1)=C1
c3233 KORD(I+3) = -KQN
c     GO TO 3245
c     ORDER WAS SET TO AN UNACCEPTABLE VALUE
c3236 KQN=abs(KQL)
c     ORDER IS NOT BEING CHANGED
c$$   COL1(STIFF .OR. INTEGO)
 3240    continue
c$$   COL1(STIFF)
c     F(L+1)=C0
c3245 IF (JSI.NE.0) KQMAXD=max(KQN,KQMAXD)
c     IF (JS.LT.abs(KORDI)) KQMAXI=max(KQN,KQMAXI)
c     GO TO 3290
c$$   COL1(STIFF,0)
c EQUATION IS NOT STIFF
c     ORDER INCREASED
 3250    F(L + KQN + 1) = -F(L + KQD + 1)
         if (LSC .gt. 0) F(L + KQN + 1) = F(L + 1) - F(I)
c     ORDER CHANGED
 3260    KORD(I + 3) = KQN
 3270    KQMAXI = max(KQN, KQMAXI)
         if (EPS .gt. C0) KQMAXS = max(KQN, KQMAXS)
         F(L + KQD + 1) = C0
 3290    continue
         if (KQN .gt. KIS) go to 3310
c.********
c.DETERMINE IF TIME TO STORE SOLUTION (OPTIONAL)
c.********
         if (KIS .ge. 1000) then
            TP2 = max(1.5E0, real(KQN) * C2 ** (1001 - KIS)) * abs(TPS4)
 3295       if (TP2 .gt. abs(F(L+KQN))) then
               if (KQN .le. KQL) then
                  KQN = KQN - 1
                  KQL = KQN
                  if (KQN .gt. 1) go to 3295
                  KQN = 1
               end if
            end if
            KORD(I+3) = KQN
            if (I .eq. 1) LKQMAX = 0
            LKQMAX = max(KQN, LKQMAX)
            KQMAXI = LKQMAX
            if (KIS .eq. 1000) then
               if (I .eq. KEMAX) EMAX = real(8 + KQN**2) * abs(EMAX)
               go to 3325
            end if
c$$   COL1(DUMP)
         else
            if (E .eq. C0) go to 3310
            if (IOP9 .gt. 0) if ((E*real(KIS-KQN+2)**(KQN+1)) - 1.E-2)
     1         3310, 3310, 3300
 3300       KIS = -1
c$$   COL1(DUMP,0)
         end if
 3310    continue
c ********
c CORRECT
c ********
         do 3320 K = 1, KORDI
 3320       Y(IY - K) = Y(IY - K) + G(KQL + 1, K) * TPP
c END OF CORRECTING
 3325 continue
c$$   COL1(OUTPUT)
      if (IOP10 .gt. 0) then
         if (I .eq. 1) then
            IDAT(1) = KSTEP
            IDAT(2) = LSC
            IDAT(3) = KSC
            IDAT(4) = IOP11
            FDAT(1) = TN
            FDAT(2) = HH
            FDAT(3) = EIMIN
            FDAT(4) = EAVE
            FDAT(5) = SIGMA(IOP11)
            FDAT(6) = ROBND
            MACT2(3) = NTE
            call SMESS(MACT1, MTEXT, IDAT, FDAT)
         end if
         IDAT(1) = I
         IDAT(2) = KQL
         IDAT(3) = LINC
         FDAT(1) = E
         FDAT(2) = EI
         FDAT(3) = EPS
         FDAT(4) = F(I)
         FDAT(5) = TPS1
         FDAT(6) = TPS2
         FDAT(7) = TPS3
         FDAT(8) = TPS4
         FDAT(9) = RNOISE
         FDAT(10) = S
         FDAT(11) = BETA(KQD)
         call SMESS(MACT2, MTEXT(LTXTAD), IDAT, FDAT)
         if (I .eq. NTE) IOP10 = IOP10 - 1
      end if
c$$   COL1(OUTPUT,0)
 3330    L = L + NUMDT
 3340    continue
      return
c$$   END OF  -IVACR INTEGRATION SUBROUTINE
      end
c$$   START(SIVAHC, ROOT = 'SIVA',$ROOT$HC)
c>> 1988-05-20 SIVAHC Krogh   Initial code.
      subroutine SIVAHC
c
c SUBROUTINE TO COMPUTE COEFFICIENTS REQUIRED FOR INTEGRATING
c ORDINARY DIFFERENTIAL EQUATIONS
c
c ========== THIS PROGRAM HAS BEEN SPECIALIZED ==========
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6)
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c                 1 ** K is equivalent to max(1, K)
      real             GG(1**(MAXORD-1)), B(KDIM+MAXORD-2),
     1   W(KDIM+MAXORD-2)
      integer GOINT
      real             C0, CP1, CRBQI, CP5, CP5625, C1, C1P125
      parameter (C0 = 0.E0)
      parameter (CP1 = .1E0)
      parameter (CRBQI = .421875E0)
      parameter (CP5 = .5E0)
      parameter (CP5625 = .5625E0)
      parameter (C1 = 1.E0)
      parameter (C1P125 = 1.125E0)
c$$   COL1(STIFF,1)
c     INTEGER          GODIF
      real             TP1, TP2, HH, TEMP, TP
c
c.    SPECIFICATION OF ENVIRONMENTAL CONSTANTS.
      real             EEPS10, EEPS16, EROV10, EEPS2, EEPT75, EOVEP2
      real             OVTM75, OVD10
      common / SIVAEV / EEPS2, EEPT75, EOVEP2, OVTM75, OVD10, EEPS10,
     1   EEPS16, EROV10
      save / SIVAEV /
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
      equivalence (G(1, 1), HH)
c
      save GG, W
c
c  B(K)= 1/(K*(K+1))
c$$   COL1(.T.,KDIMDT+KMAXO-2, 23 - (KDIMDT+KMAXO-2))
      data B(1)  / 5.000000000000000000000000000000000000000E-1 /
      data B(2)  / 1.666666666666666666666666666666666666667E-1 /
      data B(3)  / 8.333333333333333333333333333333333333333E-2 /
      data B(4)  / 5.000000000000000000000000000000000000000E-2 /
      data B(5)  / 3.333333333333333333333333333333333333333E-2 /
      data B(6)  / 2.380952380952380952380952380952380952381E-2 /
      data B(7)  / 1.785714285714285714285714285714285714286E-2 /
      data B(8)  / 1.388888888888888888888888888888888888889E-2 /
      data B(9)  / 1.111111111111111111111111111111111111111E-2 /
      data B(10) / 9.090909090909090909090909090909090909091E-3 /
      data B(11) / 7.575757575757575757575757575757575757576E-3 /
      data B(12) / 6.410256410256410256410256410256410256410E-3 /
      data B(13) / 5.494505494505494505494505494505494505495E-3 /
      data B(14) / 4.761904761904761904761904761904761904762E-3 /
c     data B(15) / 4.166666666666666666666666666666666666667E-3 /
c     data B(16) / 3.676470588235294117647058823529411764706E-3 /
c     data B(17) / 3.267973856209150326797385620915032679739E-3 /
c     data B(18) / 2.923976608187134502923976608187134502924E-3 /
c     data B(19) / 2.631578947368421052631578947368421052632E-3 /
c     data B(20) / 2.380952380952380952380952380952380952381E-3 /
c     data B(21) / 2.164502164502164502164502164502164502165E-3 /
c     data B(22) / 1.976284584980237154150197628458498023715E-3 /
c     data B(23) / 1.811594202898550724637681159420289855072E-3 /
c
c ********
c START OF CODE
c ********
c     SET STEP NUMBER OF METHOD
c$$   COL1(STIFF,1,1)
c     IOP11 = MIN(max(KQMAXI,KQMAXD) + 1), KDIM)
      IOP11 = MIN(KQMAXI + 1, KDIM)
c     TEST IF STEPSIZE WAS CHANGED
      if (KQICON .ge. 0) go to 3510
c ********
c STEPSIZE JUST CHANGED
c ********
c     SET CONSTANTS DEPENDING ON NEW STEPSIZE
      TP1 = HH
      GG(1) = TP1 * TP1
      G(1, 2) = GG(1) * CP5
      if (MAXINT .le. 2) go to 3450
      do 3440 K = 3, MAXINT
         GG(K - 1) = G(1, K - 1) * TP1
         G(1, K) = GG(K - 1) / real(K)
 3440    continue
c     SET CONSTANTS INDICATING STEP CHANGE
 3450 KQICON = 0
c$$   COL1(STIFF,1)
c     KQDCON=0
      KQMXIP = 1
      KSC = 1
      if (LSC .lt. 7) go to 3490
c     SPECIAL SET-UP OF CONSTANTS ON THE VERY FIRST STEP
      HINCC = C1P125
      LINCD = 6
      LINCQ = 12
      if (HINC .gt. C0) go to 3460
      LINCD = -2
      LINC = -2
      ROBND = C1
 3460 SIGMA(1) = 1.0
      BETA(1) = C1
      do 3470 N = 1, IOP11
c$$   COL1(STIFF,1)
c     D(1,N)=C0
         XI(N) = TP1
         ALPHA(N) = C1
         BETA(N + 1) = C1
         SIGMA(N + 1) = real(N + 1) * SIGMA(N) * HINCC
 3470    continue
      TEMP = EEPS16
      RBQ(1) = C1
      RBQ(2) = CP1
      TP = CRBQI
c     **** IN THE LOOP BELOW RBQ(K) IS COMPUTED TO BE
c          APPROXIMATELY (3/4 ** ((K-1) ** 2 - 1) / 10
c          .5625 = (3/4) ** 2    TP = (3/4) ** (2*K -3)
      do 3480 K = 3, KDIM
         TEMP = TEMP + TEMP
         RBQ(K) = max(TEMP, RBQ(K - 1) * TP)
 3480    TP = TP * CP5625
      go to 3560
c     SET-UP AFTER THE FIRST STEP
 3490 TP2 = XI(1)
      XI(1) = TP1
      BETA(2) = TP1 / TP2
      K = 2
      if (HINCC .eq. HINC) go to 3540
      if ((LSC .ne. 0) .or. ((KSTEP-KSSTRT-KQMAXS) .lt. 10)) go to 3540
      HINCC = C1
      LINCD = 0
 3500 LINCD = LINCD + 1
      HINCC = HINCC * HINC
      if (HINCC .lt. 2.E0) go to 3500
      LINC = (LINC * (LINCD + LINCD)) / LINCQ
      LINCQ = LINCD + LINCD
      HINCC = HINC
      go to 3540
c END OF LOGIC FOR CASE WHEN STEPSIZE JUST CHANGED
c     TEST IF MAXIMUM INTEGRATION ORDER DID NOT INCREASE
 3510 if (KQMAXI .le. KQMXIL) go to 3530
c ********
c INTEGRATION ORDER WAS INCREASED -- GET NEW V'S
c ********
      KQMXIL = KQMAXI
      K = KQMXIP
      KQMXIP = KQMXIL + MAXINT
      V(K) = B(K)
      if (KQICON .eq. 1) go to 3530
      if (KQICON .eq. K) KQICON = KQICON - 1
      do 3520 N = 2, KQICON
         K = K - 1
 3520    V(K) = V(K) - ALPHA(N) * V(K + 1)
c END OF GETTING NEW V'S
 3530 if (IOP11 .le. KSC) go to 3560
c ********
c COMPUTE PARAMETERS WHICH ARE STILL CHANGING AS A RESULT OF
c A CHANGE IN THE STEPSIZE
c ********
      TP2 = XI(KSC)
c     UPDATE CONSTANT STEP COUNTER
      KSC = KSC + 1
      K = KSC
      BETA(K) = C1
 3540 continue
      TEMP = HINCC
c
c   LOOP TO COMPUTE NEW VALUES OF PARAMETERS
      do 3550 N = K, IOP11
         TP1 = TP2 + HH
         TP2 = XI(N)
         XI(N) = TP1
         ALPHA(N) = HH / TP1
         BETA(N + 1) = BETA(N) * (TP1 / TP2)
         TEMP = max(TEMP, real(N) * (ALPHA(N) * HINCC))
         SIGMA(N) = SIGMA(N - 1) * TEMP
 3550    continue
      if (IOP11 .ne. KDIM) XI(IOP11 + 1) = TP2 + HH
c END OF CODE FOR COMPUTING PARAMETERS WHICH ARE STILL CHANGING
c
 3560 if (KQICON .ge. KQMXIP) go to 3690
c ********
c COMPUTE INTEGRATION COEFFICIENTS WHICH ARE STILL CHANGING
c ********
      N = KQICON + 1
      KQICON = N
      if (N .ne. 1) go to 3580
      KQMXIL = KQMAXI
      KQMXIP = KQMXIL + MAXINT
      J = KQMXIP - 1
c INITIALIZE V AND W
      do 3570 K = 1, J
         V(K) = B(K)
 3570    W(K) = V(K)
      go to 3600
c UPDATE V AND INITIALIZE W
 3580 J = KQMXIP - N
      if (J .eq. 0) go to 3690
      if (N .eq. KDIM) go to 3690
      do 3590 K = 1, J
         V(K) = V(K) - ALPHA(N) * V(K + 1)
 3590    W(K) = V(K)
c SET TRANSFER FOR LOOP BELOW DEPENDING ON VALUE OF MAXINT
 3600 continue
c$$   COL1(KMAXO .GE. 2, 6)
      if (MAXINT - 2) 3610, 3620, 3630
 3610 assign 3680 to GOINT
      go to 3680
 3620 assign 3670 to GOINT
      go to 3670
 3630 assign 3660 to GOINT
      go to 3660
c
 3640 J = J - 1
c INNER LOOP FOR COMPUTING INTEGRATION COEFFICIENTS
      do 3650 K = 1, J
 3650    W(K) = W(K) - ALPHA(N) * W(K + 1)
c
c$$   COL1(KMAXO .GE. 2, 1)
      go to GOINT, (3660, 3670, 3680)
c     STORE INTEGRATION COEFFICIENTS
 3660 continue
c$$   COL1(KMAXO .GE. 3, 2)
c     DO 3665 K=3,MAXINT
c3665 G(N+1,K)=GG(K-1)*W(K)
 3670 continue
      G(N + 1, 2) = GG(1) * W(2)
c$$   COL1(KMAXO .GE. 2, 1)
 3680 G(N + 1, 1) = HH * W(1)
      GS(N + 1) = G(N + 1, 1) - G(N, 1)
      N = N + 1
      if (N .le. KQMAXI) go to 3640
c END OF COMPUTING INTEGRATION COEFFICIENTS
c
 3690 continue
c$$   COL1(STIFF)
c     IF (KQDCON.GT.KQMAXD) GO TO 4662
c.********
c.COMPUTE DIFFERENTIATION COEFFICIENTS WHICH ARE STILL CHANGING
c.********
c.SET TRANSFER FOR LOOP BELOW, DEPENDING ON VALUE OF MAXDIF
c$$   COL1(STIFF .AND. (KMAXO .GE. 2))
c     IF (MAXDIF-2) 3693,3692,3691
c3691 ASSIGN 3696 TO GODIF
c     GO TO 3694
c3692 ASSIGN 3698 TO GODIF
c     GO TO 3694
c3693 ASSIGN 3699 TO GODIF
c$$   COL1(STIFF)
c3694 KQDCON=KQDCON+1
c.LOOP FOR COMPUTING DIFFERENTIATION COEFFICIENTS
c     DO 3699 N=KQDCON,KQMAXD
c     DS(N+1,2)=C1/XI(N)
c     D(N+1,1)=DS(N+1,2)+D(N,1)
c     DS(N+1,1)=DS(N+1,2)/D(N+1,1)
c$$   COL1(STIFF .AND. (KMAXO .GE. 2))
c     GO TO GODIF, (3696,3698,3699)
c3696 CONTINUE
c$$   COL1( (STIFF .AND. (KMAXO .GE. 3) ) )
c     DO 3697 K=3,MAXDIF
c     DS(N+1,K)=D(N,K-2) * (K-1)/XI(N)
c3697 D(N+1,K-1)=DS(N+1,K) + D(N,K-1)
c$$   COL1(STIFF)
c3698 CONTINUE
c$$   COL1(STIFF .AND. (KMAXO .GE. 2))
c     D(N+1,MAXDIF)=D(N,MAXDIF) + D(N,MAXDIF-1) * (MAXDIF)/XI(N)
c$$   COL1(STIFF)
c3699 CONTINUE
c$$   COL1(STIFF,0)
c
c END OF COMPUTING DIFFERENTIATION COEFFICIENTS
      return
c$$   END OF  -IVAHC INTEGRATION SUBROUTINE
      end
c$$   START( SIVAIN, ROOT = 'SIVA', $ROOT$IN)
c>> 1988-01-14 SIVAIN Krogh   Initial code.
      subroutine SIVAIN(T, Y, F, KORD)
c
c  SUBROUTINE TO DO INTERPOLATION FOR VARIABLE ORDER INTEG. ROUTINE
c
c ========== THIS PROGRAM HAS BEEN SPECIALIZED ==========
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer KORD(*)
      real             T(*), F(*)
      real             Y(*)
      real             C0, C1, C2
      parameter (C0 = 0.E0)
      parameter (C1 = 1.E0)
      parameter (C2 = 2.E0)
      real             C(KDIM+MAXORD-1), ETA(KDIM)
      real             GAMMA(KDIM)
      real             TP1, HI
      real             CSUM(KDIM+MAXORD-1)
      logical LNOTM1
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
      save / SIVASC /
c
c              Stuff for processing error messages
      integer IDAT(1)
      real             FDAT(6)
      parameter (MENTXT =23)
      parameter (MERET  =51)
      parameter (MEEMES =52)
      parameter (METEXT =53)
      integer MACT(8)
      character MTEXT(154)
      parameter (LTXTAA = 1)
      character MTXTAA*(8)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 9)
      character MTXTAB*(32)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      parameter (LTXTAC = 41)
      character MTXTAC*(53)
      equivalence (MTEXT(LTXTAC), MTXTAC)
      parameter (LTXTAD = 94)
      character MTXTAD*(61)
      equivalence (MTEXT(LTXTAD), MTXTAD)
c                      1 2 3 4       5 6       7      8
      data MACT / MEEMES,0,0,0, MENTXT,0, METEXT, MERET /
c
      DATA MTXTAA/'SIVAIN$B'/,
     1MTXTAB/'Interpolating at T(1)=$F with $B'/,MTXTAC/
     2'TN=$F, T(2)=$F and H=$F.  T(1) must be in [$F, $F].$E'/,
     3MTXTAD/
     4'internal variable LDT = $I.  Interpolation not allowed now.$E'/
c$$   COL1(ARGM,1)
c     ENTRY SIVAIE
c ********
c START OF CODE -- CHECK ON STATE OF DIFFERENCE TABLE
c ********
      L = LDT
      if (L) 3710, 3730, 3780
 3710 if (L + 2) 4170, 3730, 3720
 3720 if (MAXINT .ge. 0) L = 1
      go to 3840
c ********
c UPDATE DIFFERENCE TABLE TO START OF NEXT STEP
c ********
 3730 K = NDTF
      do 3770 I = 1, NTE
         KQQ = KORD(I + 3)
         if (KQQ .le. 0) go to 3760
c EQUATION IS NOT STIFF
         TP1 = F(I) - F(K)
c LOOP TO DO UPDATING
         N = K + max(abs(KQQ), 2)
         do 3750 J = K, N
 3750       F(J) = F(J) + TP1
 3760    continue
         K = K + NUMDT
 3770    continue
      LDT = 1
      if (L .ne. 0) return
c END OF UPDATING DIFFERENCE TABLE
c ********
c INITIALIZE FOR COMPUTATION OF COEFFICIENTS
c ********
 3780 INTERP = 0
      assign 4066 to LGO
      HI = T(1) - TN
      GAMMA(1) = HI / XI(1)
      if (GAMMA(1)) 3790, 3800, 3810
 3790 if (GAMMA(1) .ge. -C1) go to 3820
      INTERP = 1
      if (abs(HI) - abs(T(2))) 3820, 3820, 4180
 3800 INTERP = 2 - KQMAXI
      go to 3820
 3810 if (GAMMA(1) .gt. C2) if (LDT - 2) 4180, 3820, 3820
 3820 KQMXI = KQMAXI + INTERP - 1
c$$   COL1(STIFF,1,1)
c     KQMXS=max(KQMXI,KQMAXD)
      KQMXS = KQMXI
      do 3830 N = 2, KQMXS
 3830    GAMMA(N) = (HI + XI(N-1)) / XI(N)
 3840 LNOTM1 = L .ne. -1
      INTEG = MAXINT
      if (INTEG .le. 0) if (INTEG + MAXDIF) 4160, 3950, 3950
c ********
c COMPUTE INTEGRATION COEFFICIENTS
c ********
c     INITIAL SET-UP
c         COMPUTE INITIAL C VALUES
      do 3850 N = 1, INTEG
         C(N) = HI / real(N)
 3850 continue
      I = INTEG + 1
      INTEG = INTEG + KQMXI
      do 3860 N = I, INTEG
         C(N) = C(N - 1) * (real(N - MAXINT) / real(N))
 3860    continue
c         COMPUTE ETA'S
      do 3870 N = 1, KQMXI
 3870    ETA(N) = HI / XI(N)
c         COMPUTE C(K)'S TO CORRESPOND TO G(K-MAXINT+1,MAXINT),
c         K=MAXINT, MAXINT+1,..., MAXINT+KQMXI-1
      I = INTEG
 3880 J = INTEG
      INTEG = J - 1
      if (INTEG .le. MAXINT) go to 3900
      do 3890 N = J, I
 3890    C(N) = ETA(N - INTEG) * C(N) + C(N - 1)
      go to 3880
 3900 do 3910 N = J, I
 3910    C(N) = ETA(N - INTEG) * C(N)
c         END OF COMPUTING  G(---,MAXINT)
      INTEGZ = 0
      go to 3940
c         COMPUTE C(K)-S TO CORRESPOND TO G(K-INTEG+1,INTEG),
c         K=INTEG+1,INTEG+2,..., INTEG+KQMXI
 3920 do 3930 N = 1, KQMXI
 3930    C(INTEG+N) = GAMMA(N)*C(INTEG+N-1) - ETA(N)*C(INTEG+N)
 3940 ICI = INTEG - 1
      go to 4020
c END OF COMPUTING INTEGRATION COEFFICIENTS
c ********
c COMPUTE COEFFICIENTS FOR INTERPOLATION
c ********
 3950 C(1) = C1
      ICI = 0
      do 3960 N = 1, KQMXS
 3960    C(N + 1) = GAMMA(N) * C(N)
      if (INTEG + 1) 3970, 3990, 4010
c END OF COMPUTING INTERPOLATION COEFFICIENTS
c
c     SET-UP TO COMPUTE DIFFERENTIATION COEFFICIENTS REQUIRED
c     IN ORDER TO GET COEFFICIENTS ACTUALLY USED
 3970 INTEG = 0
      ICI = 1
 3980 INTEG = INTEG - 1
      if (INTEG .eq. MAXINT) ICI = 0
c ********
c COMPUTE DIFFERENTIATION COEFFICIENTS
c ********
 3990 INTERP = max(INTERP, 0)
      TP1 = real(-INTEG)
      C(1) = TP1 * C(1) / XI(-INTEG)
      J = KQMAXD + INTEG
      do 4000 N = 1, J
 4000    C(N + 1) = (TP1*C(N)) / XI(N - INTEG) + GAMMA(N - INTEG) * C(N)
c     C(N) NOW CORRESPONDS TO THE DIFFERENTIAL COEFFICIENT
c          D(N-INTEG,-INTEG)
 4010 INTEGZ = INTEG
      if (ICI .ne. 0) go to 3980
c END OF COMPUTING DIFFERENTIATION COEFFICIENTS
c ********
c BEGINNING OF LOOP TO DO
c         INTEGRATION       (INTEG.GT.0)
c         INTERPOLATION     (INTEG.EQ.0)
c         DIFFERENTIATION   (INTEG.LT.0)
c TO THE POINT INDICATED BY T.
c ********
c     SET UP INITIAL INDICES
 4020 if (NYNY .lt. 0) then
         IY = -NYNY
         IYNI = NYNY + ICI + 1
         if (LDT .eq. 2) then
            assign 4063 to LGO
            CSUM(ICI+1) = C(ICI+1)
            do 4025 J = ICI+2, INTEG+KQMXI
            CSUM(J) = CSUM(J-1) + C(J)
 4025       continue
         end if
      else
         IY = 1
         IYNI = NYNY + ICI - 1
      end if
      IDT = NDTF - INTEGZ
      do 4140 I = 1, NTE
         if (NKDKO .ne. 0) KORDI = KORD(NKDKO + I - 1)
         IY = IY + abs(KORDI)
         KQQ = KORD(I + 3)
c         GET INDEX OF HIGHEST ORDER DIFFERENCE TO BE USED
         K = max(abs(KQQ) + INTERP, 2)
         IYI = -INTEG
         if (KQQ) 4030, 4130, 4040
c EQUATION IS STIFF
 4030    continue
c$$   COL1(STIFF)
c     JS=abs(KORD(NJSKO+I-1))-1
c     IYI=IYI-JS
c     IF(LNOTM1) IF (IYI) 4034,4032,4130
c     IF (KORDI.LT.0) IYI=IYI+1
c     IYI=IYI+MAXINT-abs(KORDI)
c     IF (IYI) 4034,4130,4130
c.      IF EQUATION IS IMPLICIT DO NOT COMPUTE AN F
c4032 IF (KORDI.LT.0) GO TO 4130
c.      TEST IF INTEG TOO BIG FOR THIS EQUATION
c4034 IF (abs(KORDI).LT.-IYI) GO TO 4130
c     IYI=IYI+IY
c     IYN=IYI+IYNI
c. COMPUTE INNER PRODUCT FOR STIFF EQUATIONS
c     IF (INTEGZ.EQ.0) GO TO ???
c.    DIFFERENTIATING
c     TP1 = C0
c     DO 4036 J = K+INTEGZ, 1, -1
c        TP1 = TP1 + C(J) * F(IDT+J-1)
c4036 CONTINUE
c.    TEST WHETHER TO STORE RESULT IN Y OR F
c     IF (IYI-IY) 4080, 4090, 4080
c.    INTEGRATING OR INTERPOLATING
c     TP1 = C0
c     DO 4037 J = ICI + K, ICI + 2, -1
c        TP1 = TP1 + C(J) * F(IDT+J-ICI-1)
c4037 CONTINUE
c     IF (INTEG.EQ.0) GO TO 4120
c     TP1=TP1 + C(ICI+1)*Y(IYN+1)
c$$   COL1(STIFF, 0)
         go to 4100
c END OF SPECIAL CODE FOR STIFF EQUATIONS
c
c EQUATION IS NOT STIFF
 4040    if (LNOTM1) if (IYI) 4050, 4060, 4130
         IYI = IYI + MAXINT - KORDI
         if (IYI .ge. 0) go to 4130
c       TEST IF INTEG TOO BIG FOR THIS EQUATION
 4050    if (KORDI .lt. -IYI) go to 4130
 4060    IYI = IYI + IY
         IYN = IYI + IYNI
c  COMPUTE INNER PRODUCT FOR EQUATION WHICH IS NOT STIFF
         TP1 = C0
         go to LGO, (4063, 4066)
 4063    if (KQQ .ne. KQMAXI) TP1 = CSUM(K+INTEGZ+ICI) *
     1      F(IDT+INTEGZ+NUMDT-1)
 4066    do 4070 J = K + INTEGZ + ICI, ICI + 1, -1
            TP1 = TP1 + C(J) * F(IDT - ICI - 1 + J)
 4070       continue
         if (INTEG) 4080, 4090, 4100
c STORE FINAL RESULT IN Y WHEN DIFFERENTIATING
 4080    continue
         Y(IYI) = TP1
         go to 4130
c STORE INTERPOLATED VALUE IN F (OR STIFF DIFFERENTIATION)
 4090    F(I) = TP1
         go to 4130
c PICK UP EXTRA STUFF TO ADD TO INNER PRODUCT WHEN INTEGRATING
 4100    K = ICI
         if (K .eq. 0) go to 4120
 4110    continue
         TP1 = C(K) * (TP1 + Y(IYN))
         IYN = IYN - 1
         K = K - 1
         if (K .ne. 0) go to 4110
c STORE FINAL RESULT IN Y WHEN INTEGRATING (OR STIFF INTERPOLATION)
 4120    Y(IYI) = TP1 + Y(IYN)
 4130    continue
         IDT = IDT + NUMDT
 4140    continue
c
      INTEG = INTEG - 1
      if (INTEG .ge. -MAXDIF) if (INTEG) 3990, 3950, 3920
 4160 return
c ********
c ERROR PROCESSING
c ********
 4170 MACT(2) = 68
      MACT(3) = 11
      MACT(6) = LTXTAD
      IDAT(1) = LDT
      go to 4190
 4180 MACT(2) = 28
      MACT(3) = 1
      MACT(6) = LTXTAC
      FDAT(2) = TN
      FDAT(3) = T(2)
      FDAT(4) = XI(1)
      FDAT(5) = TN - T(2)
      FDAT(6) = TN + C2 * XI(1)
      if (XI(1) .lt. 0) then
         FDAT(5) = FDAT(6)
         FDAT(6) = TN - T(2)
      end if
 4190 FDAT(1) = T(1)
      call SMESS(MACT, MTEXT, IDAT, FDAT)
      if (MACT(2) .lt. 50) go to 3820
      return
c$$   END OF  -IVAIN INTEGRATION SUBROUTINE
      end
c$$   START( SIVAOP, ROOT = 'SIVA', $ROOT$OP)
c>> 1987-12-07 SIVAOP Krogh   Initial code.
c  SUBROUTINE TO SET UP OPTIONS FOR DIFFERENTIAL EQUATION
c     PACKAGE -ODE (OR -IVA)
      subroutine SIVAOP(IOPT, FOPT)
      real             FOPT(*)
      integer IOPT(*)
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6)
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c
      integer IOPTS(22), INCOP(22), IOPTC(22)
      real             CMP75, C0, CP25, CP3, CP5, CP625, CP75, CP875,
     1   CP9, C1, C1P125, C2, C4, C10, C16
      parameter (CMP75 = -.75E0)
      parameter (C0 = 0.E0)
      parameter (CP25 = .25E0)
      parameter (CP3 = .3E0)
      parameter (CP5 = .5E0)
      parameter (CP625 = .625E0)
      parameter (CP75 = .75E0)
      parameter (CP875 = .875E0)
      parameter (CP9 = .9E0)
      parameter (C1 = 1.E0)
      parameter (C1P125 = 1.125E0)
      parameter (C2 = 2.E0)
      parameter (C4 = 4.E0)
      parameter (C10 = 10.E0)
      parameter (C16 = 16.E0)
c.    SPECIFICATION OF ENVIRONMENTAL CONSTANTS.
      real             R1MACH
      real             EEPS10, EEPS16, EROV10, EEPS2, EEPT75, EOVEP2
      real             OVTM75, OVD10
      common / SIVAEV / EEPS2, EEPT75, EOVEP2, OVTM75, OVD10, EEPS10,
     1   EEPS16, EROV10
      save / SIVAEV /
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
      equivalence (IOPTC(3), IOP3)
      save IOPTS, LIOPT
c
c                      Declarations for error message processing.
c     
      parameter (MERET  =51)
      parameter (MEEMES =52)
      parameter (METEXT =53)
      parameter (MEIVEC =57)
      integer MACT(7)
c
      character MTEXT(48)
      parameter (LTXTAA = 1)
      character MTXTAA*(8)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 9)
      character MTXTAB*(40)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      DATA MTXTAA/'SIVAOP$B'/,
     1MTXTAB/'Error in IOPT() specifications: IOPT =$B'/
c                      1   2  3   4       5  6      7
      data MACT / MEEMES, 88, 24, 0, MEIVEC, 0, MERET /
c
      data IOPTS / 3*0, 500000, 12*0, 1, 5*0 /
c
c                  1  2    3  8  9 10   11   13 16   17 21 22
      data INCOP / 1, 3, 5*2, 1, 2, 3, 2*2, 3*1, 3, 4*2, 3, 2 /
c
c ********* START OF EXECUTABLE CODE ***********************
c
      K = 1
 4200 I = IOPT(K)
      IA = abs(I)
c 1 and 6 lines below need 20 changed if more options are added.
      if (IA .le. 20) if (I) 4220, 4520, 4280
      if (I .ne. 1111) go to 4490
      IOPT(2) = LIOPT
c
c     ****  INITIALIZE FOR STARTING A NEW INTEGRATION
      do 4210 J = 3, 20
 4210    IOPTC(J) = IOPTS(J)
      KSOUT = IOPTS(4)
      KMARK = 1 - IOPTS(1)
      KORDI = IOPTS(17)
      NKDKO = max(-KORDI, 0)
      IOPST = IOPTS(22)
      go to 4260
c
c     **** SET A NOMINAL VALUE
 4220 IOPTS(IA) = 0
      if (IA .eq. 12) go to 4420
      if (IA - 2) 4400, 4240, 4230
 4230 if (IA .eq. 4) IOPTS(4) = 500000
      go to 4390
c
c     **** SET ALL OPTIONS TO THEIR NOMINAL VALUES
 4240 IA = 1
      IOPTS(1) = 0
      do 4250 J = 3, 22
         IOPTS(J) = 0
         IOPTC(J) = 0
 4250    continue
      IOPTS(4) = 500000
      IOPTC(4) = IOPTS(4)
      IOPTS(17) = 1
 4260 NGTOT = IOPTS(7) + max(IOPTS(6), 0)
      if (IOPTS(12) .eq. 0) go to 4420
 4270 return
c
c     **** SET SPECIFIED OPTION
 4280 J = IOPT(K + 1)
      if (INCOP(IA) - 2) 4290, 4330, 4300
c     **** OPTION INVOLVES NO EXTRA PARAMETERS
 4290 IOPTS(IA) = 1
      if (IA - 2) 4400, 4400, 4390
c     **** TAKE CARE OF SECOND EXTRA PARAMETER
 4300 if (IA .ne. 10) go to 4310
      NOUTKO = IOPT(K + 2)
      if (NOUTKO) 4500, 4350, 4350
 4310 if (IA .ne. 16) go to 4320
      NTOLF = IOPT(K + 2)
      if (NTOLF) 4500, 4500, 4350
 4320 TMARK = FOPT(IOPT(K+2))
      KMARK = J
      go to 4400
c     **** TAKE CARE OF FIRST EXTRA PARAMETER
 4330 continue
      if (IA .eq. 12) go to 4410
      if (IA .eq. 4) KSOUT = J
 4350 IOPTS(IA) = J
      if (abs(IA - 7) .gt. 1) go to 4360
c     **** SET SPECIAL PARAMETERS FOR GSTOP-S
      IGFLG = 0
      NGTOT = IOPTS(7) + max(IOPTS(6), 0)
c     **** TEST FOR ERROR
      if (J .gt. 500) go to 4500
 4360 if (J .gt. 0) go to 4390
      if ((IA .eq. 5) .or. (IA .eq. 17)) go to 4390
      if (J + 1) 4500, 4370, 4380
 4370 if (IA .eq. 7) go to 4500
 4380 if ((IA .eq. 4) .or. (IA .eq. 11) .or. (IA .ge. 16)) go to 4500
c     **** STORE SAVED VALUE IN COMMON
 4390 IOPTC(IA) = IOPTS(IA)
c
c     **** INCREMENT K TO GET NEXT OPTION
 4400 K = K + INCOP(IA)
      go to 4200
c
c ******* SET UP INFORMATION FOR CHANGING STEPSIZE *********
c
c     **** TEST IF VALUES ARE ALREADY SET
 4410 if (IOPTS(12) .gt. 0) go to 4430
c     **** SET NOMINAL VALUES FOR VARIABLES ONLY SET ONCE
 4420 EREP = CP3
c     **** SET NOMINAL VALUES FOR STEPSIZE CONTROL AND ENV. CONSTANTS
      EEPS2 = R1MACH(4)
      EEPS16 = C16 * EEPS2
      EEPS10 = CP625 * EEPS16
      EEPT75 = EEPS2 ** CP75
      EEPS2 = EEPS2 + EEPS2
      OVD10 = R1MACH(2)
      EROV10 = C10 / OVD10
      EOVEP2 = OVD10 * EEPS2
      OVTM75 = OVD10 ** CMP75
      OVD10 = OVD10 / C10
      HINC = C2
      HDEC = CP5
      HMIN = EROV10
      HMAX = OVD10
      if (I .ne. 12) go to 4470
 4430 IOPTS(12) = J
      if (J) 4450, 4470, 4460
c     **** SET UP TO GIVE USER COMPLETE STEPSIZE CONTROL
 4450 EREP = C1 / EROV10
      HINC = -C2
      go to 4480
c     **** SET USER VALUES FOR STEPSIZE CONTROL
 4460 if (FOPT(J) .ne. C0) HINC = max(C1P125, min(FOPT(J),C4))
      if (FOPT(J + 1) .ne. C0) HDEC = min(CP875, max(FOPT(J + 1), CP25))
      if (FOPT(J + 2) .ne. C0) HMIN = FOPT(J + 2)
      if (FOPT(J + 3) .ne. C0) HMAX = FOPT(J + 3)
 4470 KQICON = -1
 4480 HMAXP9 = HMAX * CP9
      if (I - 1111) 4400, 4270, 4400
c
c ***************** ERROR  IN  IOPT ************************
c
 4490 IA = 1
 4500 KORD1I = 24
      MACT(6) = K + INCOP(IA) - 1
      call MESS(MACT, MTEXT, IOPT)
      KORD2I = -4
c Usual return with no error is here.
 4520 LIOPT = K
      return
c$$   END   -IVAOP  (SET UP OPTIONS FOR ODE PACKAGE)
      end
c$$   START( SIVAPR, ROOT = 'SIVA', $ROOT$PR)
c>> 1988-01-13 SIVAPR Krogh   Initial code.
      subroutine SIVAPR(Y, YN, F, KORD)
c
c THIS SUBROUTINE
c   1. UPDATES THE DIFFERENCE TABLE FROM THE PREVIOUS STEP (IF NOT
c      DONE ALREADY).
c   2. PREDICTS WHAT THE VALUES OF THE DEPENDENT VARIABLES, Y, AND
c      THE DIFFERENCE TABLE, DT, WILL BE AT THE END OF THE CURRENT STEP.
c ========== THIS PROGRAM HAS BEEN SPECIALIZED ==========
c
c   Y = VECTOR OF PREDICTED VALUES COMPUTED BY THIS SUBROUTINE.
c   YN= VECTOR OF VALUES OF Y COMPUTED ON THE LAST STEP.
c   F = VECTOR OF DERIVATIVE VALUES.
c   DT= ARRAY CONTAINING DIFFERENCE TABLES.
c   KD= VECTOR GIVING ORDERS OF THE DIFFERENTIAL EQUATIONS (IF
c       EQUATIONS HAVE DIFFERENT ORDERS).
c   KQ= VECTOR OF INTEGRATION ORDERS.
c
      integer KORD(*)
      real             Y(*), YN(*)
      real             F(*)
      real             C0
      parameter (C0 = 0.E0)
c
c$    parameter (KDIM = $KDIMDT$)
      parameter (KDIM = 14)
c$    parameter (MAXORD = $KMAXO$)
      parameter (MAXORD = 2)
c$    parameter (MAXSTF = $MAXKQD$)
      parameter (MAXSTF = 1)
      real             TN, XI(KDIM)
c
      integer IGTYPE(2), IGSTOP(2)
      real             ALPHA(KDIM), BETA(KDIM+1)
      real              D(MAXSTF+MAXORD,MAXORD), G(KDIM,MAXORD)
      real             V(KDIM+MAXORD-2)
      real             HC, HDEC, HINC, HINCC, HMAX, HMAXP9, HMIN, TG(2)
      real             TGSTOP(2), TMARK, TMARKX, TOUT
      real             FDAT(11)
      integer IDAT(6)
c
      real             DS(MAXSTF+MAXORD, MAXORD), GS(KDIM)
      real             SIGMA(KDIM), RBQ(KDIM), DNOISE
      real             EAVE, EIMAX, EIMIN, EMAX, EREP, ROBND, SNOISE
c
      real             TEMP(KDIM)
      real             TP1, TP2
      common / SIVASC / TN, XI, IOPST, KORDI, KQMAXD, KQMAXI, LDT,
     1   MAXDIF, MAXINT, NKDKO, NTE, NYNY, NDTF, NUMDT
c
      common /SIVAMC/ HC,HDEC,HINC,HINCC,HMAX,HMAXP9,HMIN,TG,TGSTOP,
     1   TMARK,TMARKX,TOUT,ALPHA,BETA,D,G,V,DS,GS,SIGMA,RBQ,DNOISE,
     2   EAVE,EIMAX,EIMIN,EMAX,EREP,ROBND,SNOISE,FDAT,ICF,ICS,IGFLG,
     3   IGTYPE,IGSTOP,ILGREP,INGS,IOP3,IOP4,IOP5,IOP6,IOP7,IOP8,IOP9,
     4   IOP10,IOP11,IOP12,IOP13,IOP14,IOP15,IOP16,IOP17,IOP18,IOP19,
     5   IOP20,IOP21,IOP22,IOP21S,ITOLEP,IY,KEMAX,KIS,KMARK,KORD1I,
     6   KORD2I,KPRED,KQDCON,KQICON,KQMAXS,KQMXDS,KQMXIL,KQMXIP,KQMXIS,
     7   KSC,KSOUT,KSSTRT,KSTEP,LEX,LINC,LINCD,LINCQ,LSC,MAXKQD,MAXKQI,
     8   METHOD,NE,NEPTOL,NG,NGTOT,NOISEQ,NOUTKO,NTOLF,NY,IDAT
      save / SIVAMC / , / SIVASC /
      data INTEGS / -1 /
c
c$$   COL1(ARGM,2)
c     RETURN
c     ENTRY SIVAPE
c ********
c START OF CODE
c ********
      IY = 0
      L = NDTF - 1
      do 4680 I = 1, NTE
         INTEG = KORDI
         if (NKDKO .ne. 0) INTEG = KORD(NKDKO + I - 1)
         KQQ = KORD(I + 3)
         K = max(abs(KQQ), 2)
         if (KQQ) 4530, 4520, 4540
 4520    IY = IY + abs(INTEG)
         go to 4670
c ********
c EQUATION IS STIFF, OR IMPLICIT
c ********
 4530    continue
c$$   COL1(STIFF)
c     KQQ=-KQQ
c     N=KQQ-1
c     JS=abs(KORD(NJSKO+I-1))-1
c     IMPLIC=INTEG
c     INTEG=abs(IMPLIC)-JS
c.    SET INTEGS FOR STIFF EQUATIONS
c     INTEGS=0
c     IF (K-KSC) 160,160,140
c.END OF SET-UP FOR STIFF EQUATIONS
c$$   COL1(STIFF,0)
c ********
c EQUATION IS NOT STIFF
c ********
 4540    N = KQQ
         if (LDT .ne. 0) if (K - KSC) 4570, 4570, 4550
c     DIFFERENCE TABLE HAS NOT BEEN UPDATED
         TP1 = F(I) - F(L + 1)
         if (K - KSC) 4610, 4610, 4590
c END OF SET-UP FOR EQUATIONS WHICH ARE NOT STIFF
c ********
c GET PREDICTED DIFFERENCES FROM UPDATED DIFFERENCE TABLE
c ********
 4550    F(L + K + 1) = F(L + K + 1) * BETA(K + 1)
         TEMP(K) = F(L + K) * BETA(K)
         F(L + K) = TEMP(K)
c LOOP FOR MODIFIED DIVIDED DIFFERENCES
 4560    K = K - 1
         if (K .le. KSC) go to 4580
         TEMP(K) = F(L + K) * BETA(K)
         F(L + K) = TEMP(K) + F(L + K + 1)
         go to 4560
c CODE FOR BACKWARD DIFFERENCES
 4570    F(L + K + 1) = F(L + K + 1)
         TEMP(K) = F(L + K)
         K = K - 1
c
 4580    TEMP(K) = F(L + K)
         F(L + K) = TEMP(K) + F(L + K + 1)
         K = K - 1
         if (K .ne. 0) go to 4580
         go to 4630
c ********
c UPDATE DIFFERENCE TABLE AND GET PREDICTED DIFFERENCES
c ********
c CODE FOR MODIFIED DIVIDED DIFFERENCES
 4590    F(L + K + 1) = (F(L+K+1) + TP1) * BETA(K + 1)
         TEMP(K) = (F(L + K) + TP1) * BETA(K)
         F(L + K) = TEMP(K)
 4600    K = K - 1
         if (K .le. KSC) go to 4620
         TEMP(K) = (F(L + K) + TP1) * BETA(K)
         F(L + K) = TEMP(K) + F(L + K + 1)
         go to 4600
c CODE FOR BACKWARD DIFFERENCES
 4610    F(L + K + 1) = (F(L+K+1) + TP1)
         TEMP(K) = F(L + K) + TP1
         F(L + K) = TEMP(K)
         K = K - 1
c
 4620    TEMP(K) = F(L + K) + TP1
         F(L + K) = TEMP(K) + F(L + K + 1)
         K = K - 1
         if (K .ne. 0) go to 4620
c ********
c COMPUTE Y-S OBTAINED USING INTEGRATION
c ********
c     TEST IF NEXT Y TO BE OBTAINED BY INTERPOLATION
 4630    continue
c$$   COL1(STIFF,1)
c     IF (INTEG.EQ.0) GO TO 4662
         IY = IY + 1
c     FORM INNER PRODUCT
         TP2 = C0
         do 4650 J = INTEGS + N + 1, INTEGS + 2, -1
            TP2 = TP2 + G(J, INTEG) * TEMP(J)
 4650       continue
         K = INTEG + INTEGS
         do 4660 J = K, 1, -1
            TP2 = TP2 + G(1, J) * YN(IY + J)
 4660       continue
         Y(IY) = YN(IY) + TP2
         INTEG = INTEG - 1
         if (K) 4670, 4670, 4630
c END OF COMPUTING Y-S OBTAINED BY INTEGRATION
c ********
c COMPUTE Y-S OBTAINED USING INTERPOLATION AND DIFFERENTIATION
c ********
c$$   COL1(STIFF)
c.    RESTORE INTEGS FOR EQUATIONS WHICH ARE NOT STIFF
c4662 INTEGS=-1
c     IY=IY+1
c.    COMPUTE Y USING INTERPOLATION
c     Y(IY)=YN(IY) + F(L+2)
c     IF (KQQ.EQ.1) Y(IY)=YN(IY)
c4663 INTEG=INTEG+1
c     IF (INTEG.EQ.JS) IF (IMPLIC) 4680,4680,4664
c.    COMPUTE INTEG-TH DERIVATIVE
c     TP2 = C0
c4664 DO 4666 J = KQQ+1, INTEG+1, -1
c        TP2 = TP2 + D(J, INTEG) * TEMP(J)
c4666 CONTINUE
c     IF (INTEG.EQ.JS) GO TO 4667
c     IY=IY+1
c     Y(IY)=TP2
c     GO TO 4663
c.STORE PREDICTED VALUE FOR F
c4667 CONTINUE
c     F(L+NUMDT)=TP2
c$$   COL1(STIFF,0)
 4670    L = L + NUMDT
 4680    continue
      LDT = -3
      return
c$$   END OF -IVAPR
      end

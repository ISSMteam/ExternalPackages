      SUBROUTINE SCALK8(A,B,C,D,KMAJOR,KMINOR)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1989-10-31 SCALK8 CLL  Force rounding of MKAJOR for Cray.
C>> 1985-08-02 SCALK8 Lawson  Initial code.
C     SCALK8  LIST  SELECT PLEASANT GRID BOUNDARIES
C     C.L.LAWSON,JPL,1965 JUL  7
C     C.L.L.,JPL,1967 FEB 20 CHANGED TO MAKE C AND D ALWAYS
C     BE MULTIPLES OF UNIT.
C     MODIFIED BY CLL 7/14/72 FOR A,B CLOSE TO UNDER/OVER FLOW
C     INPUT..  A,B          OUTPUT..  C,D,KMAJOR,KMINOR
C
C     A AND B ARE MIN AND MAX (OR MAX AND MIN) VALUES
C     OF A VARIABLE (EITHER ABCISSA OR ORDINATE) TO BE GRAPHED.
C     KMAJOR IS THE RECOMMENDED NO. OF MAJOR GRID SUBDIVISIONS.
C     KMINOR IS THE RECOMMENDED NO. OF SUBDIVISIONS WITHIN A MAJOR
C     SUBDIVISION.
C     C AND D ARE PLEASANT VALUES TO BE ASSIGNED TO
C     THE LEFTMOST AND RIGHTMOST GRID BOUNDARIES.
C     THE CLOSED INTERVAL (C,D) WILL CONTAIN THE THE VALUES A AND B.
C     ******************************************************************
      REAL SPAN(18),EKMN(18)
      REAL LN10
      DATA LN10/2.30258509/
      DATA IMAX/14/
      DATA(SPAN(I),I=1,8)/12.,14.,15.,16.,20.,25.,30.,35./
C     DATA(KMAJ(I),I=1,8)/ 6., 7., 3., 8., 4., 5., 6., 7./
      DATA(EKMN(I),I=1,8)/ 2., 2., 5., 2., 5., 5., 5., 5./
      DATA(SPAN(I),I=9,14)/40.,50.,60.,70.,80.,100./
C     DATA(KMAJ(I),I=9,14)/ 8., 5., 6., 7., 8., 5./
      DATA(EKMN(I),I=9,14)/ 5., 10.,10.,10.,10., 20./
      DATA EPSLON/.0001/
C     *****************************************************************
C     CHANGE A,B TO A1,B1
      A1=A
      B1=B
      IF(B1-A1)30,10,40
C     HERE IF A1 .EQ. B1
   10 IF(A1 .EQ. 0.) GO TO 20
      SMALL=.01*ABS(A1)
      A1=A1-SMALL
      B1=B1+SMALL
      GO TO 40
   20 A1=-1.
      B1=+1.
      GO TO 40
   30 B2=A1
      A1=B1
      B1=B2
   40 CONTINUE
C     NOW A1 IS .LT. B1
C
C     PERTURB A1 AND B1 TO AVOID BAD
C     DECISIONS DUE TO ROUND-OFF.
      A2=A1
      B2=B1
      SMALL=(B1-A1)*EPSLON
      IF(A1.NE.0.0) A1=A1+SMALL
      IF(B1.NE.0.0) B1=B1-SMALL
      BMA=B1-A1
      IF(BMA .GT. 0.) GO TO 50
      A1=A2
      B1=B2
      BMA=B1-A1
   50 CONTINUE
C     CONVERT BMA TO X*10**G = X*P WITH 10. .LT. X .LE. 100.
      V=LOG10(BMA)
      G=REAL(INT(V))
      F=V-G
      IF(F)60,60,70
   60 F=F+1.
C     X=10. ** (F+1.)
   70 X=EXP( (F+1.) * LN10)
      P=BMA/X
      IF(X.GT.10.)GO TO 80
      X=X*10.
      P=P/10.
C     ENTER SPAN( ) TABLE USING X
   80 DO 90 I=1,IMAX
      IF(X .LE. SPAN(I))GO TO 95
   90 CONTINUE
      I=IMAX
C     DETERMINE WHETHER SPAN(I) CAN BE USED
   95 DO 105 K=1,3
  100 UNIT=EKMN(I)*P
      C1=UNIT*REAL(INT(A1/UNIT))
      IF(C1 .GT. A1)C1=C1-UNIT
      D1=C1+SPAN(I)*P
      IF(B1 .LE. D1)GO TO 110
      I=I+1
      IF(I.LE.IMAX)GO TO 100
      I=1
      P=P*10.
  105 CONTINUE
C     TROUBLE A OR B CLOSE TO UNDER/OVER FLOW
      WRITE(6,1000) A,B,C,D
  110 C=REAL(MIN(C1,A2))
      D=REAL(MAX(D1,B2))
      KMAJOR=int(0.5 + SPAN(I)/EKMN(I))
      KMINOR=EKMN(I)
 1000 FORMAT(' SCALEK ERROR.. A,B,C,D,=',4E20.8)
      RETURN
      END

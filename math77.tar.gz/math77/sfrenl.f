c     .  Copyright (C) 1992, California Institute of Technology.
c     .  U. S. Government sponsorship under
c     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-09-15 SFRENL WV Snyder Specializing instructions
c>> 1992-04-13 SFRENL WV Snyder Declare SFRENF, SFRENG, SFRENS
c>> 1992-03-18 SFRENL WV Snyder Move declarations for coefficient arrays
c>> 1992-01-24 SFRENL WV Snyder Original code
c Entries in this subprogram compute the Fresnel Cosine and Sine
c integrals C(x) and S(x), and the auxiliary functions f(x) and g(x),
c for any X:
c     SFRENC(X) for Fresnel integral C(X)
c     SFRENS(X) for Fresnel integral S(x)
c     SFRENF(X) for Fresnel integral auxiliary function f(x)
c     SFRENG(X) for Fresnel integral auxiliary function g(x).
c 
c Developed by W. V. Snyder, Jet Propulsion Laboratory, 24 January 1992.
c 
c Ref: W. J. Cody, "Chebyshev Approximations for the Fresnel Integrals",
c Mathematics of Computation, 1968, pp 450-453 plus Microfiche Suppl.
c Accuracies of highest order formulae, where E is relative error:
c
c Range           Function   -log10(E)   Function   -log10(E)
c |X|<=1.2          C(x)       16.24       S(x)       17.26
c 1.2<|X|<=1.6      C(x)       17.47       S(x)       18.66
c 1.6<|X|<=1.9      f(x)       17.13       g(x)       16.25
c 1.9<|X|<=2.4      f(x)       16.64       g(x)       15.65
c 2.4<|X|           f(x)       16.89       g(x)       15.58
c
c Refer to Cody for accuracy of other approximations.
c 
c-----------------------------------------------------------------------
c 
      real             function SFRENC (X)
      real             X
c 
c--   S version uses SFRENC,sfrenc,SFRENF,SFRENG,SFRENS,R1MACH,r1mach
c--   D version uses DFRENC,dfrenc,DFRENF,DFRENG,DFRENS,D1MACH,d1mach
c
c SFRENF, SFRENG, SFRENS are alternate entries.
      real             SFRENF, SFRENG, SFRENS
c 
c PID2 is pi / 2.
      real             PID2
      parameter (PID2 = 1.570796326794896619231321691639751442099e0)
c RPI is the reciprocal of PI:
      real             RPI
      parameter (RPI = 0.3183098861837906715377675267450287240689e0)
c RPISQ is the reciprocal of PI squared:
      real             RPISQ
      parameter (RPISQ = RPI * RPI)
c AX is abs(x).
c BIGX is 1/sqrt(round-off).  If X > BIGX then to the working
c         precision x**2 is an integer (which we assume to be a multiple
c         of four), so cos(pi/2 * x**2) = 1, and sin(pi/2 * x**2) = 0.
c C and S are values of C(x) and S(x), respectively.
c CX and SX are cos(pi/2 * ax**2) and sin(pi/2 * ax**2), respectively.
c F and G are used to compute f(x) and g(x) when X > 1.6.
c HAVEC, HAVEF, HAVEG, HAVES are logical variables that indicate
c         whether the values stored in C, F, G and S correspond to the
c         value stored in X.  HAVEF indicates we have both F and G when
c         XSAVE .le. 1.6, and HAVEC indicates we have both C and S when
c         XSAVE .gt. 1.6.
c LARGEF is 1/(pi * underflow).  If X > LARGEF then f ~ 0.
c LARGEG is cbrt(1/(pi**2 * underflow)).  If X > LARGEG then g ~ 0.
c LARGEX is 1/sqrt(sqrt(underflow)).  If X > LARGEX then f ~ 1/(pi * x)
c         and g ~ 1/(pi**2 * x**3).
c MODE indicates the function to be computed: 1 = C(x), 2 = S(x),
c         3 = f(x), 4 = g(x).
c NEEDC, NEEDF, NEEDG, NEEDS are arrays indexed by MODE (MODE+4 when
c         X .gt. 1.6) that indicate what functions are needed.
c RESULT is equivalenced to C, F, G, and S.
c WANTC indicates whether C and S must be computed from F and G.
c WANTF and WANTG indicate we computed F and G on the present call.
c XSAVE is the most recently provided value of X.
c X4 is either X ** 4 or (1.0/X) ** 4.
      real             AX, BIGX, C, CX, F, G, LARGEF, LARGEG, LARGEX
      real             RESULT(4), S, SX, XSAVE, X4
      save BIGX, C, F, G, LARGEF, LARGEG, LARGEX, S, RESULT, XSAVE
      equivalence (RESULT(1), C), (RESULT(2), S)
      equivalence (RESULT(3), F), (RESULT(4), G)
      logical HAVEC, HAVEF, HAVEG, HAVES, WANTC, WANTF, WANTG
      save HAVEC, HAVEF, HAVEG, HAVES
      integer MODE
      logical NEEDC(8), NEEDF(8), NEEDG(8), NEEDS(8)
      external R1MACH
      real             R1MACH
c     Declarations for coefficient arrays.  If you change the order of
c     approximation, you must change the declaration here, the DATA
c     statements below, and the executable statements that evaluate
c     the approximations.
c     real             PC1(0:1), QC1(1:1)
c     real             PC1(0:2), QC1(1:2)
c     real             PC1(0:3), QC1(1:3)
      real             PC1(0:4), QC1(1:4)
c     real             PC2(0:1), QC2(1:1)
c     real             PC2(0:2), QC2(1:2)
c     real             PC2(0:3), QC2(1:3)
c     real             PC2(0:4), QC2(1:4)
      real             PC2(0:5), QC2(1:5)
c     real             PS1(0:1), QS1(1:1)
c     real             PS1(0:2), QS1(1:2)
c     real             PS1(0:3), QS1(1:3)
      real             PS1(0:4), QS1(1:4)
c     real             PS2(0:1), QS2(1:1)
c     real             PS2(0:2), QS2(1:2)
c     real             PS2(0:3), QS2(1:3)
c     real             PS2(0:4), QS2(1:4)
      real             PS2(0:5), QS2(1:5)
c     real             PF1(0:1), QF1(1:1)
c     real             PF1(0:2), QF1(1:2)
c     real             PF1(0:3), QF1(1:3)
c     real             PF1(0:4), QF1(1:4)
      real             PF1(0:5), QF1(1:5)
c     real             PF2(0:1), QF2(1:1)
c     real             PF2(0:2), QF2(1:2)
c     real             PF2(0:3), QF2(1:3)
c     real             PF2(0:4), QF2(1:4)
      real             PF2(0:5), QF2(1:5)
c     real             PF3(0:0)
c     real             PF3(0:1), QF3(1:1)
c     real             PF3(0:2), QF3(1:2)
c     real             PF3(0:3), QF3(1:3)
c     real             PF3(0:4), QF3(1:4)
c     real             PF3(0:5), QF3(1:5)
      real             PF3(0:6), QF3(1:6)
c     real             PG1(0:1), QG1(1:1)
c     real             PG1(0:2), QG1(1:2)
c     real             PG1(0:3), QG1(1:3)
c     real             PG1(0:4), QG1(1:4)
      real             PG1(0:5), QG1(1:5)
c     real             PG2(0:1), QG2(1:1)
c     real             PG2(0:2), QG2(1:2)
c     real             PG2(0:3), QG2(1:3)
c     real             PG2(0:4), QG2(1:4)
      real             PG2(0:5), QG2(1:5)
c     real             PG3(0:0)
c     real             PG3(0:1), QG3(r:1)
c     real             PG3(0:2), QG3(1:2)
c     real             PG3(0:3), QG3(1:3)
c     real             PG3(0:4), QG3(1:4)
c     real             PG3(0:5), QG3(1:5)
      real             PG3(0:6), QG3(1:6)
c 
      data BIGX /-1.0e0/
      data C /0.0e0/, F /0.5e0/, G /0.5e0/, S /0.0e0/, XSAVE /0.0e0/
      data HAVEC/.TRUE./, HAVEF/.TRUE./, HAVEG/.TRUE./, HAVES/.TRUE./
c        C(x)    S(x)    f(x)    g(x)    C(x)    S(x)    f(x)    g(x)
      data NEEDC
     1 /.TRUE., .FALSE.,.TRUE., .TRUE., .TRUE., .FALSE.,.FALSE.,.FALSE./
      data NEEDS
     1 /.FALSE.,.TRUE., .TRUE., .TRUE., .FALSE.,.TRUE., .FALSE.,.FALSE./
      data NEEDF
     1 /.FALSE.,.FALSE.,.TRUE., .FALSE.,.TRUE., .TRUE., .TRUE., .FALSE./
      data NEEDG
     1 /.FALSE.,.FALSE.,.FALSE.,.TRUE. ,.TRUE., .TRUE., .FALSE.,.TRUE. /
c 
c     Coefficients for C(x), |X| <= 1.2
c 
c     data pc1(0) / 1.00053 e0 /
c     data pc1(1) /-1.12353 e-1/, qc1(1) /1.38937 e-1/
c     data pc1(0)/  9.99999 896 e-1/
c     data pc1(1)/ -1.63090 954 e-1/, qc1(1) /8.36467 414 e-2/
c     data pc1(2)/  1.06388 604 e-2/, qc1(2) /3.10155 884 e-3/
c     data pc1(0) / 1.00000 00000 042 e0 /
c     data pc1(1) /-1.86511 27631 106 e-1/
c     data qc1(1) / 6.02288 33908 128 e-2/
c     data pc1(2) / 1.50656 63274 457 e-2/
c     data qc1(2) / 1.74103 00558 198 e-3/
c     data pc1(3) /-3.10580 74693 185 e-4/
c     data qc1(3) / 2.63086 17899 210 e-5/
      data pc1(0) / 9.99999 99999 99999 421 e-1/
      data pc1(1) /-1.99460 89882 61842 706 e-1/
      data qc1(1) / 4.72792 11201 04532 689 e-2/
      data pc1(2) / 1.76193 95254 34914 045 e-2/
      data qc1(2) / 1.09957 21502 56418 851 e-3/
      data pc1(3) /-5.28079 65137 26226 960 e-4/
      data qc1(3) / 1.55237 88527 69941 331 e-5/
      data pc1(4) / 5.47711 38568 26871 660 e-6/
      data qc1(4) / 1.18938 90142 28757 184 e-7/
c 
c     Coefficients for C(x), 1.2 < |X| <= 1.6
c     data pc2(0) / 1.3139 e0 /
c     data pc2(1) /-5.8827 e-2/, qc2(1) / 4.7324 e-1/
c     data pc2(0) / 9.97908 90 e-1/
c     data pc2(1) /-1.53918 95 e-1/, qc2(1) / 8.98786 47 e-2/
c     data pc2(2) / 9.98179 33 e-3/, qc2(2) / 5.60030 71 e-3/
c     data pc2(0) / 1.00000 44010 9 e0 /
c     data pc2(1) /-1.83413 85190 8 e-1/, qc2(1) / 6.33347 44563 7 e-2/
c     data pc2(2) / 1.45776 17082 8 e-2/, qc2(2) / 2.01245 73836 9 e-3/
c     data pc2(3) /-2.78980 70527 0 e-4/, qc2(3) / 4.03949 00464 6 e-5/
c     data pc2(0) / 9.99999 99664 96876 e-1/
c     data pc2(1) /-1.98030 09870 22688 e-1/
c     data qc2(1) / 4.87100 03089 97918 e-2/
c     data pc2(2) / 1.73551 87484 50023 e-2/
c     data qc2(2) / 1.18840 69740 04084 e-3/
c     data pc2(3) /-5.06944 22979 35788 e-4/
c     data qc2(3) / 1.82452 76358 43850 e-5/
c     data pc2(4) / 5.05996 22546 78234 e-6/
c     data qc2(4) / 1.67831 42578 74103 e-7/
      data pc2(0) / 1.00000 00000 01110 43640 e0 /
      data pc2(1) /-2.07073 36033 53238 94245 e-1/
      data qc2(1) / 3.96667 49695 23234 33510 e-2/
      data pc2(2) / 1.91870 27943 17469 26505 e-2/
      data qc2(2) / 7.88905 24505 23599 07842 e-4/
      data pc2(3) /-6.71376 03469 49221 09230 e-4/
      data qc2(3) / 1.01344 63086 67494 06081 e-5/
      data pc2(4) / 1.02365 43505 61058 64908 e-5/
      data qc2(4) / 8.77945 37789 23692 65356 e-8/
      data pc2(5) /-5.68293 31012 18707 28343 e-8/
      data qc2(5) / 4.41701 37406 50096 20393 e-10/
c 
c     Coefficients for S(x), |X| <= 1.2
c     data ps1(0) / 5.23677 e-1/
c     data ps1(1) /-4.67900 e-2/, qs1(1) / 8.81622 e-2/
c     data ps1(0) / 5.23598 7665 e-1/
c     data ps1(1) /-5.83776 3961 e-2/, qs1(1) / 6.47494 4765 e-2/
c     data ps1(2) / 2.16592 0196 e-3/, qs1(2) / 1.71328 7588 e-3/
c     data ps1(0) / 5.23598 77559 8566 e-1/
c     data ps1(1)/ -6.59149 58113 9046 e-2/
c     data qs1(1) / 5.03546 38867 0085 e-2/
c     data ps1(2) / 3.21501 64982 8293 e-3/
c     data qs1(2) / 1.17835 98035 6588 e-3/
c     data ps1(3) /-4.88704 43624 0178 e-5/
c     data qs1(3) / 1.37089 87582 6980 e-5/
      data ps1(0) / 5.23598 77559 82988 7021 e-1/
      data ps1(1) /-7.07489 91514 45230 2596 e-2/
      data qs1(1) / 4.11223 15114 23842 2205 e-2/
      data ps1(2) / 3.87782 12346 36828 7939 e-3/
      data qs1(2) / 8.17091 94215 21344 7204 e-4/
      data ps1(3) /-8.45557 28435 27768 0591 e-5/
      data qs1(3) / 9.62690 87593 90340 3370 e-6/
      data ps1(4) / 6.71748 46662 51408 6196 e-7/
      data qs1(4) / 5.95281 22767 84099 8345 e-8/
c 
c     coefficients for S(x), 1.2 < |X| <= 1.6
c     data ps2(0) / 5.4766 e-1/
c     data ps2(1) /-3.7151 e-2/, qs2(1) / 1.4559 e-1/
c     data ps2(0) / 5.23439 94 e-1/
c     data ps2(1) /-5.48283 47 e-2/, qs2(1) / 7.11047 04 e-2/
c     data ps2(2) / 1.90208 81 e-3/, qs2(2) / 2.55962 74 e-3/
c     data ps2(0) / 5.23599 04049 8 e-1/
c     data ps2(1) /-6.46593 39242 6 e-2/, qs2(1) / 5.27536 68168 5 e-2/
c     data ps2(2) / 3.08030 79436 1 e-3/, qs2(2) / 1.34311 02682 1 e-3/
c     data ps2(3) /-4.40800 85441 8 e-5/, qs2(3) / 1.90476 61284 9 e-5/
c     data ps2(0) / 5.23598 77543 50917 8 e-1/
c     data ps2(1) /-7.01490 76634 83366 2 e-2/
c     data qs2(1) / 4.22680 67370 39548 7 e-2/
c     data ps2(2) / 3.80315 81605 98703 8 e-3/
c     data qs2(2) / 8.76427 53831 07323 7 e-4/
c     data ps2(3) /-8.09649 48714 40815 6 e-5/
c     data qs2(3) / 1.10885 42889 78928 2 e-5/
c     data ps2(4) / 6.19080 80210 05277 2 e-7/
c     data qs2(4) / 7.87258 29545 47846 4 e-8/
      data ps2(0) / 5.23598 77559 83441 65913 e-1/
      data ps2(1) /-7.37766 91401 01913 23867 e-2/
      data qs2(1) / 3.53398 34276 74721 62540 e-2/
      data ps2(2) / 4.30730 52650 43665 10217 e-3/
      data qs2(2) / 6.18224 62019 54732 16538 e-4/
      data ps2(3) /-1.09540 02391 14349 94566 e-4/
      data qs2(3) / 6.87086 26571 86201 17905 e-6/
      data ps2(4) / 1.28531 04374 27248 20610 e-6/
      data qs2(4) / 5.03090 58124 66123 75866 e-8/
      data ps2(5) /-5.76765 81559 30888 04567 e-9/
      data qs2(5) / 2.05539 12445 85795 96075 e-10/
c 
c     coefficients for f(x), 1.6 < |X| <= 1.9
c     data pf1(0) / 3.18035 19 e-1/
c     data pf1(1) / 4.23523 32 e-1/, qf1(1) / 1.60154 03 e0 /
c     data pf1(0) / 3.18285 25209 4 e-1/
c     data pf1(1) / 2.02860 27571 3 e0 /, qf1(1) / 6.67171 54813 5 e0 /
c     data pf1(2) / 1.08108 13604 8 e0 /, qf1(2) / 4.52997 55397 2 e0 /
c     data pf1(0) / 3.18306 46311 448 e-1/
c     data pf1(1) / 4.60772 49266 684 e0 /
c     data qf1(1) / 1.47784 64938 936 e1 /
c     data pf1(2) / 1.19145 78438 074 e1 /
c     data qf1(2) / 4.09029 71163 705 e1 /
c     data pf1(3) / 3.55550 73665 830 e0 /
c     data qf1(3) / 1.61304 32784 819 e1 /
c     data pf1(0) / 3.18309 26850 49059 9 e-1/
c     data pf1(1) / 8.03588 12280 39415 6 e0 /
c     data qf1(1) / 2.55491 61843 57952 9 e1 /
c     data pf1(2) / 4.80340 65557 79248 7 e1 /
c     data qf1(2) / 1.57611 00558 01225 0 e2 /
c     data pf1(3) / 6.98534 26160 10206 5 e1 /
c     data qf1(3) / 2.49561 99380 51722 9 e2 /
c     data pf1(4) / 1.35304 23554 03878 4 e1 /
c     data qf1(4) / 6.55630 64008 39155 4 e1 /
      data pf1(0) / 3.18309 75293 58098 5290 e-1/
      data pf1(1) / 1.22260 00551 67296 1219 e1 /
      data qf1(1) / 3.87130 03365 58344 2831 e1 /
      data pf1(2) / 1.29248 86131 90165 7025 e2 /
      data qf1(2) / 4.16743 59830 70562 9745 e2 /
      data pf1(3) / 4.38863 67156 69554 7655 e2 /
      data qf1(3) / 1.47400 30733 96661 0568 e3 /
      data pf1(4) / 4.14667 22177 95896 1672 e2 /
      data qf1(4) / 1.53716 75584 89575 9916 e3 /
      data pf1(5) / 5.67714 63664 18511 6454 e1 /
      data qf1(5) / 2.91130 88788 84783 1515 e2 /
c 
c     coefficients for f(x), 1.9 < |X| <= 2.4
c     data pf2(0) / 3.18251 12 e-1/
c     data pf2(1) / 5.83959 51 e-1/, qf2(1) / 2.12439 44 e0 /
c     data pf2(0) / 3.18306 99932 e-1/
c     data pf2(1) / 2.99934 57087 e0 /, qf2(1) / 9.72545 17756 e0 /
c     data pf2(2) / 2.39563 40010 e0 /, qf2(2) / 9.48140 77696 e0 /
c     data pf2(0) / 3.18309 63944 521 e-1/
c     data pf2(1) / 7.07704 31878 327 e0 /
c     data qf2(1) / 2.25369 94405 207 e1 /
c     data pf2(2) / 2.87560 83262 903 e1 /
c     data qf2(2) / 9.61275 68469 278 e1 /
c     data pf2(3) / 1.35836 85742 326 e1 /
c     data qf2(3) / 5.74070 28004 031 e1 /
c     data pf2(0) / 3.18309 85686 40159 e-1/
c     data pf2(1) / 1.26512 94696 83175 e1 /
c     data qf2(1) / 4.00491 53027 81009 e1 /
c     data pf2(2) / 1.21946 76164 98339 e2/
c     data qf2(2) / 3.94205 96979 51583 e2/
c     data pf2(3) / 2.91003 36555 12762 e2/
c     data qf2(3) / 1.00136 84034 95691 e3/
c     data pf2(4) / 9.27839 78286 31516 e1/
c     data qf2(4) / 4.14267 62242 22433 e2/
      data pf2(0) / 3.18309 88182 20169 217 e-1/
      data pf2(1) / 1.95883 94102 19691 002 e1 /
      data qf2(1) / 6.18427 13817 28873 709 e1 /
      data pf2(2) / 3.39837 13492 69842 400 e2 /
      data qf2(2) / 1.08535 06750 06501 251 e3 /
      data pf2(3) / 1.93007 64078 67157 531 e3 /
      data qf2(3) / 6.33747 15585 11437 898 e3 /
      data pf2(4) / 3.09145 16157 44296 552 e3 /
      data qf2(4) / 1.09334 24898 88087 888 e4 /
      data pf2(5) / 7.17703 24936 51399 590 e2 /
      data qf2(5) / 3.36121 69918 05511 494 e3 /
c 
c     coefficients for f(x), 2.4 < |X|
c     data pf3(0) /-8.97969 e-2/
c     data pf3(0) /-9.67122 165 e-2/
c     data pf3(1) /-3.73565 920 e-1/, qf3(1) / 7.29466 572 e0 /
c     data pf3(0) /-9.67541 44364 8 e-2/
c     data pf3(1) /-2.26566 29381 8 e0 /, qf3(1) / 2.69596 93997 7 e1 /
c     data pf3(2) /-3.53429 82108 4 e0 /, qf3(2) / 9.72883 95746 9 e1 /
c     data pf3(0) /-9.67545 96389 025 e-2/
c     data pf3(1) /-5.52549 43840 897 e0 /
c     data qf3(1) / 6.06544 83020 979 e1 /
c     data pf3(2) /-5.86062 82086 171 e1 /
c     data qf3(2) / 7.85288 41711 294 e2 /
c     data pf3(3) /-5.22355 60918 394 e1 /
c     data qf3(3) / 1.85924 98578 831 e3 /
c     data pf3(0) /-9.67546 03169 52504 e-2/
c     data pf3(1) /-1.02387 64281 29288 e1 /
c     data qf3(1) / 1.09368 22440 53459 e2 /
c     data pf3(2) /-2.71257 96340 37998 e2 /
c     data qf3(2) / 3.15584 34619 20557 e3 /
c     data pf3(3) /-1.76611 93452 82127 e3 /
c     data qf3(3) / 2.62563 43162 04420 e4 /
c     data pf3(4) /-1.04346 44266 56267 e3 /
c     data qf3(4) / 4.57825 20572 46393 e4 /
c     data pf3(0) /-9.67546 03296 70903 80 e-2/
c     data pf3(1) /-1.64797 71284 12457 67 e1 /
c     data qf3(1) / 1.73871 69067 36491 14 e2 /
c     data pf3(2) /-8.16343 40178 43745 98 e2 /
c     data qf3(2) / 9.01827 59623 15241 47 e3 /
c     data pf3(3) /-1.34922 02817 18572 48 e4 /
c     data qf3(3) / 1.65946 46262 18531 84 e5 /
c     data pf3(4) /-6.13547 11361 46997 72 e4 /
c     data qf3(4) / 1.00105 47890 07913 39 e6 /
c     data pf3(5) /-2.61294 75322 51417 79 e4 /
c     data qf3(5) / 1.37012 36481 72259 72 e6 /
      data pf3(0) /-9.67546 03299 52532 343 e-2/
      data pf3(1) /-2.43127 54071 94161 683 e1 /
      data qf3(1) / 2.54828 90129 49732 752 e2 /
      data pf3(2) /-1.94762 19983 06889 176 e3 /
      data qf3(2) / 2.09976 15368 57815 105 e4 /
      data pf3(3) /-6.05985 21971 60773 639 e4 /
      data qf3(3) / 6.92412 25098 27708 985 e5 /
      data pf3(4) /-7.07680 69528 37779 823 e5 /
      data qf3(4) / 9.17882 32299 18143 780 e6 /
      data pf3(5) /-2.41765 67490 61154 155 e6 /
      data qf3(5) / 4.29273 32556 30186 679 e7 /
      data pf3(6) /-7.83491 45900 78317 336 e5 /
      data qf3(6) / 4.80329 47842 60528 342 e7 /
c 
c     coefficients for g(x), 1.6 < |X| <= 1.9
c     data pg1(0) / 1.00701 1 e-1/
c     data pg1(1) / 1.45778 0 e-1/, qg1(1) / 2.70025 3 e0 /
c     data pg1(0) / 1.01250 0483 e-1/
c     data pg1(1) / 7.73520 7446 e-1/, qg1(1) / 9.10195 6178 e0 /
c     data pg1(2) / 3.87828 2770 e-1/, qg1(2) / 1.00223 4185 e1 /
c     data pg1(0) / 1.01309 54368 17 e-1/
c     data pg1(1) / 1.73193 79841 73 e0 /
c     data qg1(1) / 1.86007 74300 76 e1 /
c     data pg1(2) / 5.03658 82452 65 e0 /
c     data qg1(2) / 6.90195 19357 25 e1 /
c     data pg1(3) / 1.29070 72465 07 e0 /
c     data qg1(3) / 4.30891 86599 89 e1 /
c     data pg1(0) / 1.01318 80965 09180 e-1/
c     data pg1(1) / 2.96622 05547 25899 e0 /
c     data qg1(1) / 3.07917 87367 24045 e1 /
c     data pg1(2) / 2.01543 52995 05393 e1 /
c     data qg1(2) / 2.36287 43189 80473 e2 /
c     data pg1(3) / 3.15560 56793 87908 e1 /
c     data qg1(3) / 4.95386 12582 48338 e2 /
c     data pg1(4) / 4.91601 28306 46366 e0 /
c     data qg1(4) / 2.02614 44934 03599 e2 /
      data pg1(0) / 1.01320 61881 02747 985 e-1/
      data pg1(1) / 4.44533 82755 05123 778 e0 /
      data qg1(1) / 4.53925 01967 36893 605 e1 /
      data pg1(2) / 5.31122 81348 09894 481 e1 /
      data qg1(2) / 5.83590 57571 64290 666 e2 /
      data pg1(3) / 1.99182 81867 89025 318 e2 /
      data qg1(3) / 2.54473 13318 18221 034 e3 /
      data pg1(4) / 1.96232 03797 16626 191 e2 /
      data qg1(4) / 3.48112 14785 65452 837 e3 /
      data pg1(5) / 2.05421 43249 85006 303 e1 /
      data qg1(5) / 1.01379 48339 60028 555 e3 /
c 
c     coefficients for g(x), 1.9 < |X| <= 2.4
c     data pg2(0) / 1.01171 1 e-1/
c     data pg2(1) / 2.23963 0 e-1/, qg2(1) / 3.60923 7 e0 /
c     data pg2(0) / 1.01311 5463 e-1/
c     data pg2(1) / 1.18202 1191 e0 /, qg2(1) / 1.31721 9285 e1 /
c     data pg2(2) / 9.88631 5969 e-1/, qg2(2) / 2.10110 4994 e1 /
c     data pg2(0) / 1.01320 20256 53 e-1/
c     data pg2(1) / 2.69076 70137 70 e0 /
c     data qg2(1) / 2.80745 70055 00 e1 /
c     data pg2(2) / 1.28362 47492 71 e1 /
c     data qg2(2) / 1.59870 43135 22 e2 /
c     data pg2(3) / 5.79133 75877 23 e0 /
c     data qg2(3) / 1.52563 03850 45 e2 /
c     data pg2(0) / 1.01321 05094 09046 e-1/
c     data pg2(1) / 4.68276 97697 57399 e0 /
c     data qg2(1) / 4.77365 29667 04634 e1 /
c     data pg2(2) / 5.24135 16133 46472 e1 /
c     data qg2(2) / 5.80203 69679 47208 e2 /
c     data pg2(3) / 1.41173 59445 50041 e2 /
c     data qg2(3) / 1.94717 93272 44406 e3 /
c     data pg2(4) / 4.01975 60127 88710 e1 /
c     data qg2(4) / 1.26604 12369 60445 e3 /
      data pg2(0) / 1.01321 16176 18045 86 e-1/
      data pg2(1) / 7.11205 00178 97828 23 e0 /
      data qg2(1) / 7.17128 59693 93021 98 e1 /
      data pg2(2) / 1.40959 61791 13155 24 e2 /
      data qg2(2) / 1.49051 92279 73292 29 e3 /
      data pg2(3) / 9.08311 74952 95939 38 e2 /
      data qg2(3) / 1.06729 67803 05808 97 e4 /
      data pg2(4) / 1.59268 00608 53538 64 e3 /
      data qg2(4) / 2.41315 56721 33697 42 e4 /
      data pg2(5) / 3.13330 16306 87559 50 e2 /
      data qg2(5) / 1.15149 83237 62606 04 e4 /
c 
c     coefficients for g(x), 2.4 < |X|
c     data pg3(0) /-1.3549 e-1/
c     data pg3(0) /-1.53828 24 e-1/
c     data pg3(1) /-6.45474 64 e-1/, qg3(1) / 1.02903 28 e1 /
c     data pg3(0) /-1.53987 60302 e-1/
c     data pg3(1) /-4.27728 57997 e0 /, qg3(1) / 3.41499 86477 e1 /
c     data pg3(2) /-6.59401 81141 e0 /, qg3(2) / 1.70717 08816 e2 /
c     data pg3(0) /-1.53989 69716 16 e-1/
c     data pg3(1) /-1.02463 83144 46 e1 /
c     data qg3(1) / 7.29222 93037 54 e1 /
c     data pg3(2) /-1.25250 74021 20 e2 /
c     data qg3(2) / 1.18652 86732 48 e3 /
c     data pg3(3) /-1.02918 96761 44 e2 /
c     data qg3(3) / 3.84443 09084 76 e3 /
c     data pg3(0) /-1.53989 73305 7971 e-1/
c     data pg3(1) / -1.86483 22383 1639 e1/
c     data qg3(1) / 1.27484 29807 5273 e2 /
c     data pg3(2) /-5.66882 77802 6550 e2 /
c     data qg3(2) / 4.40258 85815 9927 e3 /
c     data pg3(3) /-4.16714 64701 7489 e3 /
c     data qg3(3) / 4.57583 83069 4684 e4 /
c     data pg3(4) /-2.14678 07436 4341 e3 /
c     data qg3(4) / 1.08207 88328 1275 e5 /
c     data pg3(0) /-1.53989 73380 19247 e-1/
c     data pg3(1) /-2.95907 82318 55258 e1 /
c     data qg3(1) / 1.98543 98135 44440 e2 /
c     data pg3(2) /-1.66186 70871 83632 e3 /
c     data qg3(2) / 1.19669 31345 08007 e4 /
c     data pg3(3) /-3.11279 64549 20657 e4 /
c     data qg3(3) / 2.62557 38645 12749 e5 /
c     data pg3(4) /-1.57353 62868 19766 e5 /
c     data qg3(4) / 1.96905 58293 11119 e6 /
c     data pg3(5) /-5.57488 41137 46041 e4 /
c     data qg3(5) / 3.62908 13333 13312 e6 /
      data pg3(0) /-1.53989 73381 97693 16 e-1/
      data pg3(1) /-4.31710 15782 33575 68 e1 /
      data qg3(1) / 2.86733 19497 58994 83 e2 /
      data pg3(2) /-3.87754 14174 63784 93 e3 /
      data qg3(2) / 2.69183 18039 62425 36 e4 /
      data pg3(3) /-1.35678 86781 37563 47 e5 /
      data qg3(3) / 1.02878 69305 66875 06 e6 /
      data pg3(4) /-1.77758 95083 80296 76 e6 /
      data qg3(4) / 1.62095 60050 02316 46 e7 /
      data pg3(5) /-6.66907 06166 86364 16 e6 /
      data qg3(5) / 9.38695 86253 16351 79 e7 /
      data pg3(6) /-1.72590 22465 48368 45 e6 /
      data qg3(6) / 1.40622 44112 35800 05 e8 /
c 
c     *****     Entries     ********************************************
c 
      mode = 1
      go to 10
      entry SFRENF (X)
      mode = 3
      go to 10
      entry SFRENG (X)
      mode = 4
      go to 10
      entry SFRENS (X)
      mode = 2
c 
c     *****     Executable Statements     ******************************
c 
10    if (bigx .lt. 0.0e0) then
         bigx = 1.0e0 / sqrt(r1mach(4))
         largef = rpi / r1mach(1)
         largeg = (rpi * largef) ** (1.0e0 / 3.0e0)
         largex = 1.0e0/sqrt(sqrt(r1mach(1)))
      end if
      if (x .ne. xsave) then
         havec = .false.
         havef = .false.
         haveg = .false.
         haves = .false.
      end if
      ax = abs(x)
      if (ax .le. 1.6e0) then
         x4 = ax**4
         if (needc(mode) .and. .not. havec) then
            if (ax .le. 1.2e0) then
               c = x * ((((pc1(4)*x4+pc1(3))*x4+pc1(2))*x4+pc1(1))*x4+
     1                     pc1(0))
     2           / ((((qc1(4)*x4+qc1(3))*x4+qc1(2))*x4+qc1(1))*x4+1.0e0)
            else
               c = x * (((((pc2(5)*x4+pc2(4))*x4+pc2(3))*x4+pc2(2))*x4+
     1                     pc2(1))*x4+pc2(0))
     2           /   (((((qc2(5)*x4+qc2(4))*x4+qc2(3))*x4+qc2(2))*x4+
     3                   qc2(1))*x4+1.0e0)
            end if
            havec = .true.
         end if
         if (needs(mode) .and. .not. haves) then
            if (ax .le. 1.2e0) then
               s = x**3*((((ps1(4)*x4+ps1(3))*x4+ps1(2))*x4+ps1(1))*x4+
     1                      ps1(0))
     2           / ((((qs1(4)*x4+qs1(3))*x4+qs1(2))*x4+qs1(1))*x4+1.0e0)
            else
               s = x**3*(((((ps2(5)*x4+ps2(4))*x4+ps2(3))*x4+ps2(2))*x4+
     1                      ps2(1))*x4+ps2(0))
     2           /   (((((qs2(5)*x4+qs2(4))*x4+qs2(3))*x4+qs2(2))*x4+
     3                    qs2(1))*x4+1.0e0)
            end if
            haves = .true.
         end if
         if ((needf(mode) .or. needg(mode)) .and. .not. havef) then
            cx = cos(pid2 * ax*ax)
            sx = sin(pid2 * ax*ax)
            f = (0.5e0 - s) * cx - (0.5e0 - c) * sx
            g = (0.5e0 - c) * cx + (0.5e0 - s) * sx
            havef = .true.
         end if
      else
         if (ax .le. largex) then
            x4 = (1.0e0 / ax) ** 4
            wantf = needf(mode+4) .and. .not. havef
            if (wantf) then
               if (ax .le. 1.9e0) then
                  f = (((((pf1(5)*x4+pf1(4))*x4+pf1(3))*x4+pf1(2))*x4+
     1                    pf1(1))*x4+pf1(0))
     2             / ((((((qf1(5)*x4+qf1(4))*x4+qf1(3))*x4+qf1(2))*x4+
     3                    qf1(1))*x4+1.0e0) * ax)
               else if (ax .le. 2.4) then
                  f = (((((pf2(5)*x4+pf2(4))*x4+pf2(3))*x4+pf2(2))*x4+
     1                    pf2(1))*x4+pf2(0))
     2             / ((((((qf2(5)*x4+qf2(4))*x4+qf2(3))*x4+qf2(2))*x4+
     3                    qf2(1))*x4+1.0e0) * ax)
               else
                  f = (rpi +
     1              x4*((((((pf3(6)*x4+pf3(5))*x4+pf3(4))*x4+pf3(3))*x4+
     2                   pf3(2))*x4+pf3(1))*x4+pf3(0))
     3            /    ((((((qf3(6)*x4+qf3(5))*x4+qf3(4))*x4+qf3(3))*x4+
     4                   qf3(2))*x4+qf3(1))*x4+1.0e0)) / ax
               end if
               havef = .true.
            end if
            wantg = needg(mode+4) .and. .not. haveg
            if (wantg) then
               if (x .le. 1.9e0) then
                  g = (((((pg1(5)*x4+pg1(4))*x4+pg1(3))*x4+pg1(2))*x4+
     1                    pg1(1))*x4+pg1(0))
     2             / ((((((qg1(5)*x4+qg1(4))*x4+qg1(3))*x4+qg1(2))*x4+
     3                    qg1(1))*x4+1.0e0) * ax**3)
               else if (ax .le. 2.4e0) then
                  g = (((((pg2(5)*x4+pg2(4))*x4+pg2(3))*x4+pg2(2))*x4+
     1                     pg2(1))*x4+pg2(0))
     2             / ((((((qg2(5)*x4+qg2(4))*x4+qg2(3))*x4+qg2(2))*x4+
     3                    qg2(1))*x4+1.0e0) * ax**3)
               else
                  g = (rpisq +
     1              x4*((((((pg3(6)*x4+pg3(5))*x4+pg3(4))*x4+pg3(3))*x4+
     2                   pg3(2))*x4+pg3(1))*x4+pg3(0))
     3            /    ((((((qg3(6)*x4+qg3(5))*x4+qg3(4))*x4+qg3(3))*x4+
     4                   qg3(2))*x4+qg3(1))*x4+1.0e0)) / ax**3
               end if
               haveg = .true.
            end if
         else
            wantf = needf(mode)
            if (wantf) then
               if (x .le. largef) then
                  f = rpi / ax
               else
                  f = 0.0e0
               end if
            end if
            wantg = needg(mode)
            if (wantg) then
               if (x .le. largeg) then
                  g = rpisq / ax**3
               else
                  g = 0.0e0
               end if
            end if
         end if
         wantc = (needc(mode+4) .or. needs(mode+4)) .and. .not. havec
         if (wantc .or. x.lt.0.0e0) then
            if (ax .le. bigx) then
               cx = cos(pid2 * ax*ax)
               sx = sin(pid2 * ax*ax)
            else
               cx = 1.0e0
               sx = 0.0e0
            end if
            if (wantc) then
               c = 0.5e0 + f*sx - g*cx
               s = 0.5e0 - f*cx - g*sx
               if (x .lt. 0.0) then
                  c = -c
                  s = -s
               end if
               havec = .true.
            end if
            if (x .lt. 0.0) then
c              We COULD do the following before the preceeding, and then
c              not put in a test in the preceeding for x .lt. 0, but
c              even though the results are mathematically identical, we
c              would have some cancellation above if we did so.
               if (wantg) g = cx + sx - g
               if (wantf) f = cx - sx - f
            end if
          end if
      end if
      xsave = x
c     The Fortran standard says entry names in function subprograms
c     are to be treated as though they appeared in an EQUIVALENCE
c     statement, so we don't need to worry about the one to which
c     we assign the result value.
      sfrenc = result(mode)
      return
      end

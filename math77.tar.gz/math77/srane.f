      real function SRANE(STDDEV)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-03-16 CLL
c>> 1991-11-26 CLL Reorganized common. Using RANCM[A/D/S].
c>> 1991-11-22 CLL Added call to RAN0, and SGFLAG in common.
c>> 1991-01-15 CLL Reordered common contents for efficiency.
C>> 1990-01-23 CLL  Making names in common same in all subprogams.
C>> 1987-04-22 SRANE  Lawson  Initial code.
c        Returns one pseudorandom number from the Exponential
c     distribution with standard deviation, STDDEV, which should be
c     positive.
c     If U is random, uniform on [0, 1], the Exponential variable is
c     given by             SRANE = -STDDEV * log(U)
c     This variable has    mean = STDDEV
c     and                  variance = STDDEV**2
c     Reference: NBS AMS 55, P. 930.
c     Code based on subprogram written for JPL by Stephen L. Ritchie,
c     Heliodyne Corp. and Wiley R. Bunton, JPL, 1969.
c     Adapted to Fortran 77 for the JPL MATH77 library by C. L. Lawson &
c     S. Y. Chiu, JPL, Apr 1987.
c     ------------------------------------------------------------------
c--   D version uses DRANE, DRANUA, RANCMD, DPTR, DNUMS, DGFLAG
c--   S version uses SRANE, SRANUA, RANCMS, SPTR, SNUMS, SGFLAG
C     RANCMS is a common block.
c     Calls RAN0 to initialize SPTR and SGFLAG.
c     ------------------------------------------------------------------
      integer M
      parameter(M = 97)
      real SNUMS(M), STDDEV
      common/RANCMS/SNUMS
c--   Begin mask code changes.
      integer DPTR, SPTR
      logical DGFLAG, SGFLAG
      common/RANCMA/DPTR, SPTR, DGFLAG, SGFLAG
c--   End mask code changes.
      save  /RANCMA/, /RANCMS/, FIRST
      logical FIRST
      data    FIRST / .true. /
c     ------------------------------------------------------------------
      if(FIRST) then
         FIRST = .false.
         call RAN0
      endif
c 
      SPTR = SPTR - 1
      if(SPTR .eq. 0) then
         call SRANUA(SNUMS, M)
         SPTR = M
      endif
      SRANE = -STDDEV * log(SNUMS(SPTR))
      return
      end

      subroutine SMESS (MACT, TEXT, IDAT, FDAT)
c     .  Copyright (C) 1991, California Institute of Technology.
c     .  All rights reserved.  U. S. Government sponsorship under
c     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-05-27 SMESS Krogh  Initialized LDFDEF in a data statement.
c>> 1992-05-14 SMESS Krogh  Put common blocks in save statement.
c>> 1992-04-28 SMESS Krogh  Corrected minor error in floating pt. format
c>> 1992-02-07 SMESS Krogh  Initial Code.
c
c Processes Messages -- Actions are controlled by MACT().  See
c comment is subroutine MESS.  This program is for the extra
c argument of type real.
c
c BUF    In common CMESSC, see MESS.
c DOLS   In common for intitialization, not used here.  See MESS.
c EUNIT  In common for intitialization, not used here.  See MESS.
c FDAT   Formal argument -- gives floating point data to print.
c FMAG   Magnitude of floating point number to output, with negative sign
c   if floating point number is < 0.
c FMIN   Minimum floating point number.
c FMTF   In common CMESSC, format for printing floating point number.
c FMTG   In common CMESSC, user format to use in place of FMTF.
c FNMAX  Maximum negative floating point number.
c FOUT   Floating point number to be output.
c FSMA   Smallest postitive floating point number.
c I1GETD Parameter giving the value to pass to I1MACH to get the number
c   of base b digits in a floating point number.  (=11 for single
c   precision code and =14 for double precision code.)
c I1MACH External function giving integer info. about the environment.
c ICOL   In common CMESSI, see MESS.
c ID     Number of decimal digits for floating point format statement.
c IDAT   Integer data -- passed to MESS.
c IVAR   In common CMESSI, see MESS.
c IWF    In common CMESSI, see MESS.
c IWG    In common CMESSI, see MESS.
c J      Temporary index.
c K      Temporary index.
c KAP    Number of extra 0's after the decimal point in "F" format.  If
c        < 0, -KAP gives the number of extra digits to the left of the
c        decimal point.  KAP depends on abs(smallest number printed).
c KBP    Number of extra digits before the decimal point required by the
c        largest number to be printed.
c KDF    In common CMESSI, see MESS.
c KDFDEF In common CMESSI, see MESS.
c KDIAG  In common CMESSI, not used here, see MESS.
c KEXE   Extra space required for E format.
c KF     In common CMESSI, see MESS.
c KLINE  In common CMESSI, see MESS.
c KSCRN  In common CMESSI, see MESS.
c KRES1  In common CMESSI, see MESS.
c KSPEC  In common CMESSI, see MESS.
c LASTER In common CMESSI, not used here, see MESS.
c LASTI  In common CMESSI, see MESS.
c LBUF   In common CMESSI, see MESS.
c LDFDEF Value of KDFDEF for this routine.  (Saved)
c LENBUF In common CMESSI, see MESS.
c LENLIN In common CMESSI, not used here, see MESS.
c LENTRY In common CMESSI, see MESS.
c LHEAD  In common CMESSI, not used here, see MESS.
c LINERR In common CMESSI, not used here, see MESS.
c LINMSG In common CMESSI, not used here, see MESS.
c LOCBEG In common CMESSI, see MESS.
c LPRINT In common CMESSI, not used here, see MESS.
c LSTOP  In common CMESSI, not used here, see MESS.
c LSTRT  In common CMESSI, see MESS.
c MACT   Formal argument, see MESS.
c MDAT   In common CMESSI, not used here, see MESS.
c MEMDA5 In common CMESSI, see MESS.
c MESS   Program called for most of the message processing.
c MPT    In common CMESSI, see MESS.
c MUNIT  In common CMESSI, not used here, see MESS.
c NCOL   In common CMESSI, see MESS.
c NDIM   In common CMESSI, see MESS.
c NFDAT  In common CMESSI, see MESS.
c NIDAT  In common CMESSI, not used here, see MESS.
c NMDAT  In common CMESSI, not used here, see MESS.
c NTEXT  In common CMESSI, not used here, see MESS.
c OUNIT  In common CMESSI, not used here, see MESS.
c R1MACH External func. giving floating pt. info. about the environment.
c SUNIT  In common CMESSI, not used here, see MESS.
c TEXT   Formal argument, passed to MESS, see there.
c XARGOK In common CMESSI, see MESS.
c
c I1GETD is 11 for real, and 14 for double precision.
      parameter (I1GETD = 11)
      integer          MACT(*), IDAT(*)
      real             FDAT(*)
      character        TEXT(*)
      integer          I1MACH, ICOL, ID, J, K, KAP, KBP, KEXE, LDFDEF
      real             FMAG, FMIN, FOUT, FNMAX, FSMA, R1MACH
      save LDFDEF
      save /CMESSI/, /CMESSC/
c
c ************************** Data from common block ********************
c
c For comments on these variables, see the listing for MESS.
c
      parameter (LINDEF = 79)
      parameter (LENBUF = 160)
      parameter (MEVBAS = 10)
      parameter (MEVLAS = 32)
      logical          XARGOK
      integer          EUNIT, IVAR(MEVBAS:MEVLAS), IWF, IWG, KDF,
     1   KDFDEF, KDIAG, KLINE, KSCRN, KSPEC, MAXERR, LASTI, LBUF,
     2   LENLIN, LENTRY, LHEAD, LINERR, LINMSG, LOCBEG, LPRINT, LSTOP,
     3   LSTRT, MDAT(5), MPT, MUNIT, NCOL, NDIM, NFDAT, NIDAT, NMDAT,
     4   NROW, NTEXT, OUNIT, SUNIT, TABSPA
c
      character BUF*(LENBUF), DOLS*72, FMTF*14, FMTG*14, FMTT*14
      common /CMESSI/ SUNIT, LHEAD, KDFDEF, LINMSG, LINERR, MUNIT,
     1   EUNIT, KSCRN, KDIAG, MAXERR, LSTOP, LPRINT, KDF, NTEXT,
     2   NIDAT, NFDAT, NMDAT, MDAT, TABSPA, IWF, IWG, KLINE,
     3   KSPEC, LASTI, LBUF, LENLIN, LENTRY, LOCBEG, LSTRT, MPT, NROW,
     4   NCOL, NDIM, OUNIT, XARGOK
      common /CMESSC / BUF, DOLS, FMTF, FMTG, FMTT
      equivalence (IVAR(MEVBAS), SUNIT)
c
      data LDFDEF / 0 /
c
c ************************* Start of Executable Code *******************
c
      XARGOK = .true.
      if (LDFDEF .le. 0) then
         LDFDEF = 1 + int(real(I1MACH(I1GETD)) * R1MACH(5))
      end if
      KDFDEF = LDFDEF
      KDF = KDFDEF
   10 call MESS (MACT, TEXT, IDAT)
      go to (20, 100, 100, 200, 300, 400), LENTRY-3
      XARGOK = .false.
      LDFDEF = KDFDEF
      return
c                                      Print from FDAT
   20 J = LBUF + 1
      FOUT = FDAT(NFDAT)
      NFDAT = NFDAT + 1
      if (KSPEC .ge. 8) then
         LBUF = LBUF + IWG
         write (BUF(J:LBUF),FMTG) FOUT
         go to 10
      end if
      FMAG = FOUT
      FSMA = abs(FOUT)
      IWF = 1
c                                      Get the format.
   40 KEXE = 3
      KBP = 0
      KAP = 0
      if (FMAG .ne. 0.E0) then
         if (FMAG .lt. 0.E0) then
            FMAG = -FMAG
            IWF = IWF + 1
         end if
         if (FSMA .ge. 1.E0) then
            KAP = -log10(FSMA) - 1.000001E0
         else
            KAP = -log10(FSMA) + 1.E-6
         end if
         if (FMAG .ne. FSMA) then
            if (FMAG .ge. 1.E0) KBP = 1 + int(log10(FMAG) + 1.E-6)
         else
            KBP = max(-KAP, 0)
         end if
         K = max(KAP+1, KBP)
         if (K .ge. 10) KEXE = 3 + int(log10(real(K)) + 1.e-5)
      end if
      if (KDF .eq. 0) KDF = KDFDEF
      if (KDF .gt. 0) then
         if (KBP + max(KAP, 0) .ge. KEXE) go to 50
         ID = max(KDF + KAP, 0)
         IWF = IWF + ID + KBP
c If LENTRY is 5 or 6 (Vector or Matrix output), and KBP is 0, need 1
c extra since with the extra space for a blank an extra 0 is printed.
         if (LENTRY - 2*KBP .gt. 4) IWF = IWF + 1
      else if (KBP .gt. 0) then
         if (KBP .gt. KEXE) go to 50
         IWF = IWF + KBP - KDF
      end if
      write (FMTF, '(6H(0P99F,I2,1H.,I2,1H))') IWF,ID
      go to 60
   50 ID = KDF - 1
      if (ID .lt. 0) ID = -ID - 1
      IWF = IWF + ID + KEXE + 1
      write (FMTF, '(6H(1P99E,I2,1H.,I2,1HE,I1,1H))') IWF,ID,KEXE-2
   60 if (LENTRY .ne. 4) go to 10
c
      LBUF = LBUF + IWF
      write (BUF(J:LBUF),FMTF) FOUT
      go to 10
c                                     Get format for a vector or matrix
  100 if (KDF .eq. 0) KDF = KDFDEF
      ICOL = 1
      FMAG = FDAT(LOCBEG)
      FMIN = FMAG
      FSMA = 1.E0
      FNMAX = -1.E0
  110 do 120 J = LOCBEG, LASTI
         if (FDAT(J) .le. 0.E0) then
            FMIN = min(FMIN, FDAT(J))
            if (FDAT(J) .ne. 0.E0) FNMAX = max(FNMAX, FDAT(J))
         else
            FMAG = max(FMAG, FDAT(J))
            FSMA = min(FSMA, FDAT(J))
         end if
  120 continue
      if (NCOL .ne. 0) then
         ICOL = ICOL + 1
         LOCBEG = LOCBEG + NDIM
         LASTI = LASTI + NDIM
         if (ICOL .le. NCOL) go to 110
      end if
      if (FMIN .lt. 0.E0) then
         FMAG = min(FMIN, -0.1E0*FMAG)
         FSMA = min(-FNMAX, FSMA)
      end if
      if (FSMA .ge. 1.E0) then
         FSMA = abs(FMAG)
      else if (abs(FMAG) .lt. 1.E0) then
         FMAG = sign(FSMA, FMAG)
      end if
      IWF = 2
      go to 40
c                                    Floating point vector output
  200 write (BUF(LSTRT:LBUF), FMTF) (FDAT(K), K = MPT, MPT+KLINE-1)
      MPT = MPT + KLINE
      go to 10
c                                    Floating point matrix output
  300 write (BUF(LSTRT:LBUF), FMTF) (FDAT(K), K = MPT, LASTI, NDIM)
      go to 10
c                                    Table output
  400 write (BUF(LSTRT:LBUF), FMTT) (FDAT(K), K = MPT, MPT+KLINE-1)
      go to 10
      end

      subroutine DCONCM(N, COEFF)
c     .  Copyright (C) 1992, California Institute of Technology.
c     .  All rights reserved.  U. S. Government sponsorship under
c     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-06-04 DCONCM Krogh  Corrected line below.
c>> 1992-01-31 DCONCM Krogh  Initial Code.
c
c Converts COEFF in Chebyshev basis to the monomial basis.
c
      double precision COEFF(0:N), TP
c
      if (N .le. 0) return
      TP = 1.D0
      do 20 J = 0, N-2
         do 10 I = N-2, J, -1
            COEFF(I) = COEFF(I) - COEFF(I+2)
   10    continue
         COEFF(J+1) = .5D0 * COEFF(J+1)
         COEFF(J) = TP * COEFF(J)
         TP = 2.D0 * TP
   20 continue
      COEFF(N) = TP * COEFF(N)
      COEFF(N-1) = TP * COEFF(N-1)
      return
      end

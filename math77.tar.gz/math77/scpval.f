      FUNCTION SCPVAL (P,NDEGP,X)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1987-12-09 SCPVAL Lawson  Initial code.
C
C     C.L.LAWSON,JPL, 1969 DEC 17   MODIFIED 1973 JULY 24
C
C     MODIFIED 1974 NOV 19
C
C     EVALUATE A POLYNOMIAL OF DEGREE NDEGP GIVEN TRANSFORMATION
C     PARAMETERS, P(1) AND P(2), AND COEFFICIENTS RELATIVE TO THE
C     CHEBYSHEV BASIS.
C
C     NDEGP               DEGREE OF POLYNOMIAL
C     (P(I),I=1,NDEGP+3)  PARAMETERS DEFINING THE POLYNOMIAL
C     X                  INPUT ARGUMENT
C             THE POLYNOMIAL'S VALUE AT X IS DEFINED AS FOLLOWS.
C
C                             S = ( X - P(1) ) / P(2)
C
C                SCPVAL=SUM OF P(I+3)*T(I,S) FOR I=0,1,...NDEGP
C
C                             WHERE T(I,S) DENOTES THE CHEBYSHEV
C                             POLYNOMIAL OF DEGREE I EVALUATED AT S .
C
      REAL             P(*),W(3),S,S2,X
      W(1)=0.
      W(2)=0.
C                             TRANSFORM X TO S
      S=(X-P(1))/P(2)
      S2=S+S
      J=NDEGP+3
C
C                             EVALUATE POLYNOMIAL USING RECURSION
C
   10     IF(J .LE. 3) GO TO 20
          W(3)=W(2)
          W(2)=W(1)
          W(1)=(S2*W(2)-W(3))+P(J)
          J = J - 1
          GO TO 10
   20 SCPVAL=(S*W(1)-W(2))+P(3)
      RETURN
      END

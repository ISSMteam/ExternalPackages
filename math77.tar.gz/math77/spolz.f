      SUBROUTINE SPOLZ(A,NDEG,Z,H,IERR)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1992-05-11 CLL
C>> 1987-09-16 SPOLZ  Lawson  Initial code.
C     ------------------------------------------------------------------
C
C     Given coefficients A(1),...,A(NDEG+1) this subr computes the
C     NDEG roots of the polynomial                                      00001200
C                 A(1)*X**NDEG + ... + A(NDEG+1)
C     storing the roots as complex numbers in the array Z( ).
C     Require NDEG .ge. 1 and A(1) .ne. 0.
C
C     ------------------------------------------------------------------
C
C     Argument Definitions
C     --------------------
C
C     A( )     (In) Contains the coefficients of a polynomial, high     00002200
C              order coefficient first with A(1).ne.0. The contents
C              of this array will not be modified by the subroutine.
C
C     NDEG     (In) Degree of the polynomial.
C
C     Z( )     (Out) Contains the polynomial roots stored as complex
C              numbers.
C
C     H( )     (Scratch) Array of work space.
C                                                                       00003200
C     IERR     (Out) Error flag. Set by the subroutine to 0 on normal
C              termination. Set to -1 if A(1)=0. Set to -2 if NDEG
C              .le. 0. Set to  J > 0 if the iteration count limit
C              has been exceeded and roots 1 through J have not been
C              determined.
C
C     C.L.Lawson & S.Y.Chan, JPL, June 3,1986.
c     1992-05-11 CLL IERR was not being set when N = 0 or 1. Fixed this.
c                Added type stmts for all variables.
C     ------------------------------------------------------------------00004200
C
      REAL C43, C75, C95, HALF, ONE, ZERO
      PARAMETER(ZERO=0.E0, ONE=1.E0, C75=.75E0, HALF=.5E0,              
     *          C43=-.4375E0, C95=.95E0)
      INTEGER I,J,K,L,M,N,NDEG, EN,LL,MM,NA,ITS,LOW,MP2,                
     *        ENM2,IERR,I1MACH
      REAL A(NDEG+1), H(NDEG,NDEG)
      REAL P,Q,R,S,T,W,X,Y,ZZ,MACHEP,R1MACH
      REAL C,F,G,B2,RADIX
      COMPLEX Z(NDEG)
      LOGICAL NOTLAS,CONV,FIRST
C                                                                       00005400
      SAVE FIRST, MACHEP, RADIX, B2
C
      DATA FIRST /.TRUE./
C     ------------------------------------------------------------------
C
      IF(FIRST)THEN
C
C     Set MACHEP = machine dependent parameter specifying the
C                  relative precision of floating point arithmetic.
C         RADIX  = machine dependent parameter specifying the base      00006500
C                  of the machine floating point representation.
C
        FIRST = .FALSE.
        MACHEP = R1MACH(4)
        RADIX = I1MACH(10)
        B2 = RADIX * RADIX
      END IF
C
      IERR = 0
C                                                                       00007500
      IF(NDEG .LE. 0)THEN
        IERR = -2
        CALL ERMSG('SPOLZ',IERR,0,'NDEG .LE. 0','.')
        RETURN
      END IF
C
      IF(A(1) .EQ. ZERO)THEN
        IERR = -1
        CALL ERMSG('SPOLZ',IERR,0,'A(1) .EQ. ZERO','.')
        RETURN                                                          00008500
      END IF
C
C     Build first row of companion matrix.
C
      DO 20008 I = 2,NDEG+1
        H(1,I-1) = -(A(I) / A(1))
20008 CONTINUE
C
C     Extract any exact zero roots and set N = degree of
C     remaining polynomial.                                             00009500
C
      N = NDEG
      IERR = 0
C
      DO 20011 J = NDEG,1,-1
      IF (H(1,J) .NE. ZERO) GO TO 20012
        Z(J) = ZERO
        N = N - 1
20011 CONTINUE
C                                                                       00010500
C     Special for N = 0 or 1.
C
20012 IF (N .EQ. 0) RETURN
      IF(N .EQ. 1)THEN
        Z(1) = H(1,1)
        RETURN
      END IF
C
C     Build rows 2 thru N of the companion matrix.
C                                                                       00011500
      DO 20016 I = 2,N
      DO 20019 J = 1,N
          H(I,J) = ZERO
20019 CONTINUE
        H(I,I-1) = ONE
20016 CONTINUE
C
      GO TO 30001
C
20022 GO TO 30002                                                       00012500
C
20023 IF(IERR .NE. 0)THEN
        CALL ERMSG('SPOLZ',IERR,0,'Convergence failure','.')
      END IF
C
      RETURN
C
C     ------------------------------------------------------------------
C
C     PROCEDURE (BALANCE THE MATRIX)                                    00013500
C
C     This procedure balances a real companion matrix.
C
C     This proc is an adaption of the EISPACK subroutine BALANC to
C     the special case of a companion matrix. The EISPACK BALANCE
C     is a translation of the ALGOL procedure BALANCE, NUM. MATH.
C     13, 293-304(1969) by Parlett and Reinsch.
C     HANDBOOK FOR AUTO. COMP., VOL.II-LINEAR ALGEBRA, 315-326(1971).
C
C     ********** ITERATIVE LOOP FOR NORM REDUCTION **********           00014500
30001 GO TO 20028
20026 IF (CONV) GO TO 20027
20028   CONV = .TRUE.
      DO 20029 I = 1, N
C     Compute R = sum of magnitudes in row I skipping diagonal.
C             C = sum of magnitudes in col I skipping diagonal.
      IF(I .EQ. 1)THEN
            R = ABS(H(1,2))
      DO 20034 J = 3,N
              R = R + ABS(H(1,J))                                       00015400
20034 CONTINUE
            C = ABS(H(2,1))
      ELSE
            R = ABS(H(I,I-1))
            C = ABS(H(1,I))
      IF(I .NE. N)THEN
              C = C + ABS(H(I+1,I))
      END IF
      END IF
C                                                                       00016400
C     Determine column scale factor, F.
C
          G = R / RADIX
          F = ONE
          S = C + R
20039 IF(C .LT. G)THEN
            F = F * RADIX
            C = C * B2
      GO TO 20039
      END IF                                                            00017300
          G = R * RADIX
20041 IF(C .GE. G)THEN
            F = F / RADIX
            C = C / B2
      GO TO 20041
      END IF
C
C     Will the factor F have a significant effect ?
C
      IF((C + R) / F .LT. C95 * S)THEN                                  00018200
C
C           Yes, so do the scaling.
C
            G = ONE / F
            CONV = .FALSE.
C
C     Scale Row I
C
      IF(I .EQ. 1)THEN
      DO 20047 J = 1,N                                                  00019200
                H(1,J) = H(1,J)*G
20047 CONTINUE
      ELSE
              H(I,I-1) = H(I,I-1)*G
      END IF
C
C     Scale Column I
C
            H(1,I) = H(1,I) * F
            IF (I .NE. N) H(I+1,I) = H(I+1,I) * F                       00020200
C
      END IF
20029 CONTINUE
      GO TO 20026
C
20027 GO TO 20022
C
C     ------------------------------------------------------------------
C
C     PROCEDURE (QR EIGENVALUE ALGORITHM)                               00021200
C
C     This proc is the EISPACK subroutine HQR that uses the QR
C     algorithm to compute all eigenvalues of a real upper
C     Hessenberg matrix. Original ALGOL code was due to Martin,
C     Peters, and Wilkinson, Numer. Math., 14, 219-231(1970).
C
30002 LOW = 1
      EN = N
      T = ZERO
C     ********** SEARCH FOR NEXT EIGENVALUES **********                 00022200
   60 IF (EN .LT. LOW) GO TO 1001
      ITS = 0
      NA = EN - 1
      ENM2 = NA - 1
C     ********** LOOK FOR SINGLE SMALL SUB-DIAGONAL ELEMENT
C                FOR L=EN STEP -1 UNTIL LOW DO -- **********
   70 DO 80 LL = LOW, EN
         L = EN + LOW - LL
         IF (L .EQ. LOW) GO TO 100
         IF (ABS(H(L,L-1)) .LE. MACHEP * (ABS(H(L-1,L-1))               00023200
     *      + ABS(H(L,L)))) GO TO 100
   80 CONTINUE
C     ********** FORM SHIFT **********
  100 X = H(EN,EN)
      IF (L .EQ. EN) GO TO 270
      Y = H(NA,NA)
      W = H(EN,NA) * H(NA,EN)
      IF (L .EQ. NA) GO TO 280
      IF (ITS .EQ. 30) GO TO 1000
      IF (ITS .NE. 10 .AND. ITS .NE. 20) GO TO 130
C     ********** FORM EXCEPTIONAL SHIFT **********                      00024300
      T = T + X
C
      DO 120 I = LOW, EN
  120 H(I,I) = H(I,I) - X
C
      S = ABS(H(EN,NA)) + ABS(H(NA,ENM2))
      X = C75 * S
      Y = X
      W = C43 * S * S
  130 ITS = ITS + 1                                                     00025300
C     ********** LOOK FOR TWO CONSECUTIVE SMALL
C                SUB-DIAGONAL ELEMENTS.
C                FOR M=EN-2 STEP -1 UNTIL L DO -- **********
      DO 140 MM = L, ENM2
         M = ENM2 + L - MM
         ZZ = H(M,M)
         R = X - ZZ
         S = Y - ZZ
         P = (R * S - W) / H(M+1,M) + H(M,M+1)
         Q = H(M+1,M+1) - ZZ - R - S                                    00026300
         R = H(M+2,M+1)
         S = ABS(P) + ABS(Q) + ABS(R)
         P = P / S
         Q = Q / S
         R = R / S
         IF (M .EQ. L) GO TO 150
         IF (ABS(H(M,M-1)) * (ABS(Q) + ABS(R)) .LE. MACHEP * ABS(P)     
     *    * (ABS(H(M-1,M-1)) + ABS(ZZ) + ABS(H(M+1,M+1)))) GO TO 150
  140 CONTINUE
C
  150 MP2 = M + 2                                                       00027400
C
      DO 160 I = MP2, EN
         H(I,I-2) = ZERO
         IF (I .EQ. MP2) GO TO 160
         H(I,I-3) = ZERO
  160 CONTINUE
C     ********** DOUBLE QR STEP INVOLVING ROWS L TO EN AND
C                COLUMNS M TO EN **********
      DO 260 K = M, NA
         NOTLAS = K .NE. NA                                             00028400
         IF (K .EQ. M) GO TO 170
         P = H(K,K-1)
         Q = H(K+1,K-1)
         R = ZERO
         IF (NOTLAS) R = H(K+2,K-1)
         X = ABS(P) + ABS(Q) + ABS(R)
         IF (X .EQ. ZERO) GO TO 260
         P = P / X
         Q = Q / X
         R = R / X                                                      00029400
  170    S = SIGN(SQRT(P*P+Q*Q+R*R),P)
         IF (K .EQ. M) GO TO 180
         H(K,K-1) = -S * X
         GO TO 190
  180    IF (L .NE. M) H(K,K-1) = -H(K,K-1)
  190    P = P + S
         X = P / S
         Y = Q / S
         ZZ = R / S
         Q = Q / P                                                      00030400
         R = R / P
C     ********** ROW MODIFICATION **********
         DO 210 J = K, EN
            P = H(K,J) + Q * H(K+1,J)
            IF (.NOT. NOTLAS) GO TO 200
            P = P + R * H(K+2,J)
            H(K+2,J) = H(K+2,J) - P * ZZ
  200       H(K+1,J) = H(K+1,J) - P * Y
            H(K,J) = H(K,J) - P * X
  210    CONTINUE                                                       00031400
C
         J = MIN0(EN,K+3)
C     ********** COLUMN MODIFICATION **********
         DO 230 I = L, J
            P = X * H(I,K) + Y * H(I,K+1)
            IF (.NOT. NOTLAS) GO TO 220
            P = P + ZZ * H(I,K+2)
            H(I,K+2) = H(I,K+2) - P * R
  220       H(I,K+1) = H(I,K+1) - P * Q
            H(I,K) = H(I,K) - P                                         00032400
  230    CONTINUE
C
  260 CONTINUE
C
      GO TO 70
C     ********** ONE ROOT FOUND **********
  270 Z(EN) = CMPLX(X+T,ZERO)
      EN = NA
      GO TO 60
C     ********** TWO ROOTS FOUND **********                             00033400
  280 P = (Y - X) * HALF
      Q = P * P + W
      ZZ = SQRT(ABS(Q))
      X = X + T
      IF (Q .LT. ZERO) GO TO 320
C     ********** REAL PAIR **********
      ZZ = P + SIGN(ZZ,P)
      Z(NA) = CMPLX(X+ZZ,ZERO)
      Z(EN) = Z(NA)
      IF (ZZ .NE. ZERO) Z(EN) = CMPLX(X-W/ZZ,ZERO)                      00034400
      GO TO 330
C     ********** COMPLEX PAIR **********
  320 Z(NA) = CMPLX(X+P,ZZ)
      Z(EN) = CMPLX(X+P,-ZZ)
  330 EN = ENM2
      GO TO 60
C     ********** SET ERROR -- NO CONVERGENCE TO AN
C                EIGENVALUE AFTER 30 ITERATIONS **********
 1000 IERR = EN
 1001 CONTINUE                                                          00035400
C
      GO TO 20023
C
C     ------------------------------------------------------------------
C
      END                

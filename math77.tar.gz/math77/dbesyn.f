      SUBROUTINE DBESYN(X, ALPHA, NUM, BY)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1991-01-14 DBESYN CLL  Removed duplicate data statement.
C>> 1989-08-09 DBESYN CLL  More accurate constants for Cray
C>> 1986-03-18 DBESYN Lawson  Initial code.
C
c     This subr computes the Y Bessel functions of X for
c     NUM orders from ALPHA through ALPHA + NUM - 1.                    00001200
c     The results will be stored in BY(I), I = 1,...,NUM.
C
c     Require X .gt. 0.,    ALPHA .ge. 0.,    NUM .ge. 1.
C
c          The original subroutines SBYNU and BESJ/BESY were
c     designed and programmed by E. W. Ng and W. V. Snyder, JPL,
C     in 1973.  Modified by Ng and S. Singletary, JPL, 1974.
c
c     1984 April 16, JPL, C. Lawson and S. Chan.  Original subrs
c     combined into single subroutine.  Converted to SFTRAN3            00002200
c     and Fortran 77 for the JPL MATH77 library.
C
c     ------------------------------------------------------------------
c
c           As the machine precision, EPS, increases so does XPQ,
c     and thus so does the requirement for the storage dimension,
c     LDIMA.  Here are some values of -LOG10(EPS), XPQ, and LDIMA.
c
c     -LOG10(EPS)=  5     10     15     20     25     30
c            XPQ =  5.74  11.38  17.03  22.68  28.32  33.97             00003200
c          LDIMA = 17     33     49     63     79     95
c
c           Since LDIMA cannot be adjusted at run-time, we are
c     setting it to 95 to handle the case of CDC double precision
c     which is probably the largest precision system likely
c     to be encountered.  Note that the relative precision of results
c     from this subr cannot exceed about 16 or 17 decimal places
c     because of the limited accuracy of the polynomial coeffs used to
c     compute G0, and also the limited precision of the
c     subprograms referenced for gamma and loggamma.                    00004200
c     ------------------------------------------------------------------
c     Subprograms used: TANH, LOG10, LOG, EXP, COS, SIN, SQRT
      EXTERNAL          D1MACH, DBESPQ, DERV1, ERMSG, ERMOR, IERV1
      EXTERNAL          DGAMMA, DLGAMA
c     ----------
      integer I, II, K, LDIMA, M, MU, MUSAVE, N20023, N20093, ND2
      integer NMAX, NMIN, NPR001, NPR008, NUM
      parameter( LDIMA = 95, ND2 = 10)
      double precision D1MACH, DGAMMA, DLGAMA
      double precision AJ(LDIMA), ALPHA, ARG                            00005200
      double precision BGAM, BGAMSQ, BIG, BIGLOG, BY(NUM)
      double precision C11293, C16, C1P5, C2BYPI, C59, CHI, CP6, CUTLOW
      double precision D1, D2, D2SER(0:ND2), D2VAL, D3, DR
      double precision EC, EM, EM1, EMU, EN1, EN2, EN3, EPS, ETA
      double precision FAC, FK, FKM1, FKP1, FOUR, FV, FVM1, FVP1
      double precision G, G0, G1, GMAX, GNU, HALF, HALFPI, HICUT
      double precision LOGPI, LOGTWO, ONE, P, PI, PIV2, PSI1, PSIZ
      double precision Q, Q2DXPV, SCALE, SMALL, SUM
      double precision TEMP, TEST, THREE, THSJ, THVDX, TWO, TWODX
      double precision V, V2, VPMU, X, XLOG, XPQ                        00006200
      double precision YLOG, YV, YVM1, YVP1, Z, ZERO
      logical FLAG, J1SMAL
 
      SAVE EPS, HICUT, SMALL, XPQ, BIG, BIGLOG
      parameter( ZERO = 0.D0, ONE = 1.D0, TWO = 2.D0)
      parameter( HALF = 0.5D0, THREE = 3.0D0)
      parameter( C16 = 16.D0, FOUR = 4.0D0)
      parameter(PI = 3.14159 26535 89793 23846 26433 83279 50288D0)
C
      parameter(HALFPI = 1.57079 63267 94896 61923 13216 91639 75144D0) 00007200
c          LOGPI = ln(pi)
      parameter(LOGPI = 1.14472 98858 49400 17414 34273 51353 05869D0)
c          C2BYPI = 2/pi
      parameter(C2BYPI = 0.63661 97723 67581 34307 55350 53490 05744D0)
c          EC = Euler's constant.
      parameter(EC = 0.57721 56649 01532 86060 65120 90082 40243 D0)
c          LOGTWO = Ln(2)
      parameter(LOGTWO = 0.69314 71805 59945 30941 72321 21458 17657D0)
      parameter(   C1P5 = 1.5D0 )
      parameter( C11293 = 1.1293D0)                                     00008200
      parameter(    CP6 = 0.60206D0)
      parameter(    C59 = 0.59D0)
      parameter( CUTLOW = 0.012D0)
      parameter(   THSJ = 0.12D0)
      DATA EPS / ZERO /
C
      DATA D2SER( 0) / +.36746 69051 96615 96151 85D+00/
      DATA D2SER( 1) / -.17829 03980 80726 98422 31D+01/
      DATA D2SER( 2) / +.94116 44685 12285 59084 27D+00/
      DATA D2SER( 3) / -.19588 65250 24874 78780 77D+01/                00009200
      DATA D2SER( 4) / +.15573 06621 10828 32944 75D+01/
      DATA D2SER( 5) / -.25210 51413 54681 20964 37D+01/
      DATA D2SER( 6) / +.21845 02685 63511 09141 45D+01/
      DATA D2SER( 7) / -.31400 67153 45267 44028 72D+01/
      DATA D2SER( 8) / +.28174 01038 92146 13611 58D+01/
      DATA D2SER( 9) / -.37721 98775 79967 00818 58D+01/
      DATA D2SER(10) / +.34527 80604 49258 45750 60D+01/
C
c     ------------------------------------------------------------------
C                                                                       00010300
c     Set environmental parameters.
c
      IF( EPS .EQ. ZERO)THEN
         EPS = D1MACH(3)
         HICUT = ONE / (EPS*C16)
         SMALL = C16 * D1MACH(1) / EPS
         XPQ = C11293 * (CP6 - LOG10( EPS )) - C59
         BIG = D1MACH(2) / TWO
         BIGLOG = LOG(BIG)
      END IF                                                            00011300
c     ------------------------------------------------------------------
c
c     Compute V, NMIN, and NMAX.
c
      NMIN = INT(ALPHA)
      V = ALPHA - DBLE(NMIN)
      NMAX = NMIN + NUM -1
c     ------------------------------------------------------------------
c
c     Test validity of given argument values.                           00012300
C
      IF (.NOT.( X .LT. ZERO  .OR.                                      
     *          ALPHA .LT. ZERO .OR. NUM .LT. 1)) GO TO 20005
C                                                Error 1.
        CALL ERMSG('DBESYN',1,0,                                        
     *             'Require X .gt. 0, ALPHA .ge. 0, NUM .ge. 1',',')
      ASSIGN 20006 TO NPR001
      GO TO 30001
20006   RETURN
c
c     ------------------------------------------------------------------
C
c     Branch on size of X.                                              00013600
c
20005 IF (.NOT.( X .EQ. ZERO )) GO TO 20008
c     >                                           Error 6.
      DO 20009 I = 1, NUM
            BY(I) = -BIG
20009 CONTINUE
         CALL ERMSG('DBESYN',6,0,                                       
     *   'When X = 0., function value is -INFINITY.', ',')
      ASSIGN 20012 TO NPR001
      GO TO 30001
20012 GO TO 20007
20008 IF (.NOT.( X .LT. EPS )) GO TO 20013
      GO TO 30002                                                       00014700
20014 GO TO 20007
20013    TWODX = TWO / X
      IF (.NOT.( X .LE. XPQ )) GO TO 20016
      GO TO 30003
20017 GO TO 30004
20018 GO TO 20015
20016 IF (.NOT.( X .LE. HICUT )) GO TO 20019
      GO TO 30005
20020 GO TO 20015
c        >                                             Error 2.
20019       CALL ERMSG('DBESYN', 2, 0,                                  00015700
     *      'Cannot obtain any accuracy when X exceeds HICUT.', ',')
            CALL DERV1('HICUT', HICUT, ',')
      ASSIGN 20021 TO NPR001
      GO TO 30001
20021 CONTINUE
20015 CONTINUE
C
20007 RETURN
c     ------------------------------------------------------------------
c
C     PROCEDURE( VERY SMALL X )
c
c     >     Use a single term expression for Y, valid                   00016900
c     for X very close to zero.  Ref NBS AMS 55 Eqs 9.1.8 & 9.1.9.
c     For GNU = 0,   Y = (2/pi) * (EC + Ln(X/2)),  {EC = Euler's const.}
c     For GNU .gt. 0    Y =  -(1/pi) * Gamma(GNU) * (X/2)**(-GNU)
c
30002 XLOG = LOG( X )
      GNU = ALPHA
c
      I =1
      N20023=NUM
      GO TO 20024
20022 I =I +1
20024 IF ((N20023-I ).LT.0) GO TO 20023
      IF (.NOT.( GNU .EQ. ZERO )) GO TO 20026
            BY(I) = C2BYPI * (EC + XLOG - LOGTWO)                       00017900
      GO TO 20025
20026       YLOG = DLGAMA(GNU) - GNU * (XLOG-LOGTWO) - LOGPI
      IF (.NOT.(YLOG .LT. BIGLOG)) GO TO 20028
               BY(I) = -EXP(YLOG)
      GO TO 20027
c     >                                         Error 5.
20028 DO 20029 II = I,NUM
                  BY(II) = -BIG
20029 CONTINUE
               CALL ERMSG('DBESYN',5,0,                                 00018900
     *         'Results exceed overflow limit from BY(I) on.', ',')
               CALL IERV1('I', I, ',')
      ASSIGN 20032 TO NPR001
      GO TO 30001
20032 GO TO 20023
20027 CONTINUE
20025       GNU = GNU + ONE
      GO TO 20022
20023 GO TO 20014
c     ------------------------------------------------------------------
C
C     PROCEDURE( COMPUTE J BY RECURSION )                               00020100
C
C     J-TYPE BESSEL FUNCTIONS FOLLOW THE RECURRENCE RELATION
C     F(V-1,X)=(2*V/X)*F(V,X)-F(V+1,X).
C
30003 MU = INT(X) + 1
      DR = TWODX * (V+DBLE(MU))
      FKP1 = ONE
      FK =  ZERO
C
C     RECUR FORWARD UNTIL FKP1 IS GREATER THAN PRECISION OF ARITHMETIC. 00021100
C
20033 IF( EPS * ABS(FKP1) .LE. ONE )THEN
      MU = MU + 1
      DR = DR + TWODX
      FKM1 = FK
      FK = FKP1
      FKP1 = DR * FK - FKM1
      GO TO 20033
      END IF
C                                                                       00022000
C     WE ARE NOW ASSURED THAT BACKWARD RECURRENCE FROM MU WILL YIELD
C     ACCURATE RESULTS.
C
C                                        GUARANTEE EVEN MU
      IF (MOD(MU,2) .NE. 0)  MU = MU + 1
      MUSAVE = MU
c
c     >                                         Test for Error 3.
c
c     This error should never happen.  Large MU would be due to         00023000
c     large X.  But X is not larger than XPQ here.
c     See explanation at the beginning of this subroutine
c     of the relation of XPQ and LDIMA to the machine EPS.
c
      IF (.NOT.( MU + 1 .GT. LDIMA)) GO TO 20036
         CALL ERMSG('DBESYN', 3, 0,                                     
     *'Need larger dimension, LDIMA, to process given X.', ',')
         CALL ERMOR('Require LDIMA .ge. MU + 1', ',')
         CALL IERV1('MU', MU, ',')
         CALL IERV1('LDIMA', LDIMA, ',')
      ASSIGN 20037 TO NPR001                                            00024100
      GO TO 30001
c                                                Error RETURN.
20037    RETURN
c
20036 FVM1 = SMALL
      AJ(MU+1) = FVM1
      FV = ZERO
      ETA = ONE
      SUM = FVM1
      M = MU / 2
      EM = DBLE(M)                                                      00025200
      EMU = DBLE(MU)
      FAC = (V + EMU) * TWODX
C
c     Set TEST = largest value that can be multiplied by
c     FAC without risking overflow.  The present value of
c     FAC is the largest that will occur during the recursion.
c     TEST will be used to protect against overflow during
c     the recursion.
c
      TEST = BIG / MAX(ONE, FAC)                                        00026200
C
C                             Loop while MU .GT. ZERO
C
20038 FVP1 = FV
      FV = FVM1
      IF (.NOT.( ABS(FV) .GT. TEST )) GO TO 20040
      GO TO 30006
20040 FVM1 = FAC * FV - FVP1
      MU = MU -1
      EMU = EMU - ONE                                                   00027200
      FAC = (V + EMU) * TWODX
         AJ(MU+1) = FVM1
      IF(MOD(MU,2) .EQ. 0)THEN
      IF(V .EQ. ZERO)THEN
          SUM = SUM + FVM1
      IF(MU .EQ. 0)THEN
            SCALE = ONE / SUM
      GO TO 20039
      END IF
          SUM = SUM + FVM1                                              00028200
      ELSE
      IF(MU .NE. 0)THEN
            VPMU = V + EMU
            ETA = ETA * (EM/(V + (EM-ONE))) * (VPMU / (VPMU + TWO))
            SUM = SUM + FVM1 * ETA
            EM = EM - ONE
      ELSE
c
c           Here MU = 0 and EM = 0NE.  Thus the expression for
c           updating ETA reduces to the following simpler               00029200
c           expression.
c
            ETA = ETA / (V + TWO)
            SUM = SUM + FVM1 * ETA
            BGAM = DGAMMA(V+ONE)
            Q2DXPV = TWODX ** V
            SCALE = ( BGAM / ETA ) * SUM * Q2DXPV
            SCALE = ONE / SCALE
      GO TO 20039
      END IF                                                            00030200
      END IF
      END IF
      GO TO 20038
C
C     NORMALIZE AJ() TO GET VALUES OF J-BESSEL FUNCTION.
C
20039 DO 20049 I = 1, MUSAVE+1
         AJ(I) = AJ(I) * SCALE
20049 CONTINUE
20050 MU = MUSAVE                                                       00031200
      GO TO 20017
C
C     ------------------------------------------------------------------
C
C     PROCEDURE( RESCALE )
C
30006 FV = FV / SUM
      FVP1 = FVP1 / SUM
      DO 20052 II = MU+1, MUSAVE
         AJ(II) = AJ(II) / SUM                                          00032200
20052 CONTINUE
20053 SUM = ONE
      GO TO 20040
C
c     ------------------------------------------------------------------
c
C     PROCEDURE( COMPUTE Y FROM J )
c
c          This proc computes Y Bessel functions, making use
c     of previously computed J Bessel functions and other               00033200
c     previously computed values, MU, BGAM, Q2DXPV, TWODX, V.
c
c     >     Here V is in the range [0.,1.).  The
c     quantities G0 and G1 depend on X and V and are unbounded
c     as V approaches 1.   Therefore we make
c     the change of variables
c     >          V2 = V      if V .le. 0.5 and
c     >          V2 = 1 - V  if V .gt. 0.5
c     Then G0 and G1 are computed as functions of X and V2
c     with V2 in the range (-0.5, 0.5].                                 00034200
C
c     Compute G0 and G1.
c
30004 BGAMSQ = BGAM**2
      V2 = V
      IF (.NOT.( V .EQ. ZERO )) GO TO 20056
         Z = EC - LOG(TWODX)
         G0 =  Z / HALFPI
         G1 = TWO / HALFPI
         BGAMSQ = ONE                                                   00035200
         Q2DXPV = ONE
      GO TO 20055
20056 IF(V .GT. HALF)THEN
c
c           Use the transformed variable, V2 = V - 1.
c           Make corresponding transformation of Q2DXPV & BGAMSQ.
c
            V2 = (V - HALF) - HALF
            Q2DXPV = Q2DXPV / TWODX
            BGAMSQ = BGAMSQ / V**2                                      00036200
      END IF
         PIV2 = PI * V2
c
c           Here V2 is in [-.5, .5].  Now test against CUTLOW = 0.012
c
      IF (.NOT.( ABS(V2) .LT. CUTLOW )) GO TO 20060
      GO TO 30007
20061 GO TO 20059
20060       G0 = (ONE / TAN(PIV2)) - Q2DXPV**2 * BGAMSQ / PIV2
            G1 = (Q2DXPV**2/HALFPI) * BGAMSQ * (TWO+V2) / (ONE-V2)      00037200
20059 CONTINUE
c ----------------------------------
c
C     COMPUTE YO FROM SUM(J'S) FORM
c
20055 EN3 = V2 + ONE
      EN2 = V2 + EN3
      EN1 = V2 + FOUR
      D1 = TWO
      D2 = D1 - V2                                                      00038300
      D3 = D1 + V2
      FLAG = .FALSE.
c                                      THSJ = 0.12
      J1SMAL = ABS(AJ(1)) .LT. THSJ
      IF( J1SMAL  .OR. V2 .LT. ZERO)THEN
         FLAG = .TRUE.
C
C        Y(V2+1,X) MUST ALSO BE COMPUTED BY A SUM
C
         THVDX = THREE * V2 / X                                         00039300
         PSIZ = -BGAMSQ * Q2DXPV**2 / (HALFPI*X)
         PSI1 = G0 - HALF * G1
      END IF
c
      IF(V2 .GE. ZERO)THEN
         M = 3
         YV = G0 * AJ(1)
      IF( J1SMAL )THEN
            YVP1 = PSIZ * AJ(1) + PSI1 * AJ(2)
      END IF                                                            00040300
      ELSE
         Z = TWODX * V * AJ(1)-AJ(2)
         YV = G0 * Z
         M = 2
         YVP1 = PSIZ * Z + PSI1 * AJ(1)
      END IF
c
      DO 20068 I = M,MU,2
         YV = G1 * AJ(I) + YV
         G = G1                                                         00041300
         G1 = -G1 * (EN1/D1) * (EN2/D2) * (EN3/D3)
         EN1 = EN1 + TWO
         EN2 = EN2 + ONE
         EN3 = EN3 + ONE
         D1 = D1 + ONE
         D2 = ONE + D2
         D3 = D3 + TWO
      IF( FLAG )THEN
            YVP1 = YVP1 + THVDX*G*AJ(I) + HALF*(G-G1)*AJ(I+1)
      END IF                                                            00042300
20068 CONTINUE
c
      IF(V2 .LT. ZERO)THEN
         Z = YVP1
         YVP1 = V * Z * TWODX - YV
         YV = Z
      ELSEIF( .NOT. J1SMAL )THEN
C
C           NOW COMPUTE Y(V+1)
C           WRONSKIAN PROVIDED NOT NEAR A ZERO OF J                     00043300
C
            YVP1 = (YV*AJ(2)-ONE/(X*HALFPI)) / AJ(1)
      END IF
c
      ASSIGN 20076 TO NPR008
      GO TO 30008
20076 GO TO 20018
C
c     ------------------------------------------------------------------
C
C     PROCEDURE(COMPUTE G0 AND G1 FOR VERY SMALL V2)                    00044300
C
c     Here we compute
c           G0 = (ONE / TAN(PIV2)) - Q2DXPV**2 * BGAMSQ / PIV2
c     by a formulation that retains accuracy for
c     V2 close to zero.
c     >     The no. of coeffs from D2SER() used to compute D2VAL
c     could be fewer on lower precision computers, however this
c     computation is only done about 2.4% of the time so the
c     potential time saving would probably not be noticeable.
c                                                                       00045300
c     This method was derived by C. Lawson and W. V. Snyder,
c     JPL, 1984 Apr 15.
c
c     First compute EM1 = (2/X)**(2*V2) - 1
c                       = exp(2 * V2 * log(2/X)) - 1
c
30007 ARG = TWO * V2 * LOG( TWODX )
      IF( ABS( ARG ) .LT. LOGTWO )THEN
         TEMP = TANH( HALF * ARG )
         EM1 = TWO * TEMP / (ONE - TEMP)                                00046300
      ELSE
         EM1 = EXP( ARG ) - ONE
      END IF
c
c      Evaluate taylor series for
c      D2VAL = (PIV2 * cotan(PIV2) - BGAMSQ) / PIV2
c
      D2VAL = D2SER(ND2)
      DO 20079 I = ND2-1, 0, -1
         D2VAL = D2SER(I) + V2 * D2VAL                                  00047300
20079 CONTINUE
c
         G0 = D2VAL - BGAMSQ * (EM1 / PIV2)
         G1 = (Q2DXPV**2/HALFPI) * BGAMSQ * (TWO+V2) / (ONE-V2)
      GO TO 20061
C
c     ------------------------------------------------------------------
C
C     PROCEDURE( LARGE X )
C                                                                       00048300
c     >     Here we have X .ge. XPQ, and V in [0.,1.).
c     The asymptotic series for
c     the auxiliary functions P and Q can be used.
c     From these we will compute Y(V,X) and Y(V+1,X) and
c     then recur forward.
c     Reference: NBS AMS 55 Eqs 9.2.5 & 9.2.6
c
30005 CALL DBESPQ (X,V,  P,Q)
      CHI = X - (V + HALF) * HALFPI
      YV = SQRT(ONE / (HALFPI*X)) * (P*SIN(CHI) + Q*COS(CHI))           00049300
C
      IF( NMAX .GT. 0 )THEN
         CALL DBESPQ (X,V+ONE,   P,Q)
         CHI = X - (V + C1P5) * HALFPI
         YVP1 = SQRT(ONE / (HALFPI*X)) * (P*SIN(CHI) + Q*COS(CHI))
      END IF
c
      ASSIGN 20084 TO NPR008
      GO TO 30008
20084 GO TO 20020
C     ------------------------------------------------------------------00050300
c
C     PROCEDURE( FORWARD RECURSION )
c
c     >     Given YV = Y(V,X), YVP1 = Y(V+1,X), TWODX = 2/X,
c     NMIN, NUM, NMAX = NMIN + NUM -1,
c     X, ALPHA, and BIG.
c     Recur forward and store Y(NMIN+V) thru Y(NMAX+V) in
c     BY(1) thru BY(NUM).
c
30008 IF( NMIN .EQ. 0 )THEN                                             00051300
         BY(1) = YV
      IF( NMAX .GT. 0 )THEN
            BY(2) = YVP1
      END IF
      ELSEIF( NMIN .EQ. 1 )THEN
         BY(1) = YVP1
      END IF
c
      IF (.NOT.( NMAX .GT. 1 )) GO TO 20091
         G = V * TWODX                                                  00052300
         GMAX = G + TWODX * DBLE(NMAX-1)
         TEST = BIG / MAX(ONE, GMAX)
c
c        Note:  In the following statement, 3-NMIN can be nonpositive.
c
      K =3-NMIN
      N20093=NUM
      GO TO 20094
20092 K =K +1
20094 IF ((N20093-K ).LT.0) GO TO 20093
            YVM1 = YV
            YV   = YVP1
      IF (.NOT.(ABS(YV) .GT. TEST)) GO TO 20096
c                                                                       00053300
c              The recursion has reached the overflow limit.
c              Set remaining elts of BY() to a large negative value
c              and issue error message.
c
      DO 20097 II = MAX(K, 1),NUM
                  BY(II) = -BIG
20097 CONTINUE
C                                                   Error 4.
               CALL ERMSG('DBESYN',4,0,                                 
     *         'Results exceed overflow limit from BY(I) on.', ',')
               CALL IERV1('I', MAX(K,1), ',')                           00054400
      ASSIGN 20100 TO NPR001
      GO TO 30001
20100 GO TO 31008
c
20096       G = G + TWODX
            YVP1 = G * YV - YVM1
            IF( K .GE. 1)  BY(K) = YVP1
      GO TO 20092
20093 CONTINUE
20091 CONTINUE
31008 GO TO NPR008,(20076,20084)                                        00055400
C     ------------------------------------------------------------------
C
C     PROCEDURE( TRANSMIT X, ALPHA, AND NUM )
C
30001   CALL DERV1('X',X,',')
        CALL DERV1('ALPHA',ALPHA,',')
        CALL IERV1('NUM',NUM,'.')
      GO TO NPR001,(20006,20012,20021,20032,20037,20100)
C     ------------------------------------------------------------------
      END                                                               00056400

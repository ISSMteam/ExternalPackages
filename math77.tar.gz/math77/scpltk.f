      FUNCTION SCPLTK(EM)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1989-06-16 SCPLTK Snyder  Remove implied DO from DATA stmts for CFT
C>> 1985-08-02 SCPLTK Lawson  Initial code.
C
C     Complete elliptic integral K(EM). Method given by
C     W.J.CODY, Math. of Comp.,Vol.19, (1965), pp. 105-111.
C     Data are taken from Cody's table in reverse order.
C     We are using N = 5 or 9 for single precision and
C     N = 10 for double precision.
C
C     C.L.LAWSON & STELLA CHAN,JPL,1983 JUNE.
C
C     ----------------------------------------------------
C
C     POLY DEGREE     NEGATIVE LOG BASE 10 OF MAX ABS
C                     ERROR OF APPROXIMATION
C
C         N           FOR K           FOR E
C         -           -----           -----
C         5            9.50            9.44
C         9           15.87           15.84
C        10           17.45           17.42
C
C     ----------------------------------------------------
C
      REAL A(9,2), B(9,2)
C
      SAVE M, MAX, FAC
C
C     VL = LOG(4)
      DATA VL/ .138629436111989061883E+01/
C
      DATA ZERO,ONE,HALF / .0E0, 1.E0, .5E0 /
C
      DATA M / 0 /
C
      DATA A(1,1), A(2,1) / 6.63980111468E-03, 2.59628884526E-02 /
      DATA A(3,1), A(4,1) / 2.37612248576E-02, 3.15594316275E-02 /
      DATA A(5,1)         / 9.65786196226E-02 /
C
      DATA A(1,2) / 3.00725199036864838E-04 /
      DATA A(2,2) / 3.96847090209897819E-03 /
      DATA A(3,2) / 1.07959904905916349E-02 /
      DATA A(4,2) / 1.05899536209893585E-02 /
      DATA A(5,2) / 7.51938672180838102E-03 /
      DATA A(6,2) / 8.92664629455646620E-03 /
      DATA A(7,2) / 1.49420291422820783E-02 /
      DATA A(8,2) / 3.08851730018997099E-02 /
      DATA A(9,2) / 9.65735903017425285E-02 /
C
      DATA B(1,1), B(2,1) / 1.84723416323E-03, 1.87516602769E-02 /
      DATA B(3,1), B(4,1) / 4.49838755399E-02, 7.01487577829E-02 /
      DATA B(5,1)         / 1.24999295975E-01 /
C
      DATA B(1,2) / 6.66317524646073151E-05 /
      DATA B(2,2) / 1.72161470979865212E-03 /
      DATA B(3,2) / 9.28116038296860419E-03 /
      DATA B(4,2) / 2.06902400051008404E-02 /
      DATA B(5,2) / 2.95037293486887130E-02 /
      DATA B(6,2) / 3.73355466822860296E-02 /
      DATA B(7,2) / 4.88271550481180099E-02 /
      DATA B(8,2) / 7.03124954595466082E-02 /
      DATA B(9,2) / 1.24999999997640658E-01 /
C
      IF (M .EQ. 0) THEN
C
C     -LOG10(6.31E-9) = 8.2
C
        IF (R1MACH(3) .LT. 6.31E-9) THEN
          M = 2
          MAX = 9
        ELSE
          M = 1
          MAX = 5
        END IF
        FAC = ONE + 2 * R1MACH(3)
      END IF
      IF (EM .GE. ONE) THEN
        CALL SERM1('SCPLTK',1,0,'INFINITE VALUE WHEN EM .EQ. 1' //
     *             ' AND UNDEFINED FOR EM .GT. 1','EM',EM,'.')
        U = ZERO
      ELSE IF (EM .LT. ZERO) THEN
        CALL SERM1('SCPLTK',2,0,'UNDEFINED FOR EM .LT. ZERO',
     *             'EM',EM,'.')
        U = ZERO
      ELSE
        EMP = HALF + (HALF- EM)
        S1 = EMP * A(1,M)
        S2 = EMP * B(1,M)
        DO 100 J = 2, MAX
          S1 = (S1 + A(J,M)) * EMP
          S2 = (S2 + B(J,M)) * EMP
  100   CONTINUE
        U = VL + S1 + LOG(ONE/EMP) * (HALF + S2)
      END IF
C
      SCPLTK = U * FAC
      RETURN
C
      END

      SUBROUTINE SERM1(SUBNAM,INDIC,LEVEL,MSG,LABEL,VALUE,FLAG)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1985-09-25 SERM1  Lawson  Initial code.
C
      CHARACTER*(*) SUBNAM,MSG,LABEL
      CHARACTER*1 FLAG
      CALL ERMSG(SUBNAM,INDIC,LEVEL,MSG,',')
      CALL SERV1(LABEL,VALUE,FLAG)
C
      RETURN
      END

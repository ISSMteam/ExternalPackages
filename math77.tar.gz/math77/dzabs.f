      DOUBLE PRECISION FUNCTION DZABS(Z)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1987-12-07 DZABS  Lawson  Initial code.
C
C     Returns sqrt(Z(1)**2 + Z(2)**2)
C     Lawson and Chiu, JPL, Oct 1987
C
      DOUBLE PRECISION Z(2), A, B, ONE, ZERO
      PARAMETER(ONE=1.0D0, ZERO=0.0D0)
C
      A = ABS(Z(1))
      B = ABS(Z(2))
      IF (A .GT. B) THEN
        DZABS = A * SQRT(ONE+(B/A)**2)
      ELSE IF (B .NE. ZERO) THEN
        DZABS = B * SQRT(ONE+(A/B)**2)
      ELSE
        DZABS = ZERO
      END IF
      RETURN
      END

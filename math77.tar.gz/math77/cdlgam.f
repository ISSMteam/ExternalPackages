      SUBROUTINE  CDLGAM(CARG,CANS,ERREST,MODE)
C>> 1992-04-03 CDLGAM CLL Added first-time flag.
C>> 1991-11-11 CDLGAM Lawson  Dummy subr.  Calling ZGAM.
C      Subr ZGAM computes DP Complex gamma and log-gamma functions
c      with error estimates.  Changed name from CDLGAM to ZGAM on
c      Nov 11, 1991.
C     -----------------------------------------------------------------
C
      double precision CARG(2),CANS(2),ERREST
      integer MODE
      logical FIRST
      save FIRST
      data FIRST / .true. /
C     -----------------------------------------------------------------
      if(FIRST) then
      FIRST = .false.
      print'(/(a))',
     * '   ===================================================',
     * '                   Message from CDLGAM:',
     * '   Please use subroutine name ZGAM in place of CDLGAM.',
     * '   This change in MATH77 library made Nov 11, 1991.',
     * '   ===================================================',
     * ' '
      endif
      call ZGAM(CARG,CANS,ERREST,MODE)
      return
      end

      SUBROUTINE DINTNS (JUMPTO)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C     SUBROUTINE $L1$INTNS (JUMPTO)
C>> 1987-11-17 DINTNS Lawson  Initial code.
C
C     REDUCE OR INCREASE NSUB, DEPENDING ON JUMPTO.  VALUES OF JUMPTO
C     ARE GIVEN BY THE PARAMETERS NSRA, NSRB, NSIA, NSIB IN $L1$INTA.
C                                                                       00001000
C     *****     SPECIALIZER VARIABLES     ******************************
C
C     ARE DEFINED IN $L1$INTOP.
C
C     *****     EXTERNAL REFERENCES     ********************************
C
C SINTSM  IN SINGLE PRECISION
C DINTSM  IN DOUBLE PRECISION
C         TO CALCULATE THE MINIMUM STEPSIZE.
C     $.TYPE.$ $L1$INTSM                                                00002000
      DOUBLE PRECISION DINTSM
C
C     *****     LOCAL VARIABLES     ************************************
C
C TDECR   IS AN ARITHMETIC STATEMENT FUNCTION DEFINED BELOW.
C     $.TYPE.$ TDECR
      DOUBLE PRECISION TDECR
C TINCR   IS AN ARITHMETIC STATEMENT FUNCTION DEFINED BELOW.
C     $.TYPE.$ TINCR
      DOUBLE PRECISION TINCR                                            00003000
C ZL1     IS AN ARGUMENT OF ARITHMETIC STATEMENT FUNCTIONS.
C     $.TYPE.$ ZL1
      DOUBLE PRECISION ZL1
C
C     *****     COMMON VARIABLES     ***********************************
C
C ALOCAL  IS EQUIVALENT TO /$L1$INTC/ LOCAL(1).
C BLOCAL  IS EQUIVALENT TO /$L1$INTC/ LOCAL(2).
C     $.TYPE.$ ALOCAL, BLOCAL
      DOUBLE PRECISION ALOCAL, BLOCAL                                   00004000
C FATAS, FATBS
C         ARE EQUIVALENCED TO FATS.
      LOGICAL FATAS, FATBS
C
C     COMMON /$L1$INTNC/ CONTAINS VARIABLES NOT SEPARATELY SAVED FOR
C     EACH DIMENSION OF A MULTIPLE QUADRATURE.  COMMON /$L1$INTC/
C     CONTAINS VARIABLES THAT MUST BE SAVED FOR EACH DIMENSION OF THE
C     QUADRATURE.  THE VARIABLES IN EACH COMMON BLOCK ARE STORED IN THE
C     ORDER - ALWAYS DOUBLE, DOUBLE IF DOUBLE PRECISION PROGRAM, DOUBLE
C     IF DOUBLE PRECISION PROGRAM AND EXPONENT RANGE OF DOUBLE AND      00004500
C     SINGLE VERY DIFFERENT, SINGLE, INTEGER, LOGICAL.  A PAD OF LOGICAL
C     VARIABLES IS INCLUDED AT THE END OF /$L1$INTC/.  THE DIMENSION OF
C     THE PAD MAY NEED TO BE VARIED SO THAT NO VARIABLES BEYOND THE END
C     OF THE COMMON BLOCK ARE ALTERED.
C
C     DECLARATIONS OF COMMON /$L1$INTNC/ VARIABLES.
C
C     $.TYPE.$ AINIT, BINIT, FNCVAL, S, TP
      double precision AINIT, BINIT, FNCVAL, S, TP
C     $DSTYP$  FER, FER1, RELOBT, TPS, XJ, XJP                          00004500
      double precision FER, FER1, RELOBT, TPS, XJ, XJP
      INTEGER     FEA,       FEA1,      INC,       INC2,      IPRINT,   
     * ISTOP(2,2),JPRINT,    KDIM,      KK,        KMAXF,     NDIM,     
     * NFINDX,    NFMAX,     NFMAXM,    OUT,       RELTOL,    REVERM,   
     * REVERS,    WHEREM
      LOGICAL NEEDH
C
C     DECLARATIONS OF COMMON /$L1$INTC/ VARIABLES.
C
C     4 DOUBLE PRECISION VARIABLES
      DOUBLE PRECISION ACUM, PACUM, RESULT(2)
C     139 $.TYPE.$ VARIABLES
C     $.TYPE.$                                                          00004500
      DOUBLE PRECISION                                                  
     * AACUM,     ABSCIS,    DELMIN,    DELTA,     DIFF,      DISCX(2), 
     * END(2),    ERRINA,    ERRINB,    FAT(2),    FSAVE,               
     * FUNCT(24), F1,        F2,        LOCAL(4),  PAACUM,    PF1,      
     * PF2,       PHISUM,    PHTSUM,    PX,        SPACE(6),            
     * STEP(2),   START(2),  SUM,       T,         TA,        TASAVE,   
     * TB,        TEND,      WORRY(2),  X,         X1,                  
     * X2,        XT(17),    FT(17),    PHI(34)
c Note XT, FT, and PHI above are last, because they must be in adjacent
c locations in DINTO.
C     30 $DSTYP$ VARIABLES
C     $DSTYP$
      DOUBLE PRECISION                                                  
     * ABSDIF,    COUNT,     EDUE2A,    EDUE2B,    EP,        EPNOIZ,   
     * EPS,       EPSMAX,    EPSMIN,    EPSO,      EPSR,      EPSS,     
     * ERR,       ERRAT(2),  ERRC,      ERRF,      ERRI,      ERRT(2),  
     * ESOLD,     EXTRA,     PEPSMN,    RE,        RELEPS,    REP,      
     * REPROD,    RNDC,      TLEN,      XJUMP
C     29 INTEGER VARIABLES
      INTEGER     DISCF,     DISCHK,    ENDPTS,    I,         INEW,     
     * IOLD,      IP,        IXKDIM,    J,         J1,        J1OLD,    
     * J2,        J2OLD,     K,         KAIMT,     KMAX,      KMIN,     
     * L,         LENDT,     NFEVAL,    NFJUMP,    NSUB,      NSUBSV,   
     * NXKDIM,    PART,      SEARCH,    TALOC,     WHERE,     WHERE2
C     11 TO 18 LOGICALS (7 ARE PADDING).
      LOGICAL     DID1,      FAIL,      FATS(2),   FSAVED,    HAVDIF,   00004500
     * IEND,      INIT,      ROUNDF,    XCDOBT(2), PAD(7)
C
C     THE COMMON BLOCKS.
C
C     COMMON /$L1$INTNC/
      COMMON /DINTNC/                                                   
     * AINIT,  BINIT,  FNCVAL, S,      TP,     FER,    FER1,   RELOBT,  
     * TPS,    XJ,     XJP,    FEA,    FEA1,   KDIM,    INC,    INC2,   
     * ISTOP,  JPRINT, IPRINT, KK,     KMAXF,  NDIM,   NFINDX, NFMAX,   
     * NFMAXM, OUT,    RELTOL, REVERM, REVERS, WHEREM, NEEDH
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * ACUM,   PACUM,  RESULT
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * AACUM,  LOCAL,  ABSCIS, TA,     DELTA,  DELMIN, DIFF,   DISCX,   
     * END,    ERRINA, ERRINB, FAT,    FSAVE,  FUNCT,  F2,              
     * PAACUM, PF1,    PF2,    PHISUM, PHTSUM, PX,     SPACE,           
     * STEP,   START,  SUM,    T,      TASAVE, TB,     TEND,            
     * WORRY,  X1,     X2,     X,      F1,     COUNT,                   
     * XT, FT, PHI
C     COMMON /$L1$INTC/                                                 00004500
      COMMON /DINTC/                                                    
     * ABSDIF, EDUE2A, EDUE2B, EP,     EPNOIZ, EPSMAX,                  
     * EPSO,   EPSR,   EPSS,   ERRAT,  ERRC,   ERRF,                    
     * ERRT,   ESOLD,  EXTRA,  PEPSMN, RELEPS, REP,                     
     * RNDC,   TLEN,   XJUMP,                                           
     * ERRI,   ERR,    EPSMIN, EPS,    RE,     REPROD
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * DISCF,  DISCHK, ENDPTS, INEW,   IOLD,   IP,     IXKDIM,          
     * J,      J1,     J1OLD,  J2,     J2OLD,  KMAX,                    
     * KMIN,   L,      LENDT,  NFEVAL, NFJUMP, NSUBSV, NXKDIM,          
     * TALOC,  WHERE2,                                                  
     * I,      K,      KAIMT,  NSUB,   PART,   SEARCH, WHERE
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * DID1,   FAIL,   FATS,   FSAVED, HAVDIF, IEND,   INIT,   ROUNDF,  
     * XCDOBT, PAD
C     SAVE /$L1$INTNC/, /$L1$INTC/
      SAVE /DINTNC/, /DINTC/
C
C $   COL1(PORT)
C.    THE VARIABLES HERE DEFINE THE MACHINE ENVIRONMENT.  ALL ARE SET   00004700
C.    IN $L1$INTOP.  THE MEANING ATTACHED TO THESE VARIABLES CAN BE
C.    FOUND BY LOOKING AT THE RELATED SPECIALIZER VARIABLES DEFINED IN
C.    $L1$INTOP.
      DOUBLE PRECISION EDMEPS
C     $.TYPE.$
      DOUBLE PRECISION                                                  
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     COMMON /$L1$INTEC/
      COMMON /DINTEC/                                                   
     *  EDMEPS,                                                         
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     SAVE /$L1$INTEC/
      SAVE /DINTEC/                                                     00004700
C $   COL1(PORT, 0)
C
C     *****     EQUIVALENCE STATEMENTS     *****************************
C
      EQUIVALENCE (LOCAL(1),ALOCAL), (LOCAL(2),BLOCAL)
      EQUIVALENCE (FATS(1),FATAS), (FATS(2),FATBS)
C
C     *****     STATEMENT FUNCTIONS     ********************************
C
C TDECR   IS USED TO TRANSFORM AN ABSCISSA FROM THE CURRENT COORDINATE  00005600
C         SYSTEM TO ONE IN WHICH NSUB IS DECREMENTED BY A FACTOR OF 2.
      TDECR(ZL1)=TA+(ZL1-TA)*((ZL1-TA)/TB)
C TINCR   IS USED TO TRANSFORM AN ABSCISSA FROM THE CURRENT COORDINATE
C         SYSTEM TO ONE IN WHICH NSUB IS INCREMENTED BY A FACTOR OF 2.
      TINCR(ZL1)=TA+SIGN(SQRT(ABS(TB*(ZL1-TA))),TB)
C
C     *****     EXECUTABLE STATEMENTS     ******************************
C
      GO TO (2670,2680,2690,2700), JUMPTO
C                                                                       00006600
C     REDUCE NSUB
C
2670  BLOCAL=TDECR(BLOCAL)
2680  ALOCAL=TDECR(ALOCAL)
      WORRY(PART)=TDECR(WORRY(PART))
      ABSCIS=TDECR(START(PART)+SIGN(STEP(PART),TB))
      START(PART)=TDECR(START(PART))
      NSUB=2*(NSUB/4)
      GO TO 2710
C                                                                       00007600
C     INCREASE NSUB
C
2690  BLOCAL=TINCR(BLOCAL)
2700  ALOCAL=TINCR(ALOCAL)
      WORRY(PART)=TINCR(WORRY(PART))
      ABSCIS=TINCR(START(PART)+SIGN(STEP(PART),TB))
      START(PART)=TINCR(START(PART))
      NSUB=MAX0(NSUB+NSUB,2)
C
2710  FSAVED=.FALSE.                                                    00008600
      FATAS=.FALSE.
      FATBS=.FALSE.
      ENDPTS=1
      STEP(PART)=SIGN(ABSCIS-START(PART),STEP(PART))
      DELTA=ABS(BLOCAL-ALOCAL)
      ABSDIF=0.5*DELTA
      TLEN=ABS(END(1)-START(1))
      IF (PART.EQ.2) TLEN=TLEN+ABS(END(2)-START(2))
      IF (DISCHK.EQ.0) DISCHK=-1
C     DELMIN=$L1$INTSM(ALOCAL)                                          00009600
      DELMIN=DINTSM(ALOCAL)
C
      RETURN
C
      END

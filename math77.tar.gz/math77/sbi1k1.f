      subroutine SBI1K1 (x, BI1, BK1, want, status)
C>>   1990-09-25 SBI1K1 WV Snyder JPL Use Fullerton codes from CMLIB
C--   S VERSION USES SBI1K1, SCSEVL, R1MACH, SERM1, SINITS
C--   D VERSION USES DBI1K1, DCSEVL, D1MACH, DERM1, DINITS
c 
c     Compute hyperbolic Bessel functions I1 and K1.
c     Approximations originally produced by Wayne Fullerton, LASL.
c 
c     *****     Formal Arguments     ***********************************
c 
c X [in] is the argument at which the functions are to be evaluated.
c BI1, BK1 [out] are the function values.
c WANT [integer,in] indicates the functions to be computed, and their
c                   scaling:
c     ABS(WANT) =
c        1 means compute I1(X)
c        2 means compute K1(X)
c        3 means compute both of I1(X) and K1(X)
c     WANT < 0 means compute EXP(-X)*I1(X) and/or EXP(X)*K1(X).
c     WANT=0 or ABS(WANT) > 3 causes an error message to be produced.
c STATUS [integer,out] indicates the outcome:
c        0 means normal computation,
c        1 means K1(X) is zero due to underflow,
c        < 0 means an error occurred:
c           -1 means WANT=0 or ABS(WANT)>3,
c           -2 means X was so big that I1(X) overflowed,
c           -3 means X was zero or negative and K1(X) is to be computed,
c           -4 means X was so small K1(X) overflows.
c     Negative values of STATUS are produced when the error message
c     processor is called with LEVEL=0; positive values of STATUS are
c     accompanied by LEVEL=-2.  See the description of the error message
c     handler for a description of the error level effects.
c     If status = -2 then BI1 = the largest representable number;
c     if status = -3 or -4 then BK1 = the largest representable number.
c     ------------------------------------------------------------------
      real X, BI1, BK1
      integer WANT, STATUS
c 
c     *****     External References     ********************************
c 
      real R1MACH, SCSEVL
      external SCSEVL, IERM1, SINITS, R1MACH, SERM1
c 
c     *****     Local Variables     ************************************
c 
      real BI1CS(17), AI1CS(46), AI12CS(69)
      real  BK1CS(16), AK1CS(38), AK12CS(33)
      real EXP10, EXPM10, LSQ2PI, LSQPI2
      parameter (EXP10 = (+.2202646579 4806716516 95790 E+5))
C     EXP10 = EXP(10)
      parameter (EXPM10 = (+.4539992976 2484851535 59152 E-4))
C     EXPM10 = EXP(-10)
      parameter (LSQ2PI = (+.9189385332 0467274178 03296 E+0))
C     LSQ2PI = LOG(SQRT 2 PI))
      parameter (LSQPI2 = (+.2257913526 4472743236 30975 E+0))
C     LSQPI2 = LOG(SQRT(PI / 2))
      real I1NS, XIN, XKN, Y, Z
      real BOUNDK, XIMAX, XIMIN, XISML, XKMAX, XKMIN, XKSML
      integer NTI1, NTAI1, NTAI12, NTK1, NTAK1, NTAK12
      save NTI1, NTAI1, NTAI12, XIMAX, XIMIN, XISML
      save BOUNDK, NTK1, NTAK1, NTAK12, XKMAX, XKMIN, XKSML
c 
c     *****     Data     ***********************************************
c 
C SERIES FOR BI1        ON THE INTERVAL  0.          TO  9.00000E+00
C                                        WITH WEIGHTED ERROR   1.44E-32
C                                         LOG WEIGHTED ERROR  31.84
C                               SIGNIFICANT FIGURES REQUIRED  31.45
C                                    DECIMAL PLACES REQUIRED  32.46
C 
      DATA BI1CS(  1) / -.1971713261 0998597316 1385032181 49 E-2     /
      DATA BI1CS(  2) / +.4073488766 7546480608 1553936520 14 E+0     /
      DATA BI1CS(  3) / +.3483899429 9959455866 2450377837 87 E-1     /
      DATA BI1CS(  4) / +.1545394556 3001236038 5984010584 89 E-2     /
      DATA BI1CS(  5) / +.4188852109 8377784129 4588320041 20 E-4     /
      DATA BI1CS(  6) / +.7649026764 8362114741 9597039660 69 E-6     /
      DATA BI1CS(  7) / +.1004249392 4741178689 1798080372 38 E-7     /
      DATA BI1CS(  8) / +.9932207791 9238106481 3712980548 63 E-10    /
      DATA BI1CS(  9) / +.7663801791 8447637275 2001716813 49 E-12    /
      DATA BI1CS( 10) / +.4741418923 8167394980 3880919481 60 E-14    /
      DATA BI1CS( 11) / +.2404114404 0745181799 8631720320 00 E-16    /
      DATA BI1CS( 12) / +.1017150500 7093713649 1211007999 99 E-18    /
      DATA BI1CS( 13) / +.3645093565 7866949458 4917333333 33 E-21    /
      DATA BI1CS( 14) / +.1120574950 2562039344 8106666666 66 E-23    /
      DATA BI1CS( 15) / +.2987544193 4468088832 0000000000 00 E-26    /
      DATA BI1CS( 16) / +.6973231093 9194709333 3333333333 33 E-29    /
      DATA BI1CS( 17) / +.1436794822 0620800000 0000000000 00 E-31    /
C 
C SERIES FOR AI1        ON THE INTERVAL  1.25000E-01 TO  3.33333E-01
C                                        WITH WEIGHTED ERROR   2.81E-32
C                                         LOG WEIGHTED ERROR  31.55
C                               SIGNIFICANT FIGURES REQUIRED  29.93
C                                    DECIMAL PLACES REQUIRED  32.38
C 
      DATA AI1CS(  1) / -.2846744181 8814786741 0037246830 7 E-1      /
      DATA AI1CS(  2) / -.1922953231 4432206510 4444877497 9 E-1      /
      DATA AI1CS(  3) / -.6115185857 9437889822 5624991778 5 E-3      /
      DATA AI1CS(  4) / -.2069971253 3502277088 8282377797 9 E-4      /
      DATA AI1CS(  5) / +.8585619145 8107255655 3694467313 8 E-5      /
      DATA AI1CS(  6) / +.1049498246 7115908625 1745399786 0 E-5      /
      DATA AI1CS(  7) / -.2918338918 4479022020 9343232669 7 E-6      /
      DATA AI1CS(  8) / -.1559378146 6317390001 6068096907 7 E-7      /
      DATA AI1CS(  9) / +.1318012367 1449447055 2530287390 9 E-7      /
      DATA AI1CS( 10) / -.1448423418 1830783176 3913446781 5 E-8      /
      DATA AI1CS( 11) / -.2908512243 9931420948 2504099301 0 E-9      /
      DATA AI1CS( 12) / +.1266388917 8753823873 1115969040 3 E-9      /
      DATA AI1CS( 13) / -.1664947772 9192206706 2417839858 0 E-10     /
      DATA AI1CS( 14) / -.1666653644 6094329760 9593715499 9 E-11     /
      DATA AI1CS( 15) / +.1242602414 2907682652 3216847201 7 E-11     /
      DATA AI1CS( 16) / -.2731549379 6724323972 5146142863 3 E-12     /
      DATA AI1CS( 17) / +.2023947881 6458037807 0026268898 1 E-13     /
      DATA AI1CS( 18) / +.7307950018 1168836361 9869812612 3 E-14     /
      DATA AI1CS( 19) / -.3332905634 4046749438 1377861713 3 E-14     /
      DATA AI1CS( 20) / +.7175346558 5129537435 4225466567 0 E-15     /
      DATA AI1CS( 21) / -.6982530324 7962563558 5062922365 6 E-16     /
      DATA AI1CS( 22) / -.1299944201 5627607600 6044608058 7 E-16     /
      DATA AI1CS( 23) / +.8120942864 2427988920 5467834286 0 E-17     /
      DATA AI1CS( 24) / -.2194016207 4107368981 5626664378 3 E-17     /
      DATA AI1CS( 25) / +.3630516170 0296548482 7986093233 4 E-18     /
      DATA AI1CS( 26) / -.1695139772 4391041663 0686679039 9 E-19     /
      DATA AI1CS( 27) / -.1288184829 8979078071 1688253822 2 E-19     /
      DATA AI1CS( 28) / +.5694428604 9670527801 0999107310 9 E-20     /
      DATA AI1CS( 29) / -.1459597009 0904800565 4550990028 7 E-20     /
      DATA AI1CS( 30) / +.2514546010 6757173140 8469133448 5 E-21     /
      DATA AI1CS( 31) / -.1844758883 1391248181 6040002901 3 E-22     /
      DATA AI1CS( 32) / -.6339760596 2279486419 2860979199 9 E-23     /
      DATA AI1CS( 33) / +.3461441102 0310111111 0814662656 0 E-23     /
      DATA AI1CS( 34) / -.1017062335 3713935475 9654102357 3 E-23     /
      DATA AI1CS( 35) / +.2149877147 0904314459 6250077866 6 E-24     /
      DATA AI1CS( 36) / -.3045252425 2386764017 4620617386 6 E-25     /
      DATA AI1CS( 37) / +.5238082144 7212859821 7763498666 6 E-27     /
      DATA AI1CS( 38) / +.1443583107 0893824464 1678950399 9 E-26     /
      DATA AI1CS( 39) / -.6121302074 8900427332 0067071999 9 E-27     /
      DATA AI1CS( 40) / +.1700011117 4678184183 4918980266 6 E-27     /
      DATA AI1CS( 41) / -.3596589107 9842441585 3521578666 6 E-28     /
      DATA AI1CS( 42) / +.5448178578 9484185766 5051306666 6 E-29     /
      DATA AI1CS( 43) / -.2731831789 6890849891 6256426666 6 E-30     /
      DATA AI1CS( 44) / -.1858905021 7086007157 7190399999 9 E-30     /
      DATA AI1CS( 45) / +.9212682974 5139334411 2776533333 3 E-31     /
      DATA AI1CS( 46) / -.2813835155 6535611063 7083306666 6 E-31     /
C 
C SERIES FOR AI12       ON THE INTERVAL  0.          TO  1.25000E-01
C                                        WITH WEIGHTED ERROR   1.83E-32
C                                         LOG WEIGHTED ERROR  31.74
C                               SIGNIFICANT FIGURES REQUIRED  29.97
C                                    DECIMAL PLACES REQUIRED  32.66
C 
      DATA AI12CS(  1) / +.2857623501 8280120474 4984594846 9 E-1      /
      DATA AI12CS(  2) / -.9761097491 3614684077 6516445730 2 E-2      /
      DATA AI12CS(  3) / -.1105889387 6262371629 1256921277 5 E-3      /
      DATA AI12CS(  4) / -.3882564808 8776903934 5654477627 4 E-5      /
      DATA AI12CS(  5) / -.2512236237 8702089252 9452002212 1 E-6      /
      DATA AI12CS(  6) / -.2631468846 8895195068 3705236523 2 E-7      /
      DATA AI12CS(  7) / -.3835380385 9642370220 4500678796 8 E-8      /
      DATA AI12CS(  8) / -.5589743462 1965838068 6811252222 9 E-9      /
      DATA AI12CS(  9) / -.1897495812 3505412344 9892503323 8 E-10     /
      DATA AI12CS( 10) / +.3252603583 0154882385 5508067994 9 E-10     /
      DATA AI12CS( 11) / +.1412580743 6613781331 6336633284 6 E-10     /
      DATA AI12CS( 12) / +.2035628544 1470895072 2452613684 0 E-11     /
      DATA AI12CS( 13) / -.7198551776 2459085120 9258989044 6 E-12     /
      DATA AI12CS( 14) / -.4083551111 0921973182 2849963969 1 E-12     /
      DATA AI12CS( 15) / -.2101541842 7726643130 1984572746 2 E-13     /
      DATA AI12CS( 16) / +.4272440016 7119513542 9778833699 7 E-13     /
      DATA AI12CS( 17) / +.1042027698 4128802764 1741449994 8 E-13     /
      DATA AI12CS( 18) / -.3814403072 4370078047 6707253539 6 E-14     /
      DATA AI12CS( 19) / -.1880354775 5107824485 1273453396 3 E-14     /
      DATA AI12CS( 20) / +.3308202310 9209282827 3190335240 5 E-15     /
      DATA AI12CS( 21) / +.2962628997 6459501390 6854654205 2 E-15     /
      DATA AI12CS( 22) / -.3209525921 9934239587 7837353288 7 E-16     /
      DATA AI12CS( 23) / -.4650305368 4893583255 7128281897 9 E-16     /
      DATA AI12CS( 24) / +.4414348323 0717079499 4611375964 1 E-17     /
      DATA AI12CS( 25) / +.7517296310 8421048054 2545808029 5 E-17     /
      DATA AI12CS( 26) / -.9314178867 3268833756 8484784515 7 E-18     /
      DATA AI12CS( 27) / -.1242193275 1948909561 1678448869 7 E-17     /
      DATA AI12CS( 28) / +.2414276719 4548484690 0515390217 6 E-18     /
      DATA AI12CS( 29) / +.2026944384 0532851789 7192286069 2 E-18     /
      DATA AI12CS( 30) / -.6394267188 2690977870 4391988681 1 E-19     /
      DATA AI12CS( 31) / -.3049812452 3730958960 8488450357 1 E-19     /
      DATA AI12CS( 32) / +.1612841851 6514802251 3462230769 1 E-19     /
      DATA AI12CS( 33) / +.3560913964 3099250545 1027090462 0 E-20     /
      DATA AI12CS( 34) / -.3752017947 9364390796 6682800324 6 E-20     /
      DATA AI12CS( 35) / -.5787037427 0747993459 5198231074 1 E-22     /
      DATA AI12CS( 36) / +.7759997511 6481619619 8236963209 2 E-21     /
      DATA AI12CS( 37) / -.1452790897 2022333940 6445987408 5 E-21     /
      DATA AI12CS( 38) / -.1318225286 7390367021 2192275337 4 E-21     /
      DATA AI12CS( 39) / +.6116654862 9030707018 7999133171 7 E-22     /
      DATA AI12CS( 40) / +.1376279762 4271264277 3024338363 4 E-22     /
      DATA AI12CS( 41) / -.1690837689 9593478849 1983938230 6 E-22     /
      DATA AI12CS( 42) / +.1430596088 5954331539 8720108538 5 E-23     /
      DATA AI12CS( 43) / +.3409557828 0905940204 0536772990 2 E-23     /
      DATA AI12CS( 44) / -.1309457666 2707602278 4573872642 4 E-23     /
      DATA AI12CS( 45) / -.3940706411 2402574360 9352141755 7 E-24     /
      DATA AI12CS( 46) / +.4277137426 9808765808 0616679735 2 E-24     /
      DATA AI12CS( 47) / -.4424634830 9826068819 0028312302 9 E-25     /
      DATA AI12CS( 48) / -.8734113196 2307149721 1530978874 7 E-25     /
      DATA AI12CS( 49) / +.4045401335 6835333921 4340414242 8 E-25     /
      DATA AI12CS( 50) / +.7067100658 0946894656 5160771780 6 E-26     /
      DATA AI12CS( 51) / -.1249463344 5651052230 0286451860 5 E-25     /
      DATA AI12CS( 52) / +.2867392244 4034370329 7948339142 6 E-26     /
      DATA AI12CS( 53) / +.2044292892 5042926702 8177957421 0 E-26     /
      DATA AI12CS( 54) / -.1518636633 8204625683 7134680291 1 E-26     /
      DATA AI12CS( 55) / +.8110181098 1875758861 3227910703 7 E-28     /
      DATA AI12CS( 56) / +.3580379354 7735860911 2717370327 0 E-27     /
      DATA AI12CS( 57) / -.1692929018 9279025095 9305717544 8 E-27     /
      DATA AI12CS( 58) / -.2222902499 7024276390 6775852777 4 E-28     /
      DATA AI12CS( 59) / +.5424535127 1459696550 4860040112 8 E-28     /
      DATA AI12CS( 60) / -.1787068401 5780186887 6491299330 4 E-28     /
      DATA AI12CS( 61) / -.6565479068 7228149388 2392943788 0 E-29     /
      DATA AI12CS( 62) / +.7807013165 0611452809 2206770683 9 E-29     /
      DATA AI12CS( 63) / -.1816595260 6689797173 7933315222 1 E-29     /
      DATA AI12CS( 64) / -.1287704952 6600848203 7687559895 9 E-29     /
      DATA AI12CS( 65) / +.1114548172 9881645474 1370927369 4 E-29     /
      DATA AI12CS( 66) / -.1808343145 0393369391 5936887668 7 E-30     /
      DATA AI12CS( 67) / -.2231677718 2037719522 3244822893 9 E-30     /
      DATA AI12CS( 68) / +.1619029596 0803415106 1790980361 4 E-30     /
      DATA AI12CS( 69) / -.1834079908 8049414139 0130843921 0 E-31     /
c 
C 
C SERIES FOR  BK1         ON THE INTERVAL  0.          TO  4.00000E+00
C                                        WITH WEIGHTED ERROR   9.16E-32
C                                         LOG WEIGHTED ERROR  31.04
C                               SIGNIFICANT FIGURES REQUIRED  30.61
C                                    DECIMAL PLACES REQUIRED  31.64
C 
      DATA  BK1CS(  1) / +.2530022733 8947770532 5311208685 33 E-1     /
      DATA  BK1CS(  2) / -.3531559607 7654487566 7238316918 01 E+0     /
      DATA  BK1CS(  3) / -.1226111808 2265714823 4790679300 42 E+0     /
      DATA  BK1CS(  4) / -.6975723859 6398643501 8129202960 83 E-2     /
      DATA  BK1CS(  5) / -.1730288957 5130520630 1765073689 79 E-3     /
      DATA  BK1CS(  6) / -.2433406141 5659682349 6007350301 64 E-5     /
      DATA  BK1CS(  7) / -.2213387630 7347258558 3152525451 26 E-7     /
      DATA  BK1CS(  8) / -.1411488392 6335277610 9583302126 08 E-9     /
      DATA  BK1CS(  9) / -.6666901694 1993290060 8537512643 73 E-12    /
      DATA  BK1CS( 10) / -.2427449850 5193659339 2631968648 53 E-14    /
      DATA  BK1CS( 11) / -.7023863479 3862875971 7837971200 00 E-17    /
      DATA  BK1CS( 12) / -.1654327515 5100994675 4910293333 33 E-19    /
      DATA  BK1CS( 13) / -.3233834745 9944491991 8933333333 33 E-22    /
      DATA  BK1CS( 14) / -.5331275052 9265274999 4666666666 66 E-25    /
      DATA  BK1CS( 15) / -.7513040716 2157226666 6666666666 66 E-28    /
      DATA  BK1CS( 16) / -.9155085717 6541866666 6666666666 66 E-31    /
C 
C SERIES FOR AK1        ON THE INTERVAL  1.25000E-01 TO  5.00000E-01
C                                        WITH WEIGHTED ERROR   3.07E-32
C                                         LOG WEIGHTED ERROR  31.51
C                               SIGNIFICANT FIGURES REQUIRED  30.71
C                                    DECIMAL PLACES REQUIRED  32.30
C 
      DATA AK1CS(  1) / +.2744313406 9738829695 2576662272 66 E+0     /
      DATA AK1CS(  2) / +.7571989953 1993678170 8923781492 90 E-1     /
      DATA AK1CS(  3) / -.1441051556 4754061229 8531161756 25 E-2     /
      DATA AK1CS(  4) / +.6650116955 1257479394 2513854770 36 E-4     /
      DATA AK1CS(  5) / -.4369984709 5201407660 5808450891 67 E-5     /
      DATA AK1CS(  6) / +.3540277499 7630526799 4171390085 34 E-6     /
      DATA AK1CS(  7) / -.3311163779 2932920208 9826882457 04 E-7     /
      DATA AK1CS(  8) / +.3445977581 9010534532 3114997709 92 E-8     /
      DATA AK1CS(  9) / -.3898932347 4754271048 9819374927 58 E-9     /
      DATA AK1CS( 10) / +.4720819750 4658356400 9474493390 05 E-10    /
      DATA AK1CS( 11) / -.6047835662 8753562345 3735915628 90 E-11    /
      DATA AK1CS( 12) / +.8128494874 8658747888 1938379856 63 E-12    /
      DATA AK1CS( 13) / -.1138694574 7147891428 9239159510 42 E-12    /
      DATA AK1CS( 14) / +.1654035840 8462282325 9729482050 90 E-13    /
      DATA AK1CS( 15) / -.2480902567 7068848221 5160104405 33 E-14    /
      DATA AK1CS( 16) / +.3829237890 7024096948 4292272991 57 E-15    /
      DATA AK1CS( 17) / -.6064734104 0012418187 7682103773 86 E-16    /
      DATA AK1CS( 18) / +.9832425623 2648616038 1940046506 66 E-17    /
      DATA AK1CS( 19) / -.1628416873 8284380035 6666201156 26 E-17    /
      DATA AK1CS( 20) / +.2750153649 6752623718 2841203370 66 E-18    /
      DATA AK1CS( 21) / -.4728966646 3953250924 2810695680 00 E-19    /
      DATA AK1CS( 22) / +.8268150002 8109932722 3920503466 66 E-20    /
      DATA AK1CS( 23) / -.1468140513 6624956337 1939648853 33 E-20    /
      DATA AK1CS( 24) / +.2644763926 9208245978 0858948266 66 E-21    /
      DATA AK1CS( 25) / -.4829015756 4856387897 9698688000 00 E-22    /
      DATA AK1CS( 26) / +.8929302074 3610130180 6563327999 99 E-23    /
      DATA AK1CS( 27) / -.1670839716 8972517176 9977514666 66 E-23    /
      DATA AK1CS( 28) / +.3161645603 4040694931 3686186666 66 E-24    /
      DATA AK1CS( 29) / -.6046205531 2274989106 5064106666 66 E-25    /
      DATA AK1CS( 30) / +.1167879894 2042732700 7184213333 33 E-25    /
      DATA AK1CS( 31) / -.2277374158 2653996232 8678400000 00 E-26    /
      DATA AK1CS( 32) / +.4481109730 0773675795 3058133333 33 E-27    /
      DATA AK1CS( 33) / -.8893288476 9020194062 3360000000 00 E-28    /
      DATA AK1CS( 34) / +.1779468001 8850275131 3920000000 00 E-28    /
      DATA AK1CS( 35) / -.3588455596 7329095821 9946666666 66 E-29    /
      DATA AK1CS( 36) / +.7290629049 2694257991 6799999999 99 E-30    /
      DATA AK1CS( 37) / -.1491844984 5546227073 0240000000 00 E-30    /
      DATA AK1CS( 38) / +.3073657387 2934276300 7999999999 99 E-31    /
C 
C SERIES FOR AK12       ON THE INTERVAL  0.          TO  1.25000E-01
C                                        WITH WEIGHTED ERROR   2.41E-32
C                                         LOG WEIGHTED ERROR  31.62
C                               SIGNIFICANT FIGURES REQUIRED  30.25
C                                    DECIMAL PLACES REQUIRED  32.38
C 
      DATA AK12CS(  1) / +.6379308343 7390010366 0048853410 2 E-1      /
      DATA AK12CS(  2) / +.2832887813 0497209358 3503028470 8 E-1      /
      DATA AK12CS(  3) / -.2475370673 9052503454 1454556673 2 E-3      /
      DATA AK12CS(  4) / +.5771972451 6072488204 7097662576 3 E-5      /
      DATA AK12CS(  5) / -.2068939219 5365483027 4553319655 2 E-6      /
      DATA AK12CS(  6) / +.9739983441 3818041803 0921309788 7 E-8      /
      DATA AK12CS(  7) / -.5585336140 3806249846 8889551112 9 E-9      /
      DATA AK12CS(  8) / +.3732996634 0461852402 2121285473 1 E-10     /
      DATA AK12CS(  9) / -.2825051961 0232254451 3506575492 8 E-11     /
      DATA AK12CS( 10) / +.2372019002 4841441736 4349695548 6 E-12     /
      DATA AK12CS( 11) / -.2176677387 9917539792 6830166793 8 E-13     /
      DATA AK12CS( 12) / +.2157914161 6160324539 3956268970 6 E-14     /
      DATA AK12CS( 13) / -.2290196930 7182692759 9155133815 4 E-15     /
      DATA AK12CS( 14) / +.2582885729 8232749619 1993956522 6 E-16     /
      DATA AK12CS( 15) / -.3076752641 2684631876 2109817344 0 E-17     /
      DATA AK12CS( 16) / +.3851487721 2804915970 9489684479 9 E-18     /
      DATA AK12CS( 17) / -.5044794897 6415289771 1728250880 0 E-19     /
      DATA AK12CS( 18) / +.6888673850 4185442370 1829222399 9 E-20     /
      DATA AK12CS( 19) / -.9775041541 9501183030 0213248000 0 E-21     /
      DATA AK12CS( 20) / +.1437416218 5238364610 0165973333 3 E-21     /
      DATA AK12CS( 21) / -.2185059497 3443473734 9973333333 3 E-22     /
      DATA AK12CS( 22) / +.3426245621 8092206316 4538880000 0 E-23     /
      DATA AK12CS( 23) / -.5531064394 2464082325 0124800000 0 E-24     /
      DATA AK12CS( 24) / +.9176601505 6859954037 8282666666 6 E-25     /
      DATA AK12CS( 25) / -.1562287203 6180249114 4874666666 6 E-25     /
      DATA AK12CS( 26) / +.2725419375 4843331323 4943999999 9 E-26     /
      DATA AK12CS( 27) / -.4865674910 0748279923 7802666666 6 E-27     /
      DATA AK12CS( 28) / +.8879388552 7235025873 5786666666 6 E-28     /
      DATA AK12CS( 29) / -.1654585918 0392575489 3653333333 3 E-28     /
      DATA AK12CS( 30) / +.3145111321 3578486743 0399999999 9 E-29     /
      DATA AK12CS( 31) / -.6092998312 1931276124 1600000000 0 E-30     /
      DATA AK12CS( 32) / +.1202021939 3698158346 2399999999 9 E-30     /
      DATA AK12CS( 33) / -.2412930801 4594088413 8666666666 6 E-31     /
c 
      data NTI1 /0/
c 
c     *****     Statement Functions     ********************************
c 
      xin(z) = ximax + 0.5*log(z/(1.0-3.0/(8.0*z))**2)
      xkn(z) = xkmax - 0.5*log(z/(1.0+3.0/(8.0*z))**2)
c 
c     *****     Executable Statements     ******************************
c 
      if (nti1 .eq. 0) then
         z = 0.1*R1MACH(3)
         boundk = 1.693 - 6.965E-3 * log(z)
         call SINITS (bi1cs, 17, z,   nti1  )
         call SINITS (ai1cs, 46, z, ntai1 )
         call SINITS (ai12cs, 69, z, ntai12)
         call SINITS (bk1cs, 16, z, ntk1  )
         call SINITS (ak1cs, 38, z, ntak1 )
         call SINITS (ak12cs, 33, z, ntak12)
         ximin  = 2.0E0*R1MACH(1)
         xisml  = sqrt (80.0E0*z)
         ximax = log(R1MACH(2)) + lsq2pi
         ximax = xin(xin(ximax))
         xksml = sqrt (40.0E0*z)
         xkmax = -log(R1MACH(1))
         xkmin = exp (max(-xkmax, -log(R1MACH(2))) + 0.01E0)
         xkmax = lsqpi2 + xkmax
         xkmax = xkn(xkn(xkn(xkmax)))
      end if
c 
      if (want.eq.0 .or. abs(want).gt.3) then
         call ierm1('SBI1K1',-1,0,'WANT = 0 OR ABS(WANT) > 3','WANT',
     1      want,'.')
         status=-1
         return
      end if
      status = 0
c 
c     Compute I1 if requested, or if needed for K1 computation.
c 
      y = abs(x)
      if (y .le. 3.0E0) then
         if (abs(want).ne.2 .or. y.le.boundk) then
            if (y .lt. ximin) then
c              if (y .ne. 0.0E0)
c    *           call SERM1('SBI1K1',2,-1,
c    *                'ABS(X) SO SMALL I1 UNDERFLOWS', 'X',x,'.')
               BI1 = 0.0
c              status = 2
            else
               if (y.le.xisml) then
                  i1ns = 0.5E0*x
               else
                  i1ns = x*(0.875E0+SCSEVL(y*y/4.5E0-1.0E0,bi1cs,nti1))
               end if
               if (want.lt.0) then
                  BI1 = exp(-y) * i1ns
               else
                  BI1 = i1ns
               end if
            end if
         end if
      else if (abs(want) .ne. 2) then
         if (y .le. 8.0E0) then
            BI1 = SCSEVL ((48.0E0/y-11.0E0)/5.0E0, ai1cs, ntai1)
         else
            BI1 = SCSEVL (16.0E0/y-1.0E0, ai12cs, ntai12)
         end if
         BI1 = sign((0.375E0 + BI1)/sqrt(y), x)
         if (want .gt. 0) then
            if (y .gt. ximax) then
               call SERM1('SBI1K1',-2,0,'ABS(X) SO BIG I1 OVERFLOWS',
     *              'X', x, '.')
               status = -2
               BI1 = R1MACH(2)
c              y > ximax => y > xkmax
               BK1 = 0.0
               if (x .gt. 0.0) return
            else
               BI1 = (exp(y-10.0) * BI1) * exp10
            end if
         end if
      end if
c 
c     Compute K1 if requested.
c 
      if (abs(want) .gt. 1) then
         if (x .le. 0.0E0) then
            call SERM1('SBI1K1',-3,0,'X IS ZERO OR NEGATIVE','X',x,'.')
            status = -3
            BK1 = R1MACH(2)
         else if (x .le. boundk) then
            if (x .lt. xkmin) then
               call SERM1('SBI1K1',-4,0,
     *              'X IS SO SMALL K1 OVERFLOWS','X', x,'.')
               status = -4
               BK1 = R1MACH(2)
            else
               if (x .le. xksml) then
                  y = 0.E0
               else
                  y = x*x
               end if
               BK1 = log(0.5E0*x)*i1ns + (0.75E0 +
     1            SCSEVL (0.5E0*y-1.0E0,  bk1cs, ntk1))/x
               if (want .lt. 0) BK1 = exp(x) * BK1
            end if
         else
            y = 16.0E0 / x
            if (x .le. 8.0E0) then
               BK1 = SCSEVL ((y-5.0E0)/3.0E0, ak1cs, ntak1)
            else
               BK1 = SCSEVL (y-1.0E0, ak12cs, ntak12)
            end if
            BK1 = (1.25E0 + BK1) / sqrt(x)
            if (want .gt. 0) then
               if (x .gt. xkmax) then
                  call SERM1('SBI1K1',1,-1,'X SO BIG K1 UNDERFLOWS','X',
     1               x,'.')
                  BK1 = 0.0
                  status = 1
               else
                  BK1 = (exp(10.0-x) * BK1) * expm10
               end if
            end if
         end if
      end if
C 
      return
c 
      end

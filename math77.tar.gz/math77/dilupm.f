      subroutine DILUPM (NDIM,X,Y,NTAB,XT,YT,NDEG,LUP,IOPT,EOPT)
c     .  Copyright (C) 1989, California Institute of Technology.
c     .  All rights reserved.  U. S. Government sponsorship under
c     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-04-08 DILUPM  Krogh  Removed unused label 350, add ID4.
c>> 1991-10-17 DILUPM  Krogh  Initial Code.
c
c Multidimensional Polynomial Interpolation with Look Up
c Design/Code by Fred T. Krogh, Jet Propulsion Laboratory, Pasadena, CA
c Last Revision: March 1, 1991
c
c This subroutine works by making multiple calls to DILUP.  See comments
c there for the kind of look up options and the kind of interpolation
c options available.
c
c *****************     Formal Arguments     ***************************
c
c If the data is not defined on a grid of values of the independent
c variables, the table is said to be ragged.  In order to describe the
c situation for ragged tables, define
c   r = index of first NTAB(i) such that NTAB(i) < 0.
c   e = -NTAB(r) if r is defined, else e = 1000.
c If e = 1000, data is on a grid and one can ignore most of what is said
c in connection with ragged tables.  In the case of ragged tables,
c either r = NDIM, or for i .ge. r, NTAB(i) = -(i-1).
c Below we refer to lexicographic order as the order in which certain
c data is stored.  Let i.1, i.2, ... i.NDIM be indices associated with
c dimensions 1, to NDIM.  Data, D, which depends on these indices, is
c said to be in lexicographic order if for all valid values of the
c indices the data is stored in consecutive location in memory, and data
c for j.1, ..., j.NDIM precedes data for i.1, ..., i.NDIM if j.1 < i.1,
c and in the case of equality if j.2 < i.2, etc.  Thus for fixed values
c of the first NDIM-1 indices, successive values of the last index will
c be in successive memory locations.
c
c NDIM   Number of dimensions for the independent variable (1<NDIM<10).
c        The upper limit is artificial to catch bad values.
c X      Vector of dimension at least NDIM giving the place where the
c        value of the interpolant is desired.
c Y      Value of the interpolant.  The interpolating function is always
c        a piecewise polynomial of NDIM variables.
c NTAB   Defines organization of the table.  In the case of a grid,
c        NTAB(1 to NDIM) contain n.1, ..., n.NDIM, the number of points
c        with respect to the various dimensions.  NTAB(NDIM+1) must be
c        0 initially.  On the first call it is set to e as defined
c        above.  Also on the first call, values of NTAB(NDIM+2:2*NDIM+1)
c        are set to values that are used to find the XT values to pass
c        to DILUP.  In the case of ragged tables more space is required.
c        In this case NTAB must have dimension > 3*NDIM + 1 + space
c        needed to store information on the raggedness.  Information for
c        each dimension with tabular information that depends on indices
c        selected for earlier dimensions starts with a 0, then the
c        number of table entries for the first value of the indices from
c        lower dimensions, then the number of entries for the next value
c        of the indices, etc.  Here "first" and "next" means with the
c        indices ordered lexicographically, that is indices from the
c        lowest dimension vary first, and those from the highest
c        dimension last.  Thus if (j,i) represent indices from the
c        second and the first dimension, the order is (1,1), (1,2), ...,
c        (2,1), (2,2), ....  Information on raggedness is supplied first
c        for the first ragged dimension, then for the next, etc.
c        The 0 starting information for one dimension must follow
c        immediately after the last item from the previous dimension.
c        A -1 must follow the information on raggedness for the last
c        dimension.  This is used to enhance the error checks.
c XT     An array giving values of the independent variable where Y is
c        is known.  The organization of XT is defined by NTAB.
c        If the values of Y are known on a grid of points, this
c        organization is simple.
c YT     Array of dependent variable values. In the case of a grid, one
c        can think of YT as an NDIM dimensional array with YT(I(NDIM),
c        I(NDIM-1), ..., I(1)) being the value of Y at X = (XT(I(1)),
c        XT(I(2)), ..., XT(I(NDIM))).  In the case of general ragged
c        tables (as for a grid too), the YT values are stored in
c        lexicographic order.
c NDEG   NDEG(i) defines the nominal degree of the polynomial to be used
c        in the ith dimension, with definition just like that for NDEG
c        in DILUP.
c LUP    LUP(i) defines the type of look up method for the ith dimension
c        exactly as LUP does in DILUP.
c IOPT   IOPT(1) is used to return a status.  Values are as for DILUP,
c        with the addition of
c   - 1    Error estimate is > that requested error.
c   - 2    Bad value for NDIM.
c   - 3    Bad value for LUP(i).
c   - 4    Bad specification for a ragged table.
c   - 5    Ragged table does not start with a 0.
c   - 6    Bad value inside a ragged table.
c   - 7    Bad value at end of ragged table.
c   - 8    Bad option index.
c   - 9    In some dimension, the first and last XT values are equal.
c   -10    Too many derivatives requested.
c   -11    Bad value for number of derivatives in some dimension.
c   -12    Problem with storage use in EOPT.
c   <-20   Had an error in DILUP.  The value is the value returned
c          by DILUP - 20.
c
c        IOPT(2) gives the dimension of EOPT.  In addition to the first
c        location and the locations in EOPT used for options, DILUPM
c        needs a contiguous block of storage in EOPT of length >
c        2*(2*NDIM - 1 + sum of NDEG(i), i = 1 to NDIM - 1).  If
c        derivatives are being computed even more space is needed as is
c        described with option 3 below.
c        To get a message printed of the space required, set IOPT(2)=0.
c
c        IOPT(k), k > 3 is used for the specifiation of options.
c        Options are as follows:
c     0  End of the option list, must be the last item in IOPT.
c     1  An error estimate is to be returned in EOPT(1)
c     2  (Argument K2) K2 is a vector of length NDIM whose i-th entry
c        gives the polynomial degree to use when extrapolating with
c        respect to the i-th dimension.  The default for the i-th entry
c        is 2 * max(1, NDEG(i)/2)).
c     3  (Arguments K3, L3, M3)  Let D(i.1, i.2, ..., i.NDIM) denote the
c        result of differentiating the interpolating polynomial i.j
c        times with respect to i.j, j = 1, 2, ..., NDIM.  The i.j
c        satisfy the restriction: sum (i.j) .le. L3, and 0 .le. i.j .le.
c        M3.j, where M3 is a vector of length NDIM,  0 .le. M3.j .le.
c        min(NDEG(j), L3).  Subject to these restrictions, the D's are
c        stored in lexicographic order of i.NDIM, ..., i.1 starting in
c        EOPT(K3).  Thus for example if NDIM = 2, L3=2, and
c        M3.1 = M3.2 = 1, then EOPT(K3) = D(1, 0), EOPT(K3+1) = D(0, 1),
c        and EOPT(K3+2) = D(1, 1).  If L3 had been 1, nothing would be
c        stored in EOPT(K3+2).
c        Extra storage in EOPT is required when this option is used, as
c        mentioned in the description of IOPT(2).  The amount needed is
c        difficult to state for the general case.  Let n.j denote the
c        total number of derivatives that must be computed in dimension
c        j in order to get the final derivatives in dimension 1.  A
c        recurrence for computing the n.j is given in the subroutine
c        write-up.  The extra storage required is = sum for j = 2, NDIM
c        of (NDEG(j-1) + 2) * n.j
c        If one does not want to deal with the complexities of figuring
c        out the storage, set K3 = 0, and a suggested organization will
c        be printed out and the program stopped.  Or, set K3 = -1, and
c        the program will use the location it computes in the case K3 =
c        0, and return the value used in IOPT where K3 was stored
c        initially.
c     4  (Argument K4) The absolute and relative errors expected in YT
c        entries are specified in EOPT(K4) and EOPT(K4+1) respectively.
c        The values provided here are used in estimating the error in
c        the interpolation.  An error estimate is returned in EOPT(1).
c     5  (Argument K5) Do the interpolation to the accuracy requested
c        by the absolute error tolerance specified in EOPT(K5).  An
c        attempt is made to keep the final error < EOPT(K5).  Standard
c        polynomial interpolation is done, but here NDEG() gives the
c        maximum polynomial degree to use in the interpolation.  If
c        EOPT(K5) .le. 0., IOPT(1) is not set to -1, and no error
c        message is generated due to an unsatisfied accuracy request.
c        An error estimate is returned in EOPT(1).
c     6  (Argument K6) Do not use a point in the interpolation if the
c        corresponding value of YT = EOPT(K6).
c EOPT   Array used to return an error estimate, and used for options.
c     EOPT(1)  if an error estimate is returned, this contains a crude
c              estimate of the error in the interpolation.
c
c *****************     Variables Referenced     ***********************
c
c ABS    Fortran intrinsic -- absolute value.
c BADPT  In common CDILUP, see documentation in DILUP.
c DX     In common CDILUP, see documentation for DILUP.
c EBND   In common CDILUP, see documentation for DILUP.
c EBNDR  In common CDILUP, see documentation for DILUP.
c EOPT   Formal argument, see above.
c ERRDAT Place to store floating point for error messages.
c ERRSAV Place for saving error estimates.
c GETERP Usual value for GETERR.
c GETERR In common CDILUP, see documentation for DILUP.
c I      Temporary index.
c ID     Current place to pick up derivatives from higher dimension in
c        order to interpolate derivative in a lower dimension.
c ID4    = 4 defined in data.  To avoid passing literal to SILUP.
c IDIM   Index of dimension currently active.
c IDX    In common CDILUP, see documentation for DILUP.
c IDXBAS Base location for storing values of DX in EOPT.  ( =IOPT(2)+1)
c        The first DX is stored in EOPT(IDXBAS+1).
c IEEOPT Index for absolute and relative error in EOPT.
c IIFLG  Value of flag to be returned in IOPT(1).
c IMAXD  IOPT(IMAXD+IDIM) gives the maximum derivative to be computed
c        with respect to dimension IDIM.
c INTCHK Array used for checking use of optional space in EOPT.
c IOP2N  Value to store in IOPTI(2) when interpolating in the last
c        dimension.  = 255 if bad points possbile, else = 254.
c IOPT   Formal argument, see above.
c IOPTI  Internal array used to pass options to DILUP.
c IP     Array used to compute current indices into XT and YT.
c IPRAG  Part of a term used in computing IP when IDIM>IRAG, and
c        NTAB(IDIM) > 0.
c IRAG   = index of first ragged table, = 1000 if table not ragged.
c IX     Current point index w.r.t. the current dimension.
c IXT    Pointer to XT information for the current dimension.
c IYBAS  One less than first location for storing values interpolated
c        for y in EOPT.
c IYSAV  Location in EOPT for saving interpolated value.
c IYT    Location in EOPT where vector of interpolated Y's are stored.
c J      Index of a 0 in NTAB which is followed by user information
c        specifying the number of data points as a function of
c        previously used values from XT.
c K      Temporary index.
c KAOS   In common CDILUP.   Keeps track of state on variable order.
c    = 0   No variable order -- this value only set in DILUPM.
c    = 1   First time
c    = 2   Second time
c    = 3   Just had an increase or a very weak decrease in the error.
c    = 4   Just had a strong decrease in the error.
c KC     Array used for counters for computing derivatives.
c KEXTRP In common CDILUP, see documentation in DILUP.
c KGOC   In common CDILUP, see documentation for DILUP.
c KL     Largest total derivative as starting from the highest dimension
c        and working to dimension 1 in getting storage needed for
c        derivatives.
c KPTD   KPTD(IDIM) = pointer to extra derivative information for
c        dimension IDIM.  KPTD(IDIM-1) is place to store deriv.
c        values for dim. IDIM.
c L      Temporary index.
c LCKEND End of space used for checking storage in EOPT.
c LDERIV In common CDILUP, see documentation for DILUP.
c LERTMP Location in EOPT where temp. error info. is stored (2 values).
c LEXERR In common CDILUP, see documentation for DILUP.
c LEXIT  In common CDILUP.  Defines action after finding location in XT.
c    0     Don't compute anything for Y, just return. (Used for DILUPM.)
c    1     Usual case, just interpolate.
c   >1     Compute LEXIT-1 derivatives of the interpolant.
c LI     Last location examined in IOPT().
c LICINF Base for indexing information that depends on the current
c        point index in the current dimension.
c LIDX   Array containing indices of the points selected for all
c        dimensions up to the current one.  Also used in computing
c        KPTD.
c LIDXSZ Parameter giving the amount of space allocated for LIDX.
c LINFO  LINFO(IDIM) contains a pointer to the index currently being
c        worked on in dimension IDIM.
c LINFO0 LINFO0(IDIM) gives value to use LICINF when in dim. IDIM, =
c        1 + sum of (2 + NDEG(J)) for J = 1, 2, ..., IDIM-1.
c LKGOC  LKGOC(IDIM) contains value of KGOC for interp. in dim. IDIM.
c LNDEG  LNDEG(IDIM) contains value of NDEG for interp. in dim. IDIM.
c LOPT   Value from current location in IOPT.
c LT     As much of NTAB as is known to be safe for printing error info.
c LUP    Formal argument, see above.
c LUPC   Value passed to DILUP for LUP, the look up method.
c MACT   Array giving actions for printing error messages, see MESS.
c MAX    Fortran intrinsic -- maximum
c MAXDEG Parameter -- Gives maximum degree of polynomial interpolation.
c MAXDIM Paramter giving the maximum number of dimensions allowed.
c MECONT Parameter telling MESS an error message is to be continued.
c MEEMES Parameter telling MESS to print an error message.
c MEIVEC Parameter telling MESS to print an integer vector.
c MEMDA1 Parameter telling MESS that next item is integer data to be
c        made available for output.
c MERET  Parameter telling MESS that this ends the error message.
c MESS   Subroutine for printing error messages.
c METEXT Parameter telling MESS that data from MTEXT is to printed.
c LTXTxx Parameter names of this form were generated by PMESS in making
c        up text for error messages and are used to locate various parts
c        of the message.
c MLOC   Array giving locations of start of text for error messages.
c MTEXT  Text to be processed as part of an error message.
c MTOTD  Maximum order of total derivative to be computed.
c MTXTxx Character variables made up by PMESS, equivalenced to MTEXT.
c MXD    Upper bound on number of derivatives to compute when computing
c        derivatives based on information from higher dimensions.
c NDEG   Formal argument, see above.
c NDEGEC In common CDILUP, see documentation for DILUP.
c NDIM   Formal argument, see above.
c NDIMI  Internal value for NDIM = number of dimensions.
c NT     Number of points for the current call to DILUP.
c NTAB   Formal argument, see above.
c NTABM  = NTABXT + NDIMI -- NTAB(NTABM+I) is 1 + the index of the last
c        word in NTAB required for ragged table storage through dim. I.
c NTABXT = NDIMI+1 -- NTAB(NTABXT) = index of first ragged table, =1000
c        if there is no ragged table.  NTABN(NTABXT+I) = base address
c        accessing XT information.
c NUMD   NUMD(j) gives the number of different derivatives for
c        dimension j.
c OPTCHK Subroutine for checking on space allocation for options.
c SETEXT If not 0, gives IOPT(SETEXT+IDIM) gives the value to use for
c        KEXTRP in dimension IDIM.
c DILUP  One dimensional interpolation subroutine.
c DMESS  Calls MESS and prints floating data in error messages.
c STOD   Index in EOPT where derivatives are to be stored.
c X      Formal argument, see above.
c XT     Formal argument, see above.
c Y      Formal argument, see above.
c YT     Formal argument, see above.
c
c     *************     Formal Variable Declarations     ***************
c
      integer          NDIM, NTAB(*), NDEG(*), LUP(*), IOPT(*)
      double precision X(NDIM), Y, XT(*), YT(*), EOPT(*)
c
c     *************     Common Block and Parameter     *****************
c
c                               MAXDEG must be odd and > 2.
      parameter (MAXDEG = 15)
c
      logical          GETERR, GETERP
      integer          KAOS, KEXTRP, KGOC,LDERIV,LEXERR,LEXIT,NDEGEC,
     1                 IDX(0:MAXDEG+1)
      double precision BADPT, DX(0:MAXDEG+1), EBND, EBNDR
      common / CDILUP / BADPT, DX, EBND, EBNDR, KAOS, KEXTRP, KGOC,
     1                  LDERIV, LEXERR,LEXIT,NDEGEC,IDX,GETERR
c
c     *************     Local Variables     ****************************
c
      parameter (MAXDIM = 6)
      parameter (LIDXSZ = MAXDIM*(2 + MAXDEG))
      integer          IP(MAXDIM), LINFO(0:MAXDIM),
     1                 LINFO0(0:MAXDIM), LKGOC(MAXDIM), LNDEG(MAXDIM)
      integer          LIDX(LIDXSZ)
      integer          I, IDIM, IDXBAS, IEEOPT, IIFLG, IMAXD,
     1 INTCHK(0:20), IOP2N, IOPTI(3), IPRAG, IRAG, IX, IYBAS, IYSAV,
     2 IYT, J, K, KC(MAXDIM), KPTD(0:MAXDIM), L, LERTMP, LI, LT, LICINF,
     3 LOPT, LUPC, MTOTD, NDIMI, NT, NTABM, NTABXT,
     4 NUMD(MAXDIM), SETEXT, STOD
       equivalence (KPTD(0), STOD)
       double precision ERRSAV(MAXDIM)
c
c ************************ Error Message Stuff and Data ****************
c
c Parameter defined below are all defined in the error message program
c MESS and DMESS.
c
      parameter (MEMDA1 =27)
      parameter (MECONT =50)
      parameter (MERET =51)
      parameter (MEEMES =52)
      parameter (METEXT =53)
      parameter (MEIVEC =57)
c
      integer MLOC(12)
      integer MACT(12)
      double precision ERRDAT(2)
c
      character MTEXT(652)
      parameter (LTXTAA = 1)
      character MTXTAA*(8)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 9)
      character MTXTAB*(45)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      parameter (LTXTAC = 54)
      character MTXTAC*(46)
      equivalence (MTEXT(LTXTAC), MTXTAC)
      parameter (LTXTAD = 100)
      character MTXTAD*(33)
      equivalence (MTEXT(LTXTAD), MTXTAD)
      parameter (LTXTAE = 133)
      character MTXTAE*(47)
      equivalence (MTEXT(LTXTAE), MTXTAE)
      parameter (LTXTAF = 180)
      character MTXTAF*(53)
      equivalence (MTEXT(LTXTAF), MTXTAF)
      parameter (LTXTAG = 233)
      character MTXTAG*(55)
      equivalence (MTEXT(LTXTAG), MTXTAG)
      parameter (LTXTAH = 288)
      character MTXTAH*(52)
      equivalence (MTEXT(LTXTAH), MTXTAH)
      parameter (LTXTAI = 340)
      character MTXTAI*(38)
      equivalence (MTEXT(LTXTAI), MTXTAI)
      parameter (LTXTAJ = 378)
      character MTXTAJ*(61)
      equivalence (MTEXT(LTXTAJ), MTXTAJ)
      parameter (LTXTAK = 439)
      character MTXTAK*(59)
      equivalence (MTEXT(LTXTAK), MTXTAK)
      parameter (LTXTAL = 498)
      character MTXTAL*(51)
      equivalence (MTEXT(LTXTAL), MTXTAL)
      parameter (LTXTAM = 549)
      character MTXTAM*(53)
      equivalence (MTEXT(LTXTAM), MTXTAM)
      parameter (LTXTAN = 602)
      character MTXTAN*(12)
      equivalence (MTEXT(LTXTAN), MTXTAN)
      parameter (LTXTAO = 614)
      character MTXTAO*(13)
      equivalence (MTEXT(LTXTAO), MTXTAO)
      parameter (LTXTAP = 627)
      character MTXTAP*(13)
      equivalence (MTEXT(LTXTAP), MTXTAP)
      parameter (LTXTAQ = 640)
      character MTXTAQ*(13)
      equivalence (MTEXT(LTXTAQ), MTXTAQ)
      DATA MTXTAA/'DILUPM$B'/,
     1MTXTAB/'Estimated error = $F, Requested error = $F.$E'/,
     2MTXTAC/'Need NDIM in interval [1, $I] but NDIM = $I.$E'/,
     3MTXTAD/'LUP($I) = $I; it should be < 4.$E'/,
     4MTXTAE/'Ragged table badly specified in dimension $I.$E'/,
     5MTXTAF/'Start of ragged table, NTAB($I) = $I; it must be 0.$E'/,
     6MTXTAG/'Middle of ragged table, NTAB($I) = $I; it must be >0.$E'/,
     7MTXTAH/'End of ragged table, NTAB($I) = $I; it must be -1.$E'/,
     8MTXTAI/'IOPT($I) = $I is not a valid option.$E'/,
     9MTXTAJ/
     A'In dimension $I, first XT = XT($I) = last XT = XT($I) = $F.$E'/
      DATA MTXTAK/
     1'A total of only $I derivatives allowed, but $I requested.$E'/,
     2MTXTAL/'Need derivative order in [0, $I], but it is = $I.$E'/,
     3MTXTAM/'Previous error from DILUP occurred in dimension $I.$E'/,
     4MTXTAN/'LUP(1:$M):$B'/,MTXTAO/'NDEG(1:$M):$B'/,
     5MTXTAP/'NTAB(1:$M):$B'/,MTXTAQ/'IOPT(1:$M):$B'/
c
      data MLOC /LTXTAB, LTXTAC, LTXTAD, LTXTAE, LTXTAF, LTXTAG, LTXTAH,
     1           LTXTAI, LTXTAJ, LTXTAK, LTXTAL, LTXTAM/
c
c                      1 2 3 4       5       6 7       8       9 10
      data MACT / MEEMES,0,0,0, MECONT, MEMDA1,0, METEXT, MEIVEC, 0,
     1   MECONT,  MERET / 
      data INTCHK(0) / 120 /
      data ID4 / 4 /
c 
c *****************     Start of executable code     *******************
c
      LI = 2
      NDIMI = NDIM
      NTABXT = NDIMI+1
      NTABM = NTABXT + NDIMI
      LT = NTABM
      if (NTAB(NTABXT) .le. 0) then
c                            Fix NTAB on the first call.
         if (NDIMI .gt. MAXDIM) then
             INTCHK(1) = MAXDIM
             INTCHK(2) = NDIMI
             IIFLG = -2
             go to 400
         end if
         NTAB(NTABXT) = 1000
         NTAB(NTABXT+1) = 1
         do 40 I = 1, NDIMI
            if (LUP(I) .ge. 4) then
               INTCHK(1) = I
               INTCHK(2) = LUP(I)
               IIFLG = -3
               go to 400
            end if
            L = NTAB(I)
            if (L .gt. 0) then
c                             Table is not ragged up to this point.
               if (I .eq. NDIMI) go to 50
               if (NTAB(NDIMI) .lt. 0)  NTAB(NTABM+I) = NTABM+NDIMI
c       Get pointer to start of XT data for next dimension
               if (LUP(I) .eq. 3) then
                  NTAB(NTABXT+I+1) = NTAB(NTABXT+I) + 2
               else
                  NTAB(NTABXT+I+1) = NTAB(NTABXT+I) + L
               end if
            else if ((L .eq. 0) .or. ((L .ne. 1-I) .and.
     1         ((I .ne. NDIMI) .or. (L .le. -I)))) then
c                                 Problem in specifying raggedness.
               LT = NDIMI
               INTCHK(1) = I
               IIFLG = -4
               go to 400
            else
               J = NTAB(NTABM+I-1)
               if (NTAB(I-1) .gt. 0) then
                  NTAB(NTABXT) = -NTAB(I)
c       Get K = number of NTAB entries of extra data
                  K = NTAB(1)
                  do 10 L = 2, -L
                     K = K * NTAB(L)
   10             continue
               else
                  K = NTAB(J-1)
               end if
               if (NTAB(J) .ne. 0) then
                  LT = J
                  INTCHK(1) = J
                  INTCHK(2) = NTAB(J)
                  IIFLG = -5
                  go to 400
               end if
c       Change data to be the partial sum of the original data.
               LT = J + K
               do 30 L = J + 1, LT
                  if (NTAB(L) .le. 0) then
                     INTCHK(1) = L
                     INTCHK(2) = NTAB(L)
                     IIFLG = -6
                     go to 400
                  end if
                  NTAB(L) = NTAB(L) + NTAB(L-1)
   30          continue
               if (I .eq. NDIMI) then
                  LT = LT + 1
                  if (NTAB(LT) .eq. -1) go to 50
                  INTCHK(1) = LT
                  INTCHK(2) = NTAB(LT)
                  IIFLG = -7
                  go to 400
               end if
c       Save index of 0th NTAB entry for extra data for next dim.
               NTAB(NTABM+I) = J + K + 1
c       Get pointer to start of XT data for next dimension
               if (LUP(I) .eq. 3) then
                  NTAB(NTABXT+I+1) = NTAB(NTABXT+I) + 2*K
               else
                  NTAB(NTABXT+I+1) = NTAB(NTABXT+I)+NTAB(J+K)
               end if
            end if
   40    continue
      end if
   50 continue
      IIFLG = 0
      LINFO(0) = 0
      LINFO0(0) = 0
      LINFO0(1) = 1
      do 60 I = 2, NDIMI
         LINFO0(I) = LINFO0(I-1) + NDEG(I-1) + 2
   60 continue
c                  Initialize option flags
      GETERP = .false.
      SETEXT = 0
      KAOS = 0
      IEEOPT = 0
      STOD = 0
      LDERIV = 0
      IOP2N = 254
      IRAG = NTAB(NTABXT)
      INTCHK(4) = 0
      INTCHK(6) = 0
      INTCHK(5) = -2 * (LINFO0(NDIMI) + 1)
      LCKEND = 7
      go to 70
c
   62 INTCHK(LCKEND+2) = 1
   64 INTCHK(LCKEND+1) = IOPT(LI)
   65 INTCHK(LCKEND) = LOPT
      LCKEND = LCKEND + 3
   70 continue
      LI = LI + 1
      LOPT = IOPT(LI)
      if (LOPT .ne. 0) then
         go to (310, 320, 330, 300, 340, 360), LOPT
         INTCHK(1) = LI
         INTCHK(2) = LOPT
         IIFLG = -8
         go to 400
      end if

      INTCHK(1) = LCKEND
      INTCHK(2) = IOPT(2)
      INTCHK(3) = 1
      INTCHK(LCKEND) = 1
      call OPTCHK(INTCHK, IOPT, 'DILUPM / EOPT$E')
      if (INTCHK(1) .lt. 0) then
         IOPT(1) = -12
         return
      end if
      J = LCKEND
c Store values for storage locations determined by OPTCHK.
   75 J = J + 1
      K = INTCHK(J)
      if (INTCHK(K) .eq. 0) then
         LERTMP = INTCHK(INTCHK(LCKEND+1)+1)
      else
         STOD = INTCHK(INTCHK(LCKEND+2)+1)
      end if
      if (J .ne. INTCHK(LCKEND)) go to 75
      IDXBAS = LERTMP+1
      IYBAS = IDXBAS + LINFO0(NDIMI)
      if (STOD .ne. 0) then
         K = IYBAS + LINFO0(NDIMI)
         do 80 J = 1, NDIMI
            KPTD(J) = KPTD(J) + K
   80    continue
         LDERIV = KPTD(NDIMI-1)
      end if
      IYSAV = IYBAS
      do 90 I = LERTMP, IYBAS
c Ensure in DILUP, YT will be defined. (It's ref. but not used.)
         EOPT(I) = 0
   90 continue
      ERRSAV(1) = 0.D0
      IYT = IDXBAS

      GETERR = GETERP
      IDIM = 1
      IXT = 1
      LUPC = LUP(1)
      IP(1) = 0
  100 NT = NTAB(IDIM)
  110 LEXIT = 0
c                 Setup for variable order.
      if (KAOS .ne. 0) then
         KAOS = 1
         IOPTI(3) = NDEG(IDIM)
      end if
c                 Set KEXTRP to indicate how to extrapolate
      KEXTRP = -1
      if (SETEXT .ne. 0) KEXTRP = IOPT(SETEXT + IDIM)
      if (IDIM .ne. NDIMI) go to 180
c                             Interpolate in the last dimension.
c                 Flag that want results on the exit
      LEXIT = 1
c                 Setup for getting derivatives.
      if (LDERIV .gt. 0) LEXIT = IOPT(IMAXD+IDIM) + 1
c                 Indicate where error info. on Y is found (if any)
      LEXERR = IEEOPT
c                 Indicate whether there are bad points.
      IOPTI(2) = IOP2N
c
      call DILUP(X(IDIM), EOPT(IYSAV), NT, XT(IXT), YT(IP(IDIM)+1),
     1   NDEG(IDIM), LUPC, IOPTI, EOPT)
      if (LUPC .lt. 0) LUP(IDIM) = LUPC
      if (IOPTI(1) .lt. -1) go to 390
      IIFLG = max(IIFLG, IOPTI(1))
  130 continue
c                             Back up to lower dimension
      IDIM = IDIM - 1
      if (IDIM .eq. 0) then
         Y = EOPT(IYSAV)
         IOPT(1) = IIFLG
         if (IOPTI(1) .ge. 0) return
         IIFLG = IOPTI(1)
         ERRDAT(1) = EOPT(1)
         ERRDAT(2) = EBND
         go to 400
      end if
      if (GETERP) ERRSAV(IDIM) = max(ERRSAV(IDIM), EOPT(1))
      NDEGEC = LNDEG(IDIM)
      if (KAOS .ne. 0) then
         if (LINFO(IDIM) .ge. LINFO0(IDIM) + 3) then
            NDEGEC = LINFO(IDIM) - LINFO0(IDIM)
            go to 140
         end if
      end if
      if (LINFO(IDIM) .lt. LINFO0(IDIM) + NDEGEC) go to 220
c                              Restore information in the common block
  140 KGOC = abs(LKGOC(IDIM))
      LICINF = LINFO0(IDIM)
      LINFO(IDIM+1) = LINFO0(IDIM+1)
      do 150 I = 0, NDEGEC
         IDX(I) = LIDX(I+LICINF)
         DX(I) = EOPT(I+IDXBAS+LICINF)
  150 continue
      IYSAV = IYBAS + LINFO(IDIM-1)
      IYT = IYBAS + LINFO0(IDIM)
c                 Flag that already have the Y's in order.
      LUPC = 4
c                 Flag that want results on the exit
      LEXIT = 1
c                 Setup for getting derivatives.
      if (LDERIV .ne. 0) then
         if (LDERIV .ge. -IDIM) then
            LDERIV = KPTD(IDIM-1)
            if (IDIM .ne. 1) LDERIV = LDERIV + NUMD(IDIM) *
     1          (LINFO(IDIM-1)-LINFO0(IDIM-1))
            LEXIT = IOPT(IMAXD+IDIM) + 1
         end if
      end if
c                 Indicate where error info. on Y is found (if any)
      if (GETERP) then
         LEXERR = LERTMP
         EOPT(LEXERR) = ERRSAV(IDIM)
         EOPT(LEXERR+1) = 0.D0
      end if
c                 Setup for variable order.
      if (KAOS .ne. 0) then
         KAOS = 1
         IOPTI(3) = NDEGEC
      end if
c                 Indicate no bad points.
  180 IOPTI(2) = 254
c
      call DILUP(X(IDIM), EOPT(IYSAV), NT, XT(IXT), EOPT(IYT),
     1   NDEG(IDIM), LUPC, IOPTI, EOPT)
      if (IOPTI(1) .lt. -1) go to 390
      IIFLG = max(IIFLG, IOPTI(1))
      if (LEXIT .eq. 0) then
c                            Just selected points for this dimension
         if (LUPC .lt. 0) LUP(IDIM) = LUPC
c                             Save info. from the common block.
         LKGOC(IDIM) = KGOC
         LNDEG(IDIM) = NDEGEC
         LICINF = LINFO0(IDIM)
         LINFO(IDIM) = LICINF
         do 210 I = 0, NDEGEC
            LIDX(I+LICINF) = IDX(I)
            EOPT(I+IDXBAS+LICINF) = DX(I)
  210    continue
         go to 230
      else
c                            Just got result for this dimension
c                  IOPTI(2) = 0, if variable order and need more points.
         if (IOPTI(2) .eq. 0) go to 220
         if (LDERIV .gt. 0) then
            GETERR = .false.
            ID = KPTD(IDIM)
            do 212 I = IDIM+1, NDIMI
               KC(I) = 0
  212       continue
            MXD = MTOTD
  214       IYSAV = LDERIV + LEXIT - 1
            L = IDIM + 1
  215       if ((KC(L) .eq. IOPT(IMAXD+L)) .or. (MXD .eq. 0)) then
               MXD = MXD + KC(L)
               KC(L) = 0
               L = L + 1
               if (L .le. NDIMI) go to 215
               go to 218
            end if
            KC(L) = KC(L) + 1
            MXD = MXD - 1
            LEXIT = min(MXD, IOPT(IMAXD+IDIM)) + 1
            LDERIV = IYSAV + 1
            do 216 I = 0, NDEGEC
               EOPT(IYT+I) = EOPT(ID + NUMD(IDIM+1)*I)
  216       continue
            ID = ID +1
            KGOC = abs(KGOC)
            call DILUP(X(IDIM), EOPT(IYSAV), NT, XT(IXT), EOPT(IYT),
     1         NDEGEC, ID4, IOPTI, EOPT)
            go to 214
  218       GETERR = GETERP
         end if
         go to 130
      end if
  220 LINFO(IDIM) = LINFO(IDIM) + 1
      if (LDERIV .gt. 0) then
         if (LINFO(IDIM) .eq. LINFO0(IDIM) + NDEGEC) then
            if (LKGOC(IDIM) .eq. -2) then
               LDERIV = -IDIM
               go to 230
            end if
         end if
         if (IDIM .eq. NDIMI-1) then
            LDERIV = LDERIV + NUMD(NDIMI)
         else
            LDERIV = KPTD(NDIMI-1)
         end if
      end if
  230 IX = LIDX(LINFO(IDIM))
c          Get here after getting next point in this dimension
c               Compute IP() data for getting XT and YT indices
      if (IDIM .lt. IRAG) then
         IP(IDIM+1) = NTAB(IDIM+1) * (IX - 1 + IP(IDIM))
      else if (IDIM .eq. IRAG) then
         K = NTAB(NTABM+IDIM) + IP(IDIM) + IX
         IP(IDIM+1) = NTAB(K-1)
         IPRAG = NTAB(K) - NTAB(K-1)
      else if (NTAB(IDIM) .gt. 0) then
         IP(IDIM+1) = NTAB(IDIM) * IP(IDIM) + (IX -1) * IPRAG
      else
         IP(IDIM+1) = NTAB(NTAB(NTABM+IDIM)+IP(IDIM)+IX-1)
      end if
      IYSAV = IYBAS + LINFO(IDIM)
      IDIM = IDIM + 1
      ERRSAV(IDIM) = 0.D0
      if ((LEXIT .eq. 0) .or. (NTAB(IDIM) .lt. 0)) then
         IXT = NTAB(NTABXT+IDIM)
         LUPC = LUP(IDIM)
         if (NTAB(IDIM) .ge. 0) go to 100
         K = -NTAB(IDIM)
         K = NTAB(NTABM+K) + IP(K)
         NT = NTAB(K+1) - NTAB(K)
         if (LUPC .eq. 3) then
            IXT = IXT+2*(IP(-NTAB(IDIM))+LIDX(LINFO(-NTAB(IDIM)))-1)
         else
            IXT = IXT + IP(1-NTAB(IDIM))
         end if
         go to 110
      end if
      if (IDIM .eq. NDIM) then
         LUPC = LUP(IDIM)
         go to 110
      end if
      LINFO(IDIM) = LINFO0(IDIM)
      go to 230
c
c Process various options
c Specify error in Y.
  300 LI = LI + 1
      IEEOPT = IOPT(LI)
      INTCHK(LCKEND+2) = 2
      GETERP = .true.
      go to 64
c Return an error estimate
  310 GETERP = .true.
      go to 70
c Setup to set extrapolation degree
  320 SETEXT = LI
      LI = LI + NDIMI
      go to 70
c Setup for computing extra derivatives
  330 STOD = IOPT(LI+1)
      INTCHK(LCKEND+1) = STOD
      IMAXD = LI + 2
      MTOTD = IOPT(IMAXD)
      if (MTOTD .ge. LIDXSZ) then
         INTCHK(1) = LIDXSZ
         INTCHK(2) = MTOTD
         IIFLG = -10
         go to 400
      end if
      KL = IOPT(IMAXD+NDIMI)
      K = min(MTOTD, NDEG(NDIMI))
      if ((KL .lt. 0) .or. (KL .gt. K)) then
         INTCHK(1) = K
         INTCHK(2) = KL
         IIFLG = -11
         go to 400
      end if
      do 332 K = 0, MTOTD
         LIDX(K+1) = min(K, KL) + 1
  332 continue
      NUMD(NDIMI) = KL
      do 338 J = NDIMI-1, 1, -1
         L = IOPT(IMAXD+J)
         K = min(MTOTD, NDEG(J))
         if ((L .lt. 0) .or. (L .gt. K)) then
            INTCHK(1) = K
            INTCHK(2) = L
            IIFLG = -11
            go to 400
         end if
         do 334 K = MTOTD, L+1, -1
            LIDX(K+1) = LIDX(K+1) - LIDX(K-L)
  334    continue
         do 336 K = 1, MTOTD
            LIDX(K+1) = LIDX(K) + LIDX(K+1)
  336    continue
         KL = min (KL + L, MTOTD)
         NUMD(J) = LIDX(KL+1) - 1
  338 continue
      INTCHK(LCKEND+2) = NUMD(1)
      if (STOD .le. 0) then
         INTCHK(LCKEND+1) = -NUMD(1)
         INTCHK(LCKEND+2) = LI + 1
      end if
      KPTD(1) = 0
      do 339 J = 2, NDIMI
         KPTD(J) = KPTD(J-1) + NUMD(J) * (NDEG(J-1) + 2)
  339 continue
      INTCHK(5) = INTCHK(5) - KPTD(NDIMI)
      LI = IMAXD + NDIMI
      go to 65
c Setup for variable order.
  340 LI = LI + 1
      EBND = EOPT(IOPT(LI))
      EBNDR = 0.D0
      KAOS = 1
      GETERP = .true.
      go to 62
c Setup to indicate bad points
  360 LI = LI + 1
      BADPT = EOPT(IOPT(LI))
      IOP2N = 255
      go to 62
c Error Processing
  390 IIFLG = IOPTI(1) - 20
      INTCHK(1) = IDIM
      MACT(4) = MLOC(10)
      go to 410
  400 MACT(4) = MLOC(-IIFLG)
  410 IOPT(1) = IIFLG
      MACT(3) = -IIFLG
      MACT(2) = 88
      if (IIFLG .eq. -1) MACT(2) = 25
      call DMESS (MACT, MTEXT, INTCHK(1), ERRDAT)
      if (IIFLG .lt. -2) then
         MACT(7) = NDIMI
         MACT(10) = NDIMI
         call MESS (MACT(6), MTEXT(LTXTAN), LUP)
         call MESS (MACT(6), MTEXT(LTXTAO), NDEG)
         MACT(7) = LT
         MACT(10) = LT
         call MESS (MACT(6), MTEXT(LTXTAP), NTAB)
         if (LI .gt. 3) then
            MACT(7) = LI
            MACT(10) = LI
            call MESS (MACT(6), MTEXT(LTXTAQ), IOPT)
         end if
      end if
      call MESS (MACT(12), MTEXT, INTCHK(1))
      return
      end

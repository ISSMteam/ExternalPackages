      FUNCTION SCPLTE(EM)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1989-06-16 SCPLTK Snyder  Remove implied DO from DATA stmts for CFT
C>> 1985-08-02 SCPLTE Lawson  Initial code.
C
C     Complete elliptic integral E(EM). Method given by
C     W.J.CODY, Math. of Comp.,Vol.19, (1965), pp. 105-111.
C     Data are taken from Cody's table in reverse order.
C     We are using N = 5 or 9 for single precision and
C     N = 10 for double precision.
C
C     C.L.LAWSON & STELLA CHAN,JPL,1983 JUNE.
C
C     ----------------------------------------------------
C
C     POLY DEGREE     NEGATIVE LOG BASE 10 OF MAX ABS
C                     ERROR OF APPROXIMATION
C
C         N           FOR K           FOR E
C         -           -----           -----
C         5            9.50            9.44
C         9           15.87           15.84
C        10           17.45           17.42
C
C     ----------------------------------------------------
C
      REAL C(9,2), D(9,2)
C
      SAVE M, MAX, FAC
C
      DATA ZERO,ONE,HALF / 0.E0, 1.E0 ,.5E0 /
C
      DATA M / 0 /
C
      DATA C(1,1), C(2,1) / 7.65296060328E-03, 3.06623474572E-02 /
      DATA C(3,1), C(4,1) / 3.17611455247E-02, 5.75669984841E-02 /
      DATA C(5,1)         / 4.43152874726E-01 /
C
      DATA C(1,2) / 3.25192015506390418E-04 /
      DATA C(2,2) / 4.30253777479311659E-03 /
      DATA C(3,2) / 1.17858410087339355E-02 /
      DATA C(4,2) / 1.18419259955012494E-02 /
      DATA C(5,2) / 9.03552773754088184E-03 /
      DATA C(6,2) / 1.17167669446577228E-02 /
      DATA C(7,2) / 2.18361314054868967E-02 /
      DATA C(8,2) / 5.68052233293082895E-02 /
      DATA C(9,2) / 4.43147180583368137E-01 /
C
      DATA D(1,1), D(2,1) / 2.12479182845E-03, 2.18360211693E-02 /
      DATA D(3,1), D(4,1) / 5.42605244487E-02, 9.35649078307E-02 /
      DATA D(5,1)         / 2.49999202736E-01 /
C
      DATA D(1,2) / 7.20316963457154599E-05 /
      DATA D(2,2) / 1.86453791840633632E-03 /
      DATA D(3,2) / 1.00879584943751004E-02 /
      DATA D(4,2) / 2.26603098916041221E-02 /
      DATA D(5,2) / 3.28110691727210618E-02 /
      DATA D(6,2) / 4.26725101265917523E-02 /
      DATA D(7,2) / 5.85927071842652739E-02 /
      DATA D(8,2) / 9.37499951163670673E-02 /
      DATA D(9,2) / 2.49999999997461423E-01 /
C
      IF (M .EQ. 0) THEN
C
C     -LOG10(6.31E-9) = 8.2
C
        IF (R1MACH(3) .LT. 6.31E-9) THEN
          M = 2
          MAX = 9
        ELSE
          M = 1
          MAX = 5
        END IF
        FAC = ONE + 2 * R1MACH(3)
      END IF
      IF (EM .GT. ONE) THEN
        CALL SERM1('SCPLTE',1,0,'UNDEFINED FOR EM .GT. ONE',
     *             'EM',EM,'.')
        U = ZERO
      ELSE IF (EM .LT. ZERO) THEN
        CALL SERM1('SCPLTE',2,0,'UNDEFINED FOR EM .LT. ZERO',
     *             'EM',EM,'.')
        U = ZERO
      ELSE
        EMP = HALF + (HALF- EM)
        IF (EMP .EQ. ZERO) THEN
          U = ONE
          GO TO 10
        END IF
        S3 = EMP * C(1,M)
        S4 = EMP * D(1,M)
        DO 100 J = 2, MAX
          S3 = (S3 + C(J,M)) * EMP
          S4 = (S4 + D(J,M)) * EMP
  100   CONTINUE
        U = ONE + S3 + LOG(ONE/EMP) * S4
      END IF
C
  10  SCPLTE = U * FAC
      RETURN
C
      END

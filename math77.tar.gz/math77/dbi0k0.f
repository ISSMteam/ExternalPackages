      subroutine DBI0K0 (x, BI0, BK0, want, status)
C>>   1990-10-18 DBI0K0 WV Snyder JPL Use Cody K0 for small X
C>>   1990-09-25 DBI0K0 WV Snyder JPL Use Fullerton codes from CMLIB
C--   S VERSION USES SBI0K0, SCSEVL, R1MACH, SERM1, SINITS
C--   D VERSION USES DBI0K0, DCSEVL, D1MACH, DERM1, DINITS
c 
c     Compute hyperbolic Bessel functions I0 and K0.
c     Approximations for K0(X) on 0 < X < BOUNDK originally produced
c     by W. James Cody, ANL.  Other approximations originally produced
c     by Wayne Fullerton, LASL.
c 
c     *****     Formal Arguments     ***********************************
c 
c X [in] is the argument at which the functions are to be evaluated.
c BI0, BK0 [out] are the function values.
c WANT [integer,in] indicates the functions to be computed, and their
c                   scaling:
c     ABS(WANT) =
c        1 means compute I0(X)
c        2 means compute K0(X)
c        3 means compute both of I0(X) and K0(X)
c     WANT < 0 means compute EXP(-X)*I0(X) and/or EXP(X)*K0(X).
c     WANT=0 or ABS(WANT) > 3 causes an error message to be produced.
c STATUS [integer,out] indicates the outcome:
c     0 means normal computation,
c     1 means K0(X) is zero due to underflow,
c     < 0 means an error occurred:
c     -1 means WANT=0 or ABS(WANT)>3,
c     -2 means X was so big that I0(X) overflowed,
c     -3 means X was zero or negative and K0(X) is to be computed.
c     Negative values of STATUS are produced when the error message
c     processor is called with LEVEL=0; positive values of STATUS are
c     accompanied by LEVEL=-2.  See the description of the error message
c     handler for a description of the error level effects.
c     If status = -2 then BI0 = the largest representable number;
c     if status = -3 then BK0 = the largest representable number.
c     ------------------------------------------------------------------
      double precision X, BI0, BK0
      integer WANT, STATUS
c 
c     *****     External References     ********************************
c 
      double precision D1MACH, DCSEVL
      external DCSEVL, IERM1, DINITS, D1MACH, DERM1
c 
c     *****     Local Variables     ************************************
c 
      double precision BI0CS(18), AI0CS(46), AI02CS(69)
      double precision AK0CS(38), AK02CS(33)
      double precision P(6), Q(2), PP(10), QQ(10), F(4), G(3)
      double precision SUMF, SUMG, SUMP, SUMQ, Y, Z
      double precision EXP10, EXPM10, LSQ2PI, LSQPI2
      parameter (EXP10 = (+.2202646579 4806716516 95790 D+5))
C     EXP10 = EXP(10)
      parameter (EXPM10 = (+.4539992976 2484851535 59152 D-4))
C     EXPM10 = EXP(-10)
      parameter (LSQ2PI = (+.9189385332 0467274178 03296 D+0))
C     LSQ2PI = LOG(SQRT 2 PI))
      parameter (LSQPI2 = (+.2257913526 4472743236 30975 D+0))
C     LSQPI2 = LOG(SQRT(PI / 2))
      double precision BOUNDK, XIMAX, XIN, XISML, XKMAX, XKN, XKSML
      integer I, NTI0, NTAI0, NTAI02, NTAK0, NTAK02
      save NTI0, NTAI0, NTAI02, XIMAX, XISML
      save BOUNDK, NTAK0, NTAK02, XKMAX, XKSML
c 
c     *****     Data     ***********************************************
c 
c SERIES FOR BI0        ON THE INTERVAL  0.          TO  9.00000D+00
c                                        WITH WEIGHTED ERROR   9.51D-34
c                                        LOG WEIGHTED ERROR  33.02
c                               SIGNIFICANT FIGURES REQUIRED  33.31
c                                    DECIMAL PLACES REQUIRED  33.65
c 
      data BI0CS(  1) / -.7660547252 8391449510 8189497624 3285 D-1   /
      data BI0CS(  2) / +.1927337953 9938082699 5240875088 1196 D+1   /
      data BI0CS(  3) / +.2282644586 9203013389 3702929233 0415 D+0   /
      data BI0CS(  4) / +.1304891466 7072904280 7933421069 1888 D-1   /
      data BI0CS(  5) / +.4344270900 8164874513 7868268102 6107 D-3   /
      data BI0CS(  6) / +.9422657686 0019346639 2317174411 8766 D-5   /
      data BI0CS(  7) / +.1434006289 5106910799 6209187817 9957 D-6   /
      data BI0CS(  8) / +.1613849069 6617490699 1541971999 4611 D-8   /
      data BI0CS(  9) / +.1396650044 5356696994 9509270814 2522 D-10  /
      data BI0CS( 10) / +.9579451725 5054453446 2752317189 3333 D-13  /
      data BI0CS( 11) / +.5333981859 8625021310 1510774400 0000 D-15  /
      data BI0CS( 12) / +.2458716088 4374707746 9678591999 9999 D-17  /
      data BI0CS( 13) / +.9535680890 2487700269 4434133333 3333 D-20  /
      data BI0CS( 14) / +.3154382039 7214273367 8933333333 3333 D-22  /
      data BI0CS( 15) / +.9004564101 0946374314 6666666666 6666 D-25  /
      data BI0CS( 16) / +.2240647369 1236700160 0000000000 0000 D-27  /
      data BI0CS( 17) / +.4903034603 2428373333 3333333333 3333 D-30  /
      data BI0CS( 18) / +.9508172606 1226666666 6666666666 6666 D-33  /
c 
c SERIES FOR AI0        ON THE INTERVAL  1.25000D-01 TO  3.33333D-01
c                                        WITH WEIGHTED ERROR   2.74D-32
c                                         LOG WEIGHTED ERROR  31.56
c                               SIGNIFICANT FIGURES REQUIRED  30.15
c                                    DECIMAL PLACES REQUIRED  32.39
c 
      data AI0CS(  1) / +.7575994494 0237959427 2987203743 8 D-1      /
      data AI0CS(  2) / +.7591380810 8233455072 9297873320 4 D-2      /
      data AI0CS(  3) / +.4153131338 9237505018 6319749138 2 D-3      /
      data AI0CS(  4) / +.1070076463 4390730735 8242970217 0 D-4      /
      data AI0CS(  5) / -.7901179979 2128946607 5031948573 0 D-5      /
      data AI0CS(  6) / -.7826143501 4387522697 8898980690 9 D-6      /
      data AI0CS(  7) / +.2783849942 9488708063 8118538985 7 D-6      /
      data AI0CS(  8) / +.8252472600 6120271919 6682913319 8 D-8      /
      data AI0CS(  9) / -.1204463945 5201991790 5496089110 3 D-7      /
      data AI0CS( 10) / +.1559648598 5060764436 1228752792 8 D-8      /
      data AI0CS( 11) / +.2292556367 1033165434 7725480285 7 D-9      /
      data AI0CS( 12) / -.1191622884 2790646036 7777423447 8 D-9      /
      data AI0CS( 13) / +.1757854916 0324098302 1833124774 3 D-10     /
      data AI0CS( 14) / +.1128224463 2189005171 4441135682 4 D-11     /
      data AI0CS( 15) / -.1146848625 9272988777 2963387698 2 D-11     /
      data AI0CS( 16) / +.2715592054 8036628726 4365192160 6 D-12     /
      data AI0CS( 17) / -.2415874666 5626878384 4247572028 1 D-13     /
      data AI0CS( 18) / -.6084469888 2551250646 0609963922 4 D-14     /
      data AI0CS( 19) / +.3145705077 1754772937 0836026730 3 D-14     /
      data AI0CS( 20) / -.7172212924 8711877179 6217505917 6 D-15     /
      data AI0CS( 21) / +.7874493403 4541033960 8390960332 7 D-16     /
      data AI0CS( 22) / +.1004802753 0094624023 4524457183 9 D-16     /
      data AI0CS( 23) / -.7566895365 3505348534 2843588881 0 D-17     /
      data AI0CS( 24) / +.2150380106 8761198878 1205128784 5 D-17     /
      data AI0CS( 25) / -.3754858341 8308744291 5158445260 8 D-18     /
      data AI0CS( 26) / +.2354065842 2269925769 0075710532 2 D-19     /
      data AI0CS( 27) / +.1114667612 0479285302 2637335511 0 D-19     /
      data AI0CS( 28) / -.5398891884 3969903786 9677932270 9 D-20     /
      data AI0CS( 29) / +.1439598792 2407526770 4285840452 2 D-20     /
      data AI0CS( 30) / -.2591916360 1110934064 6081840196 2 D-21     /
      data AI0CS( 31) / +.2238133183 9985839074 3409229824 0 D-22     /
      data AI0CS( 32) / +.5250672575 3647711727 7221683199 9 D-23     /
      data AI0CS( 33) / -.3249904138 5332307841 7343228586 6 D-23     /
      data AI0CS( 34) / +.9924214103 2050379278 5728471040 0 D-24     /
      data AI0CS( 35) / -.2164992254 2446695231 4655429973 3 D-24     /
      data AI0CS( 36) / +.3233609471 9435940839 7333299199 9 D-25     /
      data AI0CS( 37) / -.1184620207 3967424898 2473386666 6 D-26     /
      data AI0CS( 38) / -.1281671853 9504986505 4833868799 9 D-26     /
      data AI0CS( 39) / +.5827015182 2793905116 0556885333 3 D-27     /
      data AI0CS( 40) / -.1668222326 0261097193 6450150399 9 D-27     /
      data AI0CS( 41) / +.3625309510 5415699757 0068480000 0 D-28     /
      data AI0CS( 42) / -.5733627999 0557135899 4595839999 9 D-29     /
      data AI0CS( 43) / +.3736796722 0630982296 4258133333 3 D-30     /
      data AI0CS( 44) / +.1602073983 1568519633 6551253333 3 D-30     /
      data AI0CS( 45) / -.8700424864 0572298845 2249599999 9 D-31     /
      data AI0CS( 46) / +.2741320937 9374811456 0341333333 3 D-31     /
c 
c SERIES FOR AI02       ON THE INTERVAL  0.          TO  1.25000D-01
c                                        WITH WEIGHTED ERROR   1.97D-32
c                                         LOG WEIGHTED ERROR  31.71
c                               SIGNIFICANT FIGURES REQUIRED  30.15
c                                    DECIMAL PLACES REQUIRED  32.63
c 
      data AI02CS(  1) / +.5449041101 4108831607 8960962268 0 D-1      /
      data AI02CS(  2) / +.3369116478 2556940898 9785662979 9 D-2      /
      data AI02CS(  3) / +.6889758346 9168239842 6263914301 1 D-4      /
      data AI02CS(  4) / +.2891370520 8347564829 6692402323 2 D-5      /
      data AI02CS(  5) / +.2048918589 4690637418 2760534093 1 D-6      /
      data AI02CS(  6) / +.2266668990 4981780645 9327743136 1 D-7      /
      data AI02CS(  7) / +.3396232025 7083863451 5084396952 3 D-8      /
      data AI02CS(  8) / +.4940602388 2249695891 0482449783 5 D-9      /
      data AI02CS(  9) / +.1188914710 7846438342 4084525196 3 D-10     /
      data AI02CS( 10) / -.3149916527 9632413645 3864862961 9 D-10     /
      data AI02CS( 11) / -.1321581184 0447713118 7540739926 7 D-10     /
      data AI02CS( 12) / -.1794178531 5068061177 7943574026 9 D-11     /
      data AI02CS( 13) / +.7180124451 3836662336 7106429346 9 D-12     /
      data AI02CS( 14) / +.3852778382 7421427011 4089801777 6 D-12     /
      data AI02CS( 15) / +.1540086217 5214098269 1325823339 7 D-13     /
      data AI02CS( 16) / -.4150569347 2872220866 2689972015 6 D-13     /
      data AI02CS( 17) / -.9554846698 8283076487 0214494312 5 D-14     /
      data AI02CS( 18) / +.3811680669 3526224207 4605535511 8 D-14     /
      data AI02CS( 19) / +.1772560133 0565263836 0493266675 8 D-14     /
      data AI02CS( 20) / -.3425485619 6772191346 1924790328 2 D-15     /
      data AI02CS( 21) / -.2827623980 5165834849 4205593759 4 D-15     /
      data AI02CS( 22) / +.3461222867 6974610930 9706250813 4 D-16     /
      data AI02CS( 23) / +.4465621420 2967599990 1042054284 3 D-16     /
      data AI02CS( 24) / -.4830504485 9441820712 5525403795 4 D-17     /
      data AI02CS( 25) / -.7233180487 8747539545 6227240924 5 D-17     /
      data AI02CS( 26) / +.9921475412 1736985988 8046093981 0 D-18     /
      data AI02CS( 27) / +.1193650890 8459820855 0439949924 2 D-17     /
      data AI02CS( 28) / -.2488709837 1508072357 2054491660 2 D-18     /
      data AI02CS( 29) / -.1938426454 1609059289 8469781132 6 D-18     /
      data AI02CS( 30) / +.6444656697 3734438687 8301949394 9 D-19     /
      data AI02CS( 31) / +.2886051596 2892243264 8171383073 4 D-19     /
      data AI02CS( 32) / -.1601954907 1749718070 6167156200 7 D-19     /
      data AI02CS( 33) / -.3270815010 5923147208 9193567485 9 D-20     /
      data AI02CS( 34) / +.3686932283 8264091811 4600723939 3 D-20     /
      data AI02CS( 35) / +.1268297648 0309501530 1359529710 9 D-22     /
      data AI02CS( 36) / -.7549825019 3772739076 9636664410 1 D-21     /
      data AI02CS( 37) / +.1502133571 3778353496 3712789053 4 D-21     /
      data AI02CS( 38) / +.1265195883 5096485349 3208799248 3 D-21     /
      data AI02CS( 39) / -.6100998370 0836807086 2940891600 2 D-22     /
      data AI02CS( 40) / -.1268809629 2601282643 6872095924 2 D-22     /
      data AI02CS( 41) / +.1661016099 8907414578 4038487490 5 D-22     /
      data AI02CS( 42) / -.1585194335 7658855793 7970504881 4 D-23     /
      data AI02CS( 43) / -.3302645405 9682178009 5381766755 6 D-23     /
      data AI02CS( 44) / +.1313580902 8392397817 4039623117 4 D-23     /
      data AI02CS( 45) / +.3689040246 6711567933 1425637280 4 D-24     /
      data AI02CS( 46) / -.4210141910 4616891492 1978247249 9 D-24     /
      data AI02CS( 47) / +.4791954591 0828657806 3171401373 0 D-25     /
      data AI02CS( 48) / +.8459470390 2218217952 9971707412 4 D-25     /
      data AI02CS( 49) / -.4039800940 8728324931 4607937181 0 D-25     /
      data AI02CS( 50) / -.6434714653 6504313473 0100850469 5 D-26     /
      data AI02CS( 51) / +.1225743398 8756659903 4464736990 5 D-25     /
      data AI02CS( 52) / -.2934391316 0257089231 9879821175 4 D-26     /
      data AI02CS( 53) / -.1961311309 1949829262 0371205728 9 D-26     /
      data AI02CS( 54) / +.1503520374 8221934241 6229900309 8 D-26     /
      data AI02CS( 55) / -.9588720515 7448265520 3386388206 9 D-28     /
      data AI02CS( 56) / -.3483339380 8170454863 9441108511 4 D-27     /
      data AI02CS( 57) / +.1690903610 2630436730 6244960725 6 D-27     /
      data AI02CS( 58) / +.1982866538 7356030438 9400115718 8 D-28     /
      data AI02CS( 59) / -.5317498081 4918162145 7583002528 4 D-28     /
      data AI02CS( 60) / +.1803306629 8883929462 3501450390 1 D-28     /
      data AI02CS( 61) / +.6213093341 4548931758 8405311242 2 D-29     /
      data AI02CS( 62) / -.7692189292 7721618632 0072806673 0 D-29     /
      data AI02CS( 63) / +.1858252826 1117025426 2556016596 3 D-29     /
      data AI02CS( 64) / +.1237585142 2813957248 9927154554 1 D-29     /
      data AI02CS( 65) / -.1102259120 4092238032 1779478779 2 D-29     /
      data AI02CS( 66) / +.1886287118 0397044900 7787447943 1 D-30     /
      data AI02CS( 67) / +.2160196872 2436589131 4903141406 0 D-30     /
      data AI02CS( 68) / -.1605454124 9197432005 8446594965 5 D-30     /
      data AI02CS( 69) / +.1965352984 5942906039 3884807331 8 D-31     /
c 
C--------------------------------------------------------------------
C 
C     Coefficients for K0 from Cody for XSMALL .LE.  ARG  .LE. 1.0
C 
C--------------------------------------------------------------------
      DATA   P/ 5.8599221412826100000D-04, 1.3166052564989571850D-01,
     1          1.1999463724910714109D+01, 4.6850901201934832188D+02,
     2          5.9169059852270512312D+03, 2.4708152720399552679D+03/
      DATA   Q/-2.4994418972832303646D+02, 2.1312714303849120380D+04/
      DATA   F/-1.6414452837299064100D+00,-2.9601657892958843866D+02,
     1         -1.7733784684952985886D+04,-4.0320340761145482298D+05/
      DATA   G/-2.5064972445877992730D+02, 2.9865713163054025489D+04,
     1         -1.6128136304458193998D+06/
C--------------------------------------------------------------------
C 
C     Coefficients for K0 from Cody for 1.0 .LT. ARG .LT. BOUNDK
C 
C--------------------------------------------------------------------
      DATA  PP/ 1.1394980557384778174D+02, 3.6832589957340267940D+03,
     1          3.1075408980684392399D+04, 1.0577068948034021957D+05,
     2          1.7398867902565686251D+05, 1.5097646353289914539D+05,
     3          7.1557062783764037541D+04, 1.8321525870183537725D+04,
     4          2.3444738764199315021D+03, 1.1600249425076035558D+02/
      DATA  QQ/ 2.0013443064949242491D+02, 4.4329628889746408858D+03,
     1          3.1474655750295278825D+04, 9.7418829762268075784D+04,
     2          1.5144644673520157801D+05, 1.2689839587977598727D+05,
     3          5.8824616785857027752D+04, 1.4847228371802360957D+04,
     4          1.8821890840982713696D+03, 9.2556599177304839811D+01/
C--------------------------------------------------------------------
C 
C SERIES FOR AK0        ON THE INTERVAL  1.25000D-01 TO  5.00000D-01
C                                        WITH WEIGHTED ERROR   2.85D-32
C                                         LOG WEIGHTED ERROR  31.54
C                               SIGNIFICANT FIGURES REQUIRED  30.19
C                                    DECIMAL PLACES REQUIRED  32.33
C 
      data AK0CS(  1) / -.7643947903 3279414240 8297827008 8 D-1      /
      data AK0CS(  2) / -.2235652605 6998190520 2309555079 1 D-1      /
      data AK0CS(  3) / +.7734181154 6938582353 0061817404 7 D-3      /
      data AK0CS(  4) / -.4281006688 8860994644 5214643541 6 D-4      /
      data AK0CS(  5) / +.3081700173 8629747436 5001482666 0 D-5      /
      data AK0CS(  6) / -.2639367222 0096649740 6744889272 3 D-6      /
      data AK0CS(  7) / +.2563713036 4034692062 9408826574 2 D-7      /
      data AK0CS(  8) / -.2742705549 9002012638 5721191524 4 D-8      /
      data AK0CS(  9) / +.3169429658 0974995920 8083287340 3 D-9      /
      data AK0CS( 10) / -.3902353286 9621841416 0106571796 2 D-10     /
      data AK0CS( 11) / +.5068040698 1885754020 5009212728 6 D-11     /
      data AK0CS( 12) / -.6889574741 0078706795 4171355798 4 D-12     /
      data AK0CS( 13) / +.9744978497 8259176913 8820133683 1 D-13     /
      data AK0CS( 14) / -.1427332841 8845485053 8985534012 2 D-13     /
      data AK0CS( 15) / +.2156412571 0214630395 5806297652 7 D-14     /
      data AK0CS( 16) / -.3349654255 1495627721 8878205853 0 D-15     /
      data AK0CS( 17) / +.5335260216 9529116921 4528039260 1 D-16     /
      data AK0CS( 18) / -.8693669980 8907538076 3962237883 7 D-17     /
      data AK0CS( 19) / +.1446404347 8622122278 8776344234 6 D-17     /
      data AK0CS( 20) / -.2452889825 5001296824 0467875157 3 D-18     /
      data AK0CS( 21) / +.4233754526 2321715728 2170634240 0 D-19     /
      data AK0CS( 22) / -.7427946526 4544641956 9534129493 3 D-20     /
      data AK0CS( 23) / +.1323150529 3926668662 7796746240 0 D-20     /
      data AK0CS( 24) / -.2390587164 7396494513 3598146559 9 D-21     /
      data AK0CS( 25) / +.4376827585 9232261401 6571255466 6 D-22     /
      data AK0CS( 26) / -.8113700607 3451180593 3901141333 3 D-23     /
      data AK0CS( 27) / +.1521819913 8321729583 1037815466 6 D-23     /
      data AK0CS( 28) / -.2886041941 4833977702 3595861333 3 D-24     /
      data AK0CS( 29) / +.5530620667 0547179799 9261013333 3 D-25     /
      data AK0CS( 30) / -.1070377329 2498987285 9163306666 6 D-25     /
      data AK0CS( 31) / +.2091086893 1423843002 9632853333 3 D-26     /
      data AK0CS( 32) / -.4121713723 6462038274 1026133333 3 D-27     /
      data AK0CS( 33) / +.8193483971 1213076401 3568000000 0 D-28     /
      data AK0CS( 34) / -.1642000275 4592977267 8075733333 3 D-28     /
      data AK0CS( 35) / +.3316143281 4802271958 9034666666 6 D-29     /
      data AK0CS( 36) / -.6746863644 1452959410 8586666666 6 D-30     /
      data AK0CS( 37) / +.1382429146 3184246776 3541333333 3 D-30     /
      data AK0CS( 38) / -.2851874167 3598325708 1173333333 3 D-31     /
C 
C SERIES FOR AK02       ON THE INTERVAL  0.          TO  1.25000D-01
C                                        WITH WEIGHTED ERROR   2.30D-32
C                                         LOG WEIGHTED ERROR  31.64
C                               SIGNIFICANT FIGURES REQUIRED  29.68
C                                    DECIMAL PLACES REQUIRED  32.40
C 
      data AK02CS(  1) / -.1201869826 3075922398 3934621245 2 D-1      /
      data AK02CS(  2) / -.9174852691 0256953106 5256107571 3 D-2      /
      data AK02CS(  3) / +.1444550931 7750058210 4884387805 7 D-3      /
      data AK02CS(  4) / -.4013614175 4357097286 7102107787 9 D-5      /
      data AK02CS(  5) / +.1567831810 8523106725 9034899033 3 D-6      /
      data AK02CS(  6) / -.7770110438 5217377103 1579975446 0 D-8      /
      data AK02CS(  7) / +.4611182576 1797178825 3313052958 6 D-9      /
      data AK02CS(  8) / -.3158592997 8605657705 2666580330 9 D-10     /
      data AK02CS(  9) / +.2435018039 3650411278 3588781432 9 D-11     /
      data AK02CS( 10) / -.2074331387 3983478977 0985337350 6 D-12     /
      data AK02CS( 11) / +.1925787280 5899170847 4273650469 3 D-13     /
      data AK02CS( 12) / -.1927554805 8389561036 0034718221 8 D-14     /
      data AK02CS( 13) / +.2062198029 1978182782 8523786964 4 D-15     /
      data AK02CS( 14) / -.2341685117 5792424026 0364019507 1 D-16     /
      data AK02CS( 15) / +.2805902810 6430422468 1517882845 8 D-17     /
      data AK02CS( 16) / -.3530507631 1618079458 1548246357 3 D-18     /
      data AK02CS( 17) / +.4645295422 9351082674 2421633706 6 D-19     /
      data AK02CS( 18) / -.6368625941 3442664739 2205346133 3 D-20     /
      data AK02CS( 19) / +.9069521310 9865155676 2234880000 0 D-21     /
      data AK02CS( 20) / -.1337974785 4236907398 4500531199 9 D-21     /
      data AK02CS( 21) / +.2039836021 8599523155 2208896000 0 D-22     /
      data AK02CS( 22) / -.3207027481 3678405000 6086997333 3 D-23     /
      data AK02CS( 23) / +.5189744413 6623099636 2635946666 6 D-24     /
      data AK02CS( 24) / -.8629501497 5405721929 6460799999 9 D-25     /
      data AK02CS( 25) / +.1472161183 1025598552 0803840000 0 D-25     /
      data AK02CS( 26) / -.2573069023 8670112838 1235199999 9 D-26     /
      data AK02CS( 27) / +.4601774086 6435165873 7664000000 0 D-27     /
      data AK02CS( 28) / -.8411555324 2010937371 3066666666 6 D-28     /
      data AK02CS( 29) / +.1569806306 6353689393 0154666666 6 D-28     /
      data AK02CS( 30) / -.2988226453 0057577889 7919999999 9 D-29     /
      data AK02CS( 31) / +.5796831375 2168365206 1866666666 6 D-30     /
      data AK02CS( 32) / -.1145035994 3476813321 5573333333 3 D-30     /
      data AK02CS( 33) / +.2301266594 2496828020 0533333333 3 D-31     /
c 
      data NTI0 /0/
c 
c     *****     Statement Functions     ********************************
c 
      xin(z) = ximax + 0.5*log(z/(1.0+1.0/(8.0*z))**2)
      xkn(z) = xkmax - 0.5*log(z/(1.0-1.0/(8.0*z))**2)
c 
c     *****     Executable Statements     ******************************
c 
      if (nti0 .le. 0) then
         z = 0.1*D1MACH(3)
         boundk = 1.757 - 6.22d-3 * log(z)
         call DINITS (bi0cs, 18, z,  nti0  )
         call DINITS (ai0cs, 46, z,  ntai0 )
         call DINITS (ai02cs, 69, z, ntai02)
         call DINITS (ak0cs, 38, z,  ntak0 )
         call DINITS (ak02cs, 33, z, ntak02)
         xisml = sqrt (80.0D0*z)
         ximax = log(D1MACH(2)) + lsq2pi
         ximax = xin(xin(ximax))
         xksml = sqrt (10.0*z*p(6)/p(5))
c        xksml = sqrt (10.0*z*min(p(6)/p(5),q(2)/q(1)))
         xkmax = lsqpi2 - log(D1MACH(1))
         xkmax = xkn(xkn(xkn(xkmax)))
      end if
c 
      if (want.eq.0 .or. abs(want).gt.3) then
         call ierm1('DBI0K0',-1,0,'WANT = 0 OR ABS(WANT) > 3','WANT',
     1      want,'.')
         status=-1
         return
      end if
      status = 0
c 
c     Compute I0 if requested.
c 
      if (abs(want) .ne. 2) then
         y = abs(x)
         if (y.le.3.0) then
            if (y.le.xisml) then
              BI0 = 1.0D0
            else
              BI0 = 2.75D0 + DCSEVL(y*y/4.5D0-1.0D0, bi0cs, nti0)
            end if
            if (want.lt.0) BI0 = exp(-y) * BI0
         else
            if (y .le. 8.0D0) then
              BI0 = DCSEVL ((48.0D0/y-11.0D0)/5.0D0, ai0cs, ntai0)
            else
              BI0 = DCSEVL (16.0D0/y-1.0D0, ai02cs, ntai02)
            end if
           BI0 = (0.375D0 + BI0) / sqrt(y)
            if (want .gt. 0) then
               if (y .gt. ximax) then
                  call DERM1('DBI0K0',-2,0,'ABS(X) SO BIG I0 OVERFLOWS',
     1               'X',x,'.')
                  status = -2
                  BI0 = D1MACH(2)
c                 y > ximax => y > xkmax
                  BK0 = 0.0
                  if (x .gt. 0.0) return
               else
                  BI0 = (exp(y-10.0) * BI0) * exp10
               end if
            end if
         end if
      end if
c 
c     Compute K0 if requested.
c 
      if (abs(want) .gt. 1) then
         if (x .le. 0.0D0) then
            call DERM1('DBI0K0',-3,0,'X IS ZERO OR NEGATIVE','X',x,'.')
            status = -3
            BK0 = D1MACH(2)
         else if (x .le. 1.0) then
c                                         0.0 < x <= 1.0
            BK0 = log(x)
            if (x .lt. xksml) then
c                                         0.0 <= x < xksml
               BK0 = p(6)/q(2) - BK0
            else
c                                         xksml <= x <= 1.0
               y = x*x
               sump = ((((p(1)*y+p(2))*y+p(3))*y+p(4))*y+p(5))*y+p(6)
               sumq = (y + q(1))*y + q(2)
               sumf = ((f(1)*y + f(2))*y + f(3))*y + f(4)
               sumg = ((y + g(1))*y + g(2))*y + g(3)
               BK0 = sump/sumq - y * sumf * BK0 / sumg - BK0
            end if
            if (want .lt. 0) BK0 = exp(x) * BK0
         else if (x .le. boundk) then
c                                         1.0 < x <= boundk
            y = 1.0 / x
            sump = pp(1)
            do 120 i = 2, 10
               sump = sump*y + pp(i)
120         continue
            sumq = y
            do 140 i = 1, 9
               sumq = (sumq + qq(i))*y
140         continue
            sumq = sumq + qq(10)
            BK0 = sump / (sumq * sqrt(x))
            if (want .gt. 0) BK0 = exp(-x) * BK0
         else
c                                         boundk < x
            y = 16.0D0 / x
            if (x .le. 8.0D0) then
               BK0 = DCSEVL ((y-5.0D0)/3.0D0, ak0cs, ntak0)
            else
               BK0 = DCSEVL (y-1.0D0, ak02cs, ntak02)
            end if
            BK0 = (1.25D0 + BK0) / sqrt(x)
            if (want .gt. 0) then
               if (x .gt. xkmax) then
                  call DERM1('DBI0K0',1,-2,'X SO BIG K0 UNDERFLOWS','X',
     1               x,'.')
                  BK0 = 0.0
                  status = 1
               else
                  BK0 = (exp(10.0-x) * BK0) * expm10
               end if
            end if
         end if
      end if
C 
      return
c 
      end

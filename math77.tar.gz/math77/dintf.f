      SUBROUTINE DINTF (ANSWER, WORK, IOPT)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1990-01-23 CLL Added type stmts. Avoids msgs from some code checkers
C>> 1988-06-07 DINTF  Snyder  Replaced " by '.
C>> 1987-12-09 DINTF  Snyder  Initial code.
C
C     Dummy DINTF subprogram that prints
C     'You have neglected either to write the DINTF subprogram'
C     'or to select reverse communication before invoking DINT.'
C     and then STOPs.
C
      double precision ANSWER, WORK(*)
      integer IOPT(*)
      PRINT *,'You have neglected either to write the DINTF subprogram'
      PRINT *,'or to select reverse communication before invoking DINT*'
      STOP
      END

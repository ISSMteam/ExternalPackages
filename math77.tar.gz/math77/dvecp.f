      SUBROUTINE      DVECP  (V, N, TEXT)
c     DVECP..  Print a vector.
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1992-04-22 CLL
C>> 1985-09-20 CLL
C>> 1983-07-05 DVECP  K. Stewart   recoded for math 77 library
C>> 1981-07-23 DVECP  Kris Stewart RECODED FOR PORTABLE ENVIRONMENT
C>> 1969-00-00 C. L. Lawson, JPL, Original code: MOUT/VOUT
c     ------------------------------------------------------------------
c                  Subroutine arguments
C
C  V(I),I=1,N    Vector to be output.
C  N             Number of vector components.
c  TEXT   Character string to be printed as a title.
c         First character in TEXT controls line spacing before title on
c         an impact printer.  For output to be viewed on a screen it is
c         safest to always use ' '.
c         ' ' = normal single space.
c         '0' = double space.
c         '1' = page advance.
c         '+' = suppress space, i.e., overprint.
c     ------------------------------------------------------------------
C     I VERSION USES IVECP, '/8/', '8I15'
C--   D VERSION USES DVECP, '/6/', '1P,6G20.12'
C--   S VERSION USES SVECP, '/8/', '1P,8G15.7'
C     ------------------------------------------------------------------
      INTEGER  J, J1, J2, LAST, MAXCOL, N, NBLOCK, NCOL
      DOUBLE PRECISION  V(N)
      CHARACTER*(*)     TEXT
      DATA MAXCOL/6/
C     ------------------------------------------------------------------
      WRITE(*,'(A)') TEXT
      NBLOCK=N /MAXCOL
      LAST=N -NBLOCK*MAXCOL
      NCOL=MAXCOL
      J1=1
C
C                            MAIN LOOP STARTS HERE
C
   20 IF(NBLOCK .GT.0) GO TO 30
      IF(LAST .LE. 0) RETURN
      NCOL=LAST
      LAST=0
C
   30 J2=J1+NCOL-1
      WRITE(*,'(1X,I3,a,I3,1X,1P,6G20.12)') J1,' TO ',J2,(V(J),J=J1,J2)
      J1=J1+MAXCOL
      NBLOCK=NBLOCK-1
      GO TO 20
      END

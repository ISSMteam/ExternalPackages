      SUBROUTINE DINT1 (A,B,ANSWER,WORK,IOPT)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C     SUBROUTINE $L1$INT1 (A,B,ANSWER,WORK,IOPT)
C>> 1991-09-20 DINT1  Krogh converted '(1)' dimensioning to '(*)'.
C>> 1987-09-25 DINT1  Lawson  Initial code.
C
C     *****     WARNING     ********************************************
C                                                                       00001100
C     THIS IS A PROTOTYPE PROGRAM.
C
C     ******************************************************************
C
C     THIS SUBROUTINE ATTEMPTS TO CALCULATE THE INTEGRAL OF A FUNCTION
C     OVER THE INTERVAL A TO B TO WITHIN A TOLERANCE LEVEL SPECIFIED
C     BY THE USER.  THE FUNCTION IS PROVIDED BY THE USER VIA A
C     SUBPROGRAM REFERENCED BY CALL $L1$INTF (F,X,IFLAG), OR BY REVERSE
C     COMMUNICATION.  IN THE CASE OF ONE-DIMENSIONAL QUADRATURE, IFLAG
C     IS ALWAYS ZERO.  ALL ABSCISSAE ARE WITHIN THE INTERVAL OF         00002100
C     INTEGRATION.
C
C     THE RESULT IS OBTAINED USING QUADRATURE FORMULAE DUE TO
C     T. N. L. PATTERSON, MATHEMATICS OF COMPUTATION, VOLUME 22,
C     PAGES 847-856, 1968.
C
C     *****    WARNING   ***********************************************
C
C     THE RELIABILITY AND EFFICIENCY OF THIS PROGRAM ARE STRONGLY
C     INFLUENCED BY DISCONTINUITIES IN THE FUNCTION OR IT'S             00003100
C     DERIVATIVES, INTEGRABLE SINGULARITIES ON THE REAL AXIS,
C     NON-INTEGRABLE SINGULARITIES NEAR THE REGION, AND POLES
C     NOT ON THE REAL AXIS.  THE EFFICIENCY AND RELIABILITY
C     OF INTEGRATING SUCH FUNCTIONS MAY BE GREATLY IMPROVED BY MANUALLY
C     SUBDIVIDING THE INTERVAL OF INTEGRATION AT THE DISCONTINUITY,
C     SINGULARITY OR REAL PART OF THE POLE, AND SUMMING THE ANSWERS.
C     A CHANGE OF VARIABLE TO ELIMINATE OR REDUCE THE STRENGTH OF THE
C     SINGULARITY WILL SIGNIFICANTLY IMPROVE PERFORMANCE.
C
C     *****    SPECIALIZER VARIABLES     *******************************00004100
C
C     SPECIALIZER VARIABLES ARE ALL DEFINED IN SINTOP (OR DINTOP)
C
C     *****    FORMAL ARGUMENTS    *************************************
C
C A       LOWER LIMIT OF INTERVAL OF INTEGRATION.
C     $.TYPE.$ A
      DOUBLE PRECISION A
C B       UPPER LIMIT OF INTERVAL OF INTEGRATION.
C     $.TYPE.$ B                                                        00005100
      DOUBLE PRECISION B
C ANSWER  IS THE ESTIMATE OF THE INTEGRAL.  WHEN REVERSE COMMUNICATION
C         IS SPECIFIED IT IS USED TO PASS FUNCTION VALUES FROM
C         THE USER PROGRAM TO $L1$INTA.
C     $.TYPE.$ ANSWER
      DOUBLE PRECISION ANSWER
C WORK    IS A WORKING STORAGE VECTOR USED BY OPTIONS (SEE IOPT).
C         WHEN THE INTEGRATION IS COMPLETE, WORK(1) CONTAINS THE
C         ESTIMATED ABSOLUTE ERROR.  WHEN REVERSE COMMUNICATION
C         IS SPECIFIED, WORK(1) IS USED TO PASS ABSCISSAE FROM          00006100
C         $L1$INTA TO THE USER PROGRAM.
C     $.TYPE.$ WORK(*)
      DOUBLE PRECISION WORK(*)
C IOPT    IS A VECTOR OF INTEGERS USED TO RETURN THE STATUS AND TO
C         SPECIFY OPTIONS.
      INTEGER IOPT(*)
C         IOPT(1) IS USED TO RETURN A STATUS INDICATOR TO THE USER.
C         VALUES OF THE STATUS INDICATOR ARE
C         -1 - NORMAL TERMINATION, EITHER THE ABSOLUTE OR THE RELATIVE
C              ERROR CRITERIA ARE SATISFIED.                            00007100
C         -2 - NORMAL TERMINATION, NEITHER THE ABSOLUTE NOR THE
C              RELATIVE ERROR CRITERIA ARE SATISFIED, BUT THE RELATIVE
C              TO THE OBTAINABLE ERROR CRITERION IS SATISFIED.
C         -3 - NORMAL TERMINATION, BUT NONE OF THE ERROR CRITERIA ARE
C              SATISFIED.
C         +4 - BAD IOPT VALUE.
C         +5 - TOO MANY FUNCTION VALUES NEEDED.
C         +6 - APPARENT NON-INTEGRABLE SINGULARITY NEAR ANSWER.
C         ENTRIES IN IOPT STARTING AT IOPT(2) ARE DESCRIBED BELOW.
C         IOPT(I)    ENTRY IN IOPT(I) MEANS                             00008100
C           0        NO MORE OPTIONS, BEGIN INTEGRATION.
C           1        IOPT(I+1) CONTAINS THE UNIT NUMBER FOR OUTPUT.
C           2        IOPT(I+1) IS DIAGNOSTIC PRINT LEVEL
C                    0 - NO PRINTING
C                    1 - MINIMUM PRINTING - ERROR MESSAGES (DEFAULT)
C                    2 - PANEL BOUNDARIES AND ANSWERS
C                    3 - ERROR ESTIMATES FOR EACH QUADRATURE FORMULA
C                    4 - DETAILED OUTPUT (DIFFERENCE LINES, ETC).
C           3        WORK(IOPT(I+1)) CONTAINS THE ABSOLUTE TOLERANCE,
C                    WORK(IOPT(I+1)+1) CONTAINS TOLERANCE RELATIVE TO   00009100
C                    THE LOCALLY OBTAINABLE PRECISION, AND
C                    WORK(IOPT(I+1)+2) CONTAINS TOLERANCE RELATIVE TO
C                    THE VALUE OF THE INTEGRAL.  THE TOLERANCE RELATIVE
C                    TO THE LOCALLY OBTAINABLE PRECISION IS SPECIFIED AS
C                    THE FRACTION OF LOCALLY OBTAINABLE DIGITS THAT ARE
C                    PERMITTED TO BE WRONG, AND IS INTERNALLY BOUNDED
C                    BETWEEN 0.0 AND 1.0.  IF ANY OF THE ERROR CONTROL
C                    CRITERIA ARE SATISFIED, THE ANSWER IS ACCEPTED.  IF
C                    THIS OPTION IS NOT USED, THE ABSOLUTE AND RELATIVE
C                    TOLERANCES ARE SET TO ZERO, AND THE TOLERANCE      00010100
C                    RELATIVE TO THE LOCALLY OBTAINABLE PRECISION IS SET
C                    TO 0.25.
C           4        WORK(IOPT(I+1)) CONTAINS ABSOLUTE ERROR COMMITTED
C                    COMPUTING F.  WORK(IOPT(I+1)) MAY BE CHANGED DURING
C                    THE INTEGRATION.
C           5        WORK(IOPT(I+1)) CONTAINS RELATIVE ERROR EXPECTED TO
C                    BE COMMITTED COMPUTING F.  CHANGES TO THIS VALUE
C                    DURING INTEGRATION WILL NOT BE DETECTED.
C           6        USE REVERSE COMMUNICATION -
C                    CALL $L1$INT (A,B,ANSWER,WORK,IOPT)                00011100
C                  1 CALL $L1$INTA (ANSWER,WORK,IFLAG)
C                    IF (IFLAG.NE.0) GO TO 2
C                    ANSWER=F(WORK(1))
C                    GO TO 1
C                  2 CONTINUE
C                    IFLAG AT THIS POINT CONTAINS THE SAME VALUE AS
C                    THE STATUS FLAG WOULD (IF SELECTED) FOR THE
C                    FORWARD COMMUNICATION METHOD.
C           7        SET MINIMUM INDEX OF QUADRATURE FORMULA TO USE
C                    BEFORE SUBDIVISION TO IOPT(I+1).                   00012100
C           8        NO EFFECT.  MAY BE USED TO PASS INFORMATION INTO
C                    SINTF.  INCREMENT I BY 2.
C           9        IOPT(I+1) IS THE MAXIMUM NUMBER OF FUNCTION VALUES
C                    TO USE TO INTEGRATE THE ENTIRE PROBLEM.  IF
C                    IOPT(I+1) .LE. 0, THE NUMBER OF FUNCTION VALUES
C                    IS NOT CONTROLLED.
C          10        IOPT(I+1) IS USED TO RETURN THE NUMBER OF FUNCTION
C                    VALUES USED TO INTEGRATE THE ENTIRE PROBLEM.
C          11        WORK(IABS(IOPT(I+1))) IS THE LOCATION OF A
C                    SINGULARITY OR DISCONTINUITY.  IF THE LOCATION IS  00013100
C                    INSIDE THE INTERVAL, THE INTERVAL WILL BE
C                    IMMEDIATELY SUBDIVIDED.  IF IOPT(I+1).GT.0, A
C                    T**2 SUBSTITUTION BASED AT WORK(...) WILL BE USED.
C                    IF IOPT(I+1) .LT. 0 A T**4 SUBSTITUTION WILL BE
C                    USED.  IF IOPT(I+1) .EQ. 0, NO SUBSTITUTION WILL BE
C                    USED.
C          12        WORK(IOPT(I+1)) CONTAINS THE ABSOLUTE ERROR IN THE
C                    LOWER LIMIT OF THE CURRENT DIMENSION.  THE ERROR IN
C                    THE UPPER LIMIT IS IN WORK(IOPT(I+1)+1).
C          13        IS USED ONLY FOR MULTIDIMENSIONAL PROBLEMS.        00014100
C
C     ALL OPTIONS ARE SET TO THEIR NOMINAL VALUES BEFORE THE OPTION
C     VECTOR IS PROCESSED.
C
C     *****    EXTERNAL REFERENCES     *********************************
C
C SINTA   IN SINGLE PRECISION
C DINTA   IN DOUBLE PRECISION
C         TO PERFORM THE INTEGRATION.
C SINTOP  IN SINGLE PRECISION                                           00015100
C DINTOP  IN DOUBLE PRECISION
C         TO SET OPTIONS.
C
C     *****    COMMON STORAGE     **************************************
C
C     COMMON /$L1$INTNC/ CONTAINS VARIABLES NOT SEPARATELY SAVED FOR
C     EACH DIMENSION OF A MULTIPLE QUADRATURE.  COMMON /$L1$INTC/
C     CONTAINS VARIABLES THAT MUST BE SAVED FOR EACH DIMENSION OF THE
C     QUADRATURE.  THE VARIABLES IN EACH COMMON BLOCK ARE STORED IN THE
C     ORDER - ALWAYS DOUBLE, DOUBLE IF DOUBLE PRECISION PROGRAM, DOUBLE 00015700
C     IF DOUBLE PRECISION PROGRAM AND EXPONENT RANGE OF DOUBLE AND
C     SINGLE VERY DIFFERENT, SINGLE, INTEGER, LOGICAL.  A PAD OF LOGICAL
C     VARIABLES IS INCLUDED AT THE END OF /$L1$INTC/.  THE DIMENSION OF
C     THE PAD MAY NEED TO BE VARIED SO THAT NO VARIABLES BEYOND THE END
C     OF THE COMMON BLOCK ARE ALTERED.
C
C     DECLARATIONS OF COMMON /$L1$INTNC/ VARIABLES.
C
C     $.TYPE.$ AINIT, BINIT, FNCVAL, S, TP
      double precision AINIT, BINIT, FNCVAL, S, TP                      00015700
C     $DSTYP$  FER, FER1, RELOBT, TPS, XJ, XJP
      double precision FER, FER1, RELOBT, TPS, XJ, XJP
      INTEGER     FEA,       FEA1,      INC,       INC2,      IPRINT,   
     * ISTOP(2,2),JPRINT,    KDIM,      KK,        KMAXF,     NDIM,     
     * NFINDX,    NFMAX,     NFMAXM,    OUT,       RELTOL,    REVERM,   
     * REVERS,    WHEREM
      LOGICAL NEEDH
C
C     DECLARATIONS OF COMMON /$L1$INTC/ VARIABLES.
C
C     4 DOUBLE PRECISION VARIABLES
      DOUBLE PRECISION ACUM, PACUM, RESULT(2)
C     139 $.TYPE.$ VARIABLES                                            00015700
C     $.TYPE.$
      DOUBLE PRECISION                                                  
     * AACUM,     ABSCIS,    DELMIN,    DELTA,     DIFF,      DISCX(2), 
     * END(2),    ERRINA,    ERRINB,    FAT(2),    FSAVE,               
     * FUNCT(24), F1,        F2,        LOCAL(4),  PAACUM,    PF1,      
     * PF2,       PHISUM,    PHTSUM,    PX,        SPACE(6),            
     * STEP(2),   START(2),  SUM,       T,         TA,        TASAVE,   
     * TB,        TEND,      WORRY(2),  X,         X1,                  
     * X2,        XT(17),    FT(17),    PHI(34)
c Note XT, FT, and PHI above are last, because they must be in adjacent
c locations in DINTO.
C     30 $DSTYP$ VARIABLES
C     $DSTYP$
      DOUBLE PRECISION                                                  
     * ABSDIF,    COUNT,     EDUE2A,    EDUE2B,    EP,        EPNOIZ,   
     * EPS,       EPSMAX,    EPSMIN,    EPSO,      EPSR,      EPSS,     
     * ERR,       ERRAT(2),  ERRC,      ERRF,      ERRI,      ERRT(2),  
     * ESOLD,     EXTRA,     PEPSMN,    RE,        RELEPS,    REP,      
     * REPROD,    RNDC,      TLEN,      XJUMP
C     29 INTEGER VARIABLES
      INTEGER     DISCF,     DISCHK,    ENDPTS,    I,         INEW,     
     * IOLD,      IP,        IXKDIM,    J,         J1,        J1OLD,    
     * J2,        J2OLD,     K,         KAIMT,     KMAX,      KMIN,     
     * L,         LENDT,     NFEVAL,    NFJUMP,    NSUB,      NSUBSV,   
     * NXKDIM,    PART,      SEARCH,    TALOC,     WHERE,     WHERE2
C     11 TO 18 LOGICALS (7 ARE PADDING).                                00015700
      LOGICAL     DID1,      FAIL,      FATS(2),   FSAVED,    HAVDIF,   
     * IEND,      INIT,      ROUNDF,    XCDOBT(2), PAD(7)
C
C     THE COMMON BLOCKS.
C
C     COMMON /$L1$INTNC/
      COMMON /DINTNC/                                                   
     * AINIT,  BINIT,  FNCVAL, S,      TP,     FER,    FER1,   RELOBT,  
     * TPS,    XJ,     XJP,    FEA,    FEA1,   KDIM,    INC,    INC2,   
     * ISTOP,  JPRINT, IPRINT, KK,     KMAXF,  NDIM,   NFINDX, NFMAX,   
     * NFMAXM, OUT,    RELTOL, REVERM, REVERS, WHEREM, NEEDH
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * ACUM,   PACUM,  RESULT
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    00015700
     * AACUM,  LOCAL,  ABSCIS, TA,     DELTA,  DELMIN, DIFF,   DISCX,   
     * END,    ERRINA, ERRINB, FAT,    FSAVE,  FUNCT,  F2,              
     * PAACUM, PF1,    PF2,    PHISUM, PHTSUM, PX,     SPACE,           
     * STEP,   START,  SUM,    T,      TASAVE, TB,     TEND,            
     * WORRY,  X1,     X2,     X,      F1,     COUNT,                   
     * XT, FT, PHI
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * ABSDIF, EDUE2A, EDUE2B, EP,     EPNOIZ, EPSMAX,                  
     * EPSO,   EPSR,   EPSS,   ERRAT,  ERRC,   ERRF,                    
     * ERRT,   ESOLD,  EXTRA,  PEPSMN, RELEPS, REP,                     
     * RNDC,   TLEN,   XJUMP,                                           
     * ERRI,   ERR,    EPSMIN, EPS,    RE,     REPROD
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * DISCF,  DISCHK, ENDPTS, INEW,   IOLD,   IP,     IXKDIM,          
     * J,      J1,     J1OLD,  J2,     J2OLD,  KMAX,                    
     * KMIN,   L,      LENDT,  NFEVAL, NFJUMP, NSUBSV, NXKDIM,          
     * TALOC,  WHERE2,                                                  
     * I,      K,      KAIMT,  NSUB,   PART,   SEARCH, WHERE
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * DID1,   FAIL,   FATS,   FSAVED, HAVDIF, IEND,   INIT,   ROUNDF,  
     * XCDOBT, PAD
C     SAVE /$L1$INTNC/, /$L1$INTC/
      SAVE /DINTNC/, /DINTC/
C
C $   COL1(PORT)                                                        00015900
C.    THE VARIABLES HERE DEFINE THE MACHINE ENVIRONMENT.  ALL ARE SET
C.    IN $L1$INTOP.  THE MEANING ATTACHED TO THESE VARIABLES CAN BE
C.    FOUND BY LOOKING AT THE RELATED SPECIALIZER VARIABLES DEFINED IN
C.    $L1$INTOP.
      DOUBLE PRECISION EDMEPS
C     $.TYPE.$
      DOUBLE PRECISION                                                  
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     COMMON /$L1$INTEC/
      COMMON /DINTEC/                                                   
     *  EDMEPS,                                                         
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     SAVE /$L1$INTEC/                                                  00015900
      SAVE /DINTEC/
C $   COL1(PORT, 0)
C
C     *****    PROCEDURES     ******************************************
C
      WHERE=0
      NDIM=1
      KDIM=1
      NFEVAL=0
C     CALL $L1$INTOP (IOPT,WORK)                                        00016800
      CALL DINTOP (IOPT,WORK)
      IF(IOPT(1).EQ.0)THEN
C
C        CALL $L1$INTA TO DO THE INTEGRATION.
C
         AINIT=A
         BINIT=B
C        IF (REVERS.EQ.0) CALL $L1$INTA (ANSWER,WORK,IOPT)
         IF (REVERS.EQ.0) CALL DINTA (ANSWER,WORK,IOPT)
      END IF                                                            00017800
      RETURN
C
      END

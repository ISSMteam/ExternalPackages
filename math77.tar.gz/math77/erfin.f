      SUBROUTINE ERFIN
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1985-09-23 ERFIN  Lawson  Initial code.
C
      COMMON/M77ERR/IDELTA,IALPHA
      SAVE /M77ERR/
C
      PRINT 1003
      IF (IALPHA.GE.2) STOP
      RETURN
 1003 FORMAT(1X,72('$')/' ')
      END

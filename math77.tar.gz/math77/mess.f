      subroutine MESS(MACT, TEXT, IDAT)
c     .  Copyright (C) 1991, California Institute of Technology.
c     .  All rights reserved.  U. S. Government sponsorship under
c     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-06-24 MESS  Krogh  More blanks allowed on break of long lines.
c>> 1992-06-10 MESS  Krogh  Minor fix to vector output.
c>> 1992-05-27 MESS  Krogh  Fixed bug on line width setting.
c>> 1992-05-14 MESS  Krogh  Put common blocks in save statement.
c>> 1992-05-11 MESS  Krogh  Added label to assigned go to & a comment.
c>> 1992-04-08 MESS  Krogh  Unused labels 60, 220 and 320 removed.
c>> 1992-03-20 MESS  Krogh  Changed status on open to SCRATCH.
c>> 1992-03-10 MESS  Krogh  1 line below label 690 changed max to min.
c>> 1992-02-05 MESS  Krogh  Fixed bugs in printing matrix labels.
c>> 1992-01-29 MESS  Krogh  Added UMESS and multiple print option.
c>> 1991-12-09 MESS  Krogh  Fine tuning of vector output.
c>> 1991-10-10 MESS  Krogh  Insure no stop if stop level = 9.
c>> 1991-06-26 MESS  Krogh  Initial Code.
c Processes Messages -- Actions are controlled by MACT().
c This routine is intended for use primarily by other library routines.
c Users of library routines may want to use values of MACT from MERET-
c MESUNI, and may have an interest in using it to print messages
c from their own software.
c This routine has companion routines that are called with the same
c three arguments, plus one additional argument.  This argument is
c referred to here as FDAT since actions specified here can result
c in returns to print data from FDAT.  The name FDAT is used because
c this other routine will ordinarily print floating point data, but
c it could also print other kinds of data, e.g. logical.  At present
c only SMESS and DMESS are defined which are for single and double
c precision floating point data.
c MACT is a vector specifying sequentially the actions desired.
c Some of these actions require more than one location, in which
c case the next action follows the last datum required by the
c previous action.  Internal variables together with default
c values in parentheses which are used to keep track of locations
c are as follows:
c  NTEXT  (1)   The next text output starts at TEXT(NTEXT).
c  NIDAT  (1)   The next output from IDAT starts at IDAT(NIDAT).
c  NFDAT  (1)   The next output from FDAT starts at FDAT(NFDAT).
c  NMDAT  (1)   The next output from MDAT starts at MDAT(NMDAT), where
c               MDAT is defined by actions MEMDA1-MEMDA5 below, and
c               NMDAT is set to one at end of every text output.
c An action which uses data pointed to by one of the above will cause
c the pointer to be incrmented to one past the last loction used.  An
c exception is NMDAT which when it reaches 5 is not incremented and the
c value pointed to is incremented instead.
c Actions are encoded by values starting in MACT(1) as follows.
c (Arguments required are given in parentheses at the start of
c description.  These arguments follow the action index.  The next
c action follows the last argument for the preceding action.  Action
c indices have been selected so that it is easy to add new
c functionality without affecting codes using an earlier version.
c MESUNI=10  (K10) Set the unit to use for a scratch file.  The default
c            unit for a scratch file is 30.  If a scratch file is
c            needed, (only needed here if a table exceeds the line
c            length), and unit 30 can not be opened as a new scratch
c            file, then units 29, 28, ..., will be tried until an
c            acceptable unit is found.  Library routines may use this
c            file but must be sure that the use does not conflict with
c            the printing of tables here, or the use by any other
c            library routines.  If this is set to 0, a scratch unit
c            is assumed not to be available, and tables with long lines
c            will be printed with each line on multiple lines.
c MEHEAD=11  (K11) Defines the print that surrounds an error message.
c            K11=0 gives nothing, and 1 gives the first 4 characters in
c            TEXT repeated 18 times. characters in TEXT.  If this is not
c            used, one gets 72 $'s.  (To get a blank line use 1 with
c                   TEXT = '    '.)
c MEDDIG=12  (K12) Set default digits to print for floating point.  If
c            K12 > 0 then K12 significant digits will be printed, if K12
c            <0, then -K12 digits will be printed after the decimal
c            point, and if K12 = 0, the default will be used, which is
c            the full machine precision.  Setting or getting this value
c            will only work properly if the action is taken by calling
c            SMESS or DMESS as appropriate.
c MEMLIN=13  (K13) Set message line length to K13.  (Default is 128.)
c MEELIN=14  (K14) Set error message line length to K14. (Default is 79)
c MEMUNI=15  (K15) Messages go to unit K15.  If K15 = 0 (default),
c            'print' is used.  If K15 < 0, messages go to both 'print'
c            and to unit abs(K15).
c MEEUNI=16  (K16) As for MEMUNI, except for Error Messages.
c MESCRN=17  (K17) Set number of lines to print to standard output
c            before pausing for "go" from user.  Default is 0, which
c            never stops.
c MEDIAG=18  (K18) Set the diagnostic level desired.  This routine
c            makes no use of K18.  It merely serves as a place to set
c            it and to answer inquiries on its value.  It is intended
c            to be set by users of library software.  Library packages
c            that make use of this number are expected to use it as
c            described below.  If K18 = 0 (the default), no diagnostic
c            print is being requested.  Else m = mod(K18,256)
c            determines whether a package will do diagnostic printing.
c            Associated with a library package is a number L which must
c            be a power of 2 < 129, and which should be mentioned in
c            the documentation for the package.  If the bit logical
c            or(m,L) = m then diagnosics output for the routine with the
c            associated value of L is activated.  The value of L should
c            have been selected by the following somewhat vague rules.
c            Let base 2 log(L) = 2*i + j, where j is 0 or 1.  Select i
c            = level of the library package, where the level is 0 if no
c            other library routine that is likely to be used with the
c            package could reasonably be expected to want any embedded
c            diagnostics, and otherwise is min(4, I+1), where I is the
c            maximum level for any library routine which is likely to
c            be used with the package.  Select j = 0 if the user is
c            relatively unlikely to want diagnostics, and j = 1, if
c            this is a routine for which considering its level the user
c            is relatively likely to want diagnostic output.
c            The next 8 bits, mod(K18/256, 256), may be used by the
c            library routine to select the actual output that is to be
c            given.  These bits may be ignored,  but if they are used,
c            the lowest order bits should correspond to less voluminous
c            output that is more likely to be requested.  Finally,
c            K18 / (2**16) may be used to give a count on how many
c            times to print the diagnostics that are given.  This count
c            may be interpreted by library routines in slightly
c            different ways, but when used it should serve to turn off
c            all output after a certain limit is reached.  By
c            convention, if this is 0 there is no upper bound on the
c            count.
c MEMAXE=19  (K19) Set the maximum error value.  When retrieving this
c            value, it is the maximum value seen for 10000*s + 1000*p +
c            i, where s, p, and i are the stop and print levels, and
c            the index on the last error message processed,
c            respectively.  See MEEMES below.
c MESTOP=20  (K20) Set the stop level for error messages.  If an error
c            message has a stop index > min(K20, 8), the program is
c            stopped after processing the message.  The default value is
c            K20=3.
c MEPRNT=21  (K21) Set the print level for error messages.  If an error
c            message has a print index > K21, or the message is going
c            to stop when finished, information in an error message is
c            processed, else all the actions including printing are
c            skipped.  (MESTOP controls stopping.)  The default value
c            is MEPRNT = 3.
c An action index of -i, for i < METDIG, will return in the location
c ordinarily used for Ki the current default value for the internal
c variable set by Ki.  In the case of MESUNI, if the scratch unit has
c not been opened, it will be opened before returning the unit number.
c
c METDIG=22  (K22) As for MEDDIG, except the value here is temporary,
c            lasting until the return, or next use of this action.  If
c            0, the internal value for K12 is used instead.
c MENTXT=23  (K23) Set value of NTEXT to K23.
c MEIDAT=24  (K24) Set value of NIDAT to K24.
c MEFDAT=25  (K25) Set value of NFDAT to K25.
c MEMDAT=26  (K26) Set value of NMDAT to K26.
c MEMDA1=27  (K27) set MDAT(1) to K27.  See description of NMDAT above.
c MEMDA2=28  (K28) set MDAT(2) to K28.
c MEMDA3=29  (K29) set MDAT(3) to K29.
c MEMDA4=30  (K30) set MDAT(4) to K30.
c MEMDA5=31  (K31) set MDAT(5) to K31.
c METABS=32  (K32) set spacing for tabs to to K32.
c MECONT=50  Exit, but no print of current print buffer.  The error or
c            diagnostic message is to be continued immediately.
c MERET=51   All done with diagnostic or error message, complete
c            processing and return, or for some error messages stop.
c MEEMES=52  (K52, L52, M52) Start an error message with severity level
c            K52,index for the error of L52, and message text starting
c            at TEXT(M52).  If M52 is 0, message text starts at
c            TEXT(NTEXT), and if M52 < 0, no message text is
c            printed as part of this action.  Library routines should
c            set K52 = 10*s + p, where s is the stop level desired, and
c            p the print level, and should have 10 > p .ge. s .ge. 0.
c            We offer the following guidelines as a yardstick for
c            setting the value of s.
c   = 9  User has ignored warning that program was going to be stopped.
c   = 8  Program has no way to continue.
c   = 7  User has given no indication of knowing that functionality of
c        results is reduced.  (E.g. not enough space for some result.)
c   = 6  Program could continue but with reduced functionality.
c   = 5  Results far worse than user expected to want.
c   = 4  User has given no indication of knowing that results do not
c        meet requested or expected accuracy.
c   = 3  Warning is given that program will be stopped without some
c        kind of response from the calling program.
c   = 2  Program is not delivering requested or expected accuracy.
c   = 1  Some kind of problem that user could correct with more care in
c        coding or in problem formulation.
c   = 0  Message is for information of uncritical nature.
c            Print levels might be counted down so that warnings given
c            several times are no longer given, or be counted up so
c            that a warning is only given after a certain threshold is
c            reached.  Levels should be selected with the understanding
c            that the default is to print only levels above 3.
c METEXT=53  Print TEXT, starting at TEXT(NTEXT).  Print ends
c            with the last character preceding the first '$'.  Special
c            actions are determined by the character following the '$'.
c            Except as noted, the '$' and the single character which
c            follows are not printed.  In the text below, "to continue",
c            means to continue print of TEXT with the next character
c            until the next "$".  Except for the one case noted, NTEXT
c            is set to point to the second character after the "$".
c            Note, letters must be in upper case.  Possibilities are:
c      B  Break text, but don't start a new line.
c      E  End of text and line.
c      R  Break text, don't change the value of NTEXT.  Thus next
c         text Repeats the current.
c      N  Start a New line, and continue.
c      I  Print IDAT(NIDAT), set NIDAT=NIDAT+1, and continue.
c      J  As for I above, except use the last integer format
c         defined by a "$(", see below.
c      F  Print FDAT(NFDAT), set NFDAT=NFDAT+1, and continue.
c      G  As for F above, except use the last floating format
c         defined by a "$(", see below.
c      M  Print MDAT(NMDAT), set NMDAT=NMDAT+1, and continue.  When
c         used in matrix row or column labels this prints the
c         current row or column index, respectively, ends the text
c         for the current row or column, and resets the text pointer
c         to where it started.
c      H  Marks terminator for column amd row Headings, see table,
c         vector, and matrix output below.  This causes enough blanks to
c         be generated to keep column headings centered over their
c         columns.  After the blanks are generated, text is continued
c         until the next '$'.  This is not to be used except inside
c         column or row headings.
c      (  Starts the definition of a format for integer or floating
c         point output.  The format may contain a "P" field but
c         nothing else additional, and must require no more than 14
c         characters for floating point (e.g. "(pPnnEww.ddEe)", where
c         each of the lower case letters represents a single digit), and
c         no more than 7 characters for integer output.  Following the
c         ")" that ends the format, if the next character is not a "$"
c         then "$J" or "$G" type output is done, see above.  In either
c         case processing of TEXT then continues.
c      T  Tab.
c      $  a single '$' is printed, continue till the next '$'. 
c      C  Only used by PMESS which deletes it and the preceding '$'.
c         Used at the end of a line to indicate continued text.
c   other Don't use this -- the '$' is ignored, but new features may
c         change the action.
c METXTF=54  (K54)  Treat TEXT as having K54 entries and print the
c            characters without looking for the '$' character.  If the
c            first character is '0' a blank line is printed in place
c            of the character (if the current print buffer is empty).
c METABL=55  (K55, L55, M55, N55)  Note this action automatically
c            returns when done, further locations in MACT are not
c            examined.  This action prints a heading and/or data that
c            follows a heading.  If K55 is 1, then the heading text
c            starting in TEXT(NTEXT) is printed.  This text
c            should contain embedded "$H"'s to terminate columns of the
c            heading.  If there is no heading on a column, use " $H".
c            Note the leading blank.  If the heading is to continue
c            over k columns, begin the text with "$H" repeated k-1
c            times with no other embedded characters.
c            After tabular data is printed, K55 is incremented by 1,
c            and compared with L55.  If K55 > L55, K55 is reset to 1,
c            and if the data that was to be printed had lines that were
c            too long, data saved in the scratch file is printed using
c            the headings for the columns that would not fit on the
c            first pass.  Note that only one line of tabular data can
c            be printed on one call to this subroutine.
c            M55 gives the number of columns of data associated with the
c            heading.
c            N55 is a vector containing M55 entries.  The k-th integer
c            in N55 defines the printing action for the k-th column
c            of the table.  Let such an integer have a value defined by
c            +/- (r + 100 * (w + 100 * f)) where the number is positive
c            if integers are to be output, and negative otherwise, and 
c            r and w are < 100.  (If the number is negative and r is 0,
c            then TEXT(NTEXT) to TEXT(NTEXT+w-1) is copied to the output
c            and NTEXT is replaced by NTEXT+w.  An f pointing to a valid
c            format must be specified, but the format is not referenced.
c      r     The number of times the format is to repeat.  If r = 0,
c            then the format repeats once and the integer K55 is printed
c            instead of printing from IDAT.
c      w     The total number of column positions used by the column,
c            including the space used to separate this column from the
c            preceding one.  This must be big enough so that the column
c            headings will fit without overlap.
c      f     The starting "(" for the format is in TEXT(f).
c MEIVEC=57  (K57) Print IDAT as a vector with K57 entries.  The vector
c            output starts on the current line even if the current line
c            contains text.  This is useful for labeling the vector.
c            The vector starts at IDAT(NIDAT).
c            If K57 < 0,  indices printed in the labels for the vector
c            start at at NIDAT, and entries from NIDAT to -K57 are
c            printed.
c MEIMAT=58  (K58, L58, M58, I58, J58) Print IDAT as a matrix with K58
c            declared rows, L58 actual rows, and M58 columns.  If L58<0,
c            the number of actual rows is mod(-L58, 100000), and the
c            starting row index is -L58 / 100000.  Similarly for M58<0.
c            TEXT(I58) starts the text for printing row labels.  If
c            I58 < 0, no row labels are printed.  If I58 = 0, it is as
c            if it pointed to text containing "Row $M".  Any "$" in a
c            row or column label must be followed by "H" or
c            "M" which terminates the text for the label.  In the case
c            of $H, text for the next label follows immediately,
c            in the case of $M the current row index is printed in place
c            of the $M and the next label uses the same text.  J58 is
c            treated similarly to I58, except for column labels, and
c            with "Row $M" replaced with "Col $M".  The matrix starts at
c            IDAT(NIDAT), and NIDAT points one past the end of the
c            matrix when finished.
c MEJVEC=59  (K59) As for MEIVEC, except use format set with $(.
c MEJMAT=60  (K60, L60, M60, I60, J60) As for MEIMAT, except use the
c            format set with $(.
c MEFVEC=61  (K61) As for MEIVEC, except print FDAT as a vector with
c            K61 entries.  The vector starts at FDAT(NFDAT).
c MEFMAT=62  (K62, L62, M62, I62, J62) As for action MEIMAT, but
c            instead print FDAT, and use NFDAT in place of NIDAT.
c MEGVEC=63  (K63) As for MEFVEC, except use format set with $(.
c MEGMAT=64  (K64, L64, M64, I64, J64) As for MEIMAT, except use the
c            format set with $(.
c
c ************** Parameters Defining Actions (See Above) ***************
c
      parameter (MESUNI =10)
      parameter (MEHEAD =11)
      parameter (MEDDIG =12)
      parameter (MEMLIN =13)
      parameter (MEELIN =14)
      parameter (MEMUNI =15)
      parameter (MEEUNI =16)
      parameter (MESCRN =17)
      parameter (MEDIAG =18)
      parameter (MEMAXE =19)
      parameter (MESTOP =20)
      parameter (MEPRNT =21)
      parameter (METDIG =22)
      parameter (MENTXT =23)
      parameter (MEIDAT =24)
      parameter (MEFDAT =25)
      parameter (MEMDAT =26)
      parameter (MEMDA1 =27)
      parameter (MEMDA2 =28)
      parameter (MEMDA3 =29)
      parameter (MEMDA4 =30)
      parameter (MEMDA5 =31)
      parameter (METABS =32)
      parameter (MECONT =50)
      parameter (MERET  =51)
      parameter (MEEMES =52)
      parameter (METEXT =53)
      parameter (METXTF =54)
      parameter (METABL =55)
      parameter (MERES3 =56)
      parameter (MEIVEC =57)
      parameter (MEIMAT =58)
      parameter (MEJVEC =59)
      parameter (MEJMAT =60)
      parameter (MEFVEC =61)
      parameter (MEFMAT =62)
      parameter (MEGVEC =63)
      parameter (MEGMAT =64)
c Parameter derived from those above.
      parameter (MEMAXI =64)
      parameter (MEGBAS =49)
      parameter (MEVBAS = 10)
      parameter (MEVLAS = 32)
      parameter (MESLAS = MEMLIN)
c
c ************************** Internal Variables ************************
c
c BUF    Character string holding characters to be output.
c DOLS   A heading/trailing string of characters, default = $'s.
c ERMSG  Default part of error message.
c EUNIT  Unit number for output of error messages.
c FDAT   Formal array, containing floating point data to output.  Only
c   appears external to this subroutine.
c FMTC   Format for integer output of matrix column headings.
c FMTF   Format for floating point or other output.
c FMTG   Format set by user for floating point or other output.
c FMTI   Charaacter string holding format for integer output.
c FMTIM  Equivalenced to FMTR, FMTC.
c FMTJ   Format set by user for integer output.
c FMTR   Value of FMTI for format of row indices.
c FMTT   Format to be stored in FMTJ or FMTG
c GOTFMT Set .true. if format has been set by user.  When printing
c   tables, set true when heading has been output.
c I      Index of current action from MACT.
c ICHAR0 Value of ICHAR('0')
c ICOL   Current column index in matrix output.
c IDAT   Formal array, containing integer data to output.
c IMAG   Magnitude of integer to output, with negative sign if integer
c   is < 0.
c IMAX   Used when computing largest integer in array.
c IMIN   Used when computing smallest integer in array.
c INCM   Array giving amount of space used by the options.
c INERR  0 if not processing an error message, 1 if printing an error
c   message, -1 if in an error message that is not being printed, and >1
c   if printing an error message that stops.  Set to -2 when the error
c   message is supposed to stop.
c IOUT   Integer to be output.
c IRC    = 1 for rows, = 2 for columns when determining labels for
c   matrix output.
c IROW   Row index for matrix output.  Also used in table output to
c    count lines for printing line index on read from scratch unit.
c IROW1  Starting row index for matrix output.
c IVAR   Integer array, that is equivalence to a number of integer
c   variables that can be set by the user.
c IWF    Width to be used in a floating pt. (or other) format.
c IWG    Value like IWF for user set format.
c J      Used as a temporary index.
c JJ      Used as a temporary index.
c K      Used as a temporary index.
c KD     Number of locations needed to print the current integer.
c KDF    Current number of digits to print for floating point.  See
c   description of MACT(*) = METDIG above.
c KDFDEF Current default for KDF, see description of MACT(*) = MEDDIG.
c KDI    Value of KD from last print of an integer.
c KDIAG  Not directly referenced.  Holds place in IVAR for reference
c   from outside.  See comments above.
c KDILAB Length for printing index in vector output.
c KDJ    As for KD, except for format set by user.
c KF     Location of format for current numeric output in table.
c KGO    Used for an assigned go to for the action after printing BUF.
c KK     Temporary index.
c KLINE  Count of number of things to print on a line.  (In table print
c   is the number to print for one spec field.)
c KNT    In vector output gives the current index for output.
c KOLWID Length to use for printing a column heading.  Equivalenced to
c   MAXWID(2).
c KP     Index from error action input for the print action.
c KRES1  Holds place in common block for future use.
c KS     Index from error action input for the stop action.
c KSCRN  Number of lines to "print" before pausing.
c KSHIFT Amount to shift column heading before printing.
c KSPEC  Defines action after looking for character in TEXT.  (Also
c   used as a temporary index.)
c   1.  $B   Break the text here continue on same line.
c   2.  $E   Break text, print what is in BUF.
c   3.  $R   Break text, continue on same line, NTEXT set to repeat the
c            current text.
c   4.  $N   Print BUF, continue with following text.
c   5.  $I   Print IDAT(NIDAT), continue TEXT.
c   6.  $F   Print FDAT(NFDAT), continue TEXT.
c   7.  $M   Print MDAT(NMDAT), continue TEXT.
c   8.  $J   As for $I, but with user format.
c   9.  $G   As for $F, but with user format.
c  10.  $(   Set a user format.
c  11.  $T   Tab.
c  12.       Set when done with an action.
c  13.       Set when done with boiler plate text for an error message.
c   0. Other Ignore the "$", continue with TEXT.
c L      Used as a temporary index.
c LASKNT In vector output value index for last element to print.
c LASTI  Last index for matrix output, or for finding values that
c   determine format.
c LBUF   Position of characters in BUF, usually the last to print.
c LBUF1  Start of text to shift when shifting text in BUF to the left.
c LBUF2  End of text to shift when shifting text in BUF to the left.
c LENBUF Parameter giving the number of character in BUF.
c LENLIN Gives number of character in output lines.
c LENOUT Length of output for table or vector/matrix output.
c LENTRY Tells what to do on entry (and sometimes other places.)
c   = 1  The value on first entry.
c   = 2  A previous entry is to be continued.
c   = 3  A non printing error message is to be continued
c   = 4  Just done output from inside a METEXT action.
c   = 5  Got "maximum" value for entries in a vector.
c   = 6  Got "maximum" value for entries in a matrix.
c   = 7  Vector (either print or get format for label indices.)
c   = 8  Matrix (either print or get format for label indices.)
c   = 9  Output of data in a table.
c LHEAD  If = 0 no print of DOLS, else DOLS printed in error messages.
c LINERR Gives LENLIN for error messages.
c LINMSG Gives LENLIN for diagnostic messages.
c LINSTR Space at start of line for label in vector and matrix output.
c   Equivalenced to MAXWID(1).
c LNERR  Parameter giving the default value for LENERR, only in XMESS.
c LNMSG  Parameter giving the default value for LENMSG, only in XMESS.
c LOCBEG Index of first item in vector and matrix output.
c LPRINT For error messages with a print level .le. LPRINT nothing is
c   printed (unless the message would result in a stop).
c LSTOP  As for LPRINT, except with the stop level, and stopping.
c LSTRT  Starting character position in BUF for storing next characters.
c M      Index for the current action.
c MACT   Formal integer array specifying the actions, see above.
c MAXERR Value save in IVAR for user to get indication of last (really
c   the maximum error seen so far = 1000 * (10*stop + print) + index.
c MAXWID Equivalenced to  LINSTR and KOLWID.
c MDAT   Array where user can store integers in IVAR for later output.
c
c The following parameter names starting with ME define actions
c   which the user can request.  They have been documented in the
c   description above, except for the ones defined just below.
c MEGBAS is 1 less than the smallest action that involves something
c   other than just storing or retrieving a value.
c MEMAXI is the largest action which a user can request.
c MESLAS is the largest action index for setting or storing that
c   requires a special value.
c MEVBAS is the smallest action index, used to set the starting index in
c   IVAR.
c MECONT,  MEDDI,  MEELI,  MEEME, MEEUNI, MEFDAT, MEFMAT, MEFVEC,
c MEGBAS, MEGMAT, MEGVEC, MEHEAD, MEIDAT, MEIMAT, MEIVEC, MEJMAT,
c MEJVEC, MEMAXE, MEMAXI, MEMDA1, MEMDA2, MEMDA3, MEMDA4, MEMDA5,
c MEMDAT, MEMLIN, MEMUNI, MENTXT, MEPRNT, MESCRN, MERES1, MERES2,
c MERES3, MERET, MESTOP, MESUNI, METABL, METDIG, METEXT, METXTF
c MPT    Current pointer to data for matrix or vector output.
c MTEXT  Equivalenced to MTEXTR and MTEXTC.
c MTEXTC TEXT(MTEXTC) starts text for printing column labels.
c   When printing tables gives place where line was split. (0 if not)
c MTEXTR TEXT(MTEXTR) starts text for printing row labels.
c MUNIT  Output unit used for messages that aren't in an error message.
c NCOL   Number of columns for matrix output, 0 for vector output,
c   count of column left for table output.
c NDIM   Distance between columns for matrix output.
c NFDAT  Index of next item in FDAT to print.
c NIDAT  Index of next item in IDAT to print.
c NLINE  Maximum number of data items to print on a line for matrix and
c   vector output.  If the scratch file is used for table output,
c   NLINE gives the original end of the buffer.
c NMDAT  Pointer to next thing to print from MDAT.
c NROCO  Equivalenced to (NROW, NCOL).  Used in matrix output.
c NROW   Number of rows for matrix output.
c NSCRN  Number of lines currently on CRT from messages.
c NTEXT  Index in TEXT for the next text output.
c NTEXTR Value of NTEXT to use if get a $R.
c NTXTSV Saved value of NTEXT when doing matrix output.
c OUNIT  Index of the current output unit.
c SC     Paramter for special character used to introduce actions.
c   Default value is '$'.  If this is changed the "$"'s in comments
c   should be changed to the new value of the character.  (Note that
c   SC = '\' is not portable.)
c SUNIT  Index for the scratch unit, -1 if not yet assigned.
c TEXT   Formal argument giving the character string from which all text
c   is taken.
c UMESS  Name of subroutine called that does nothing, but which may be
c   modified by the user to cause different actions to be taken.
c XARG   If .true., output data is not integer, and a return is made to
c   print data from FDAT.
c XARGOK Set .true. if call is from program that will print data from
c   FDAT.
c XMESS  Name of the block data subprogram that initializes common data.
c
c ************************** Variable Declarations *********************
c
      integer          MACT(*), IDAT(*)
      character        TEXT(*)
c
      integer          I, ICHAR0, ICOL, IMAG, IMAX, IMIN,
     1    INCM(MECONT:MEIMAT), INERR, IOUT, IRC, IROW, J, JJ, K, KD,
     2    KDI, KDILAB, KDJ, KF, KGO, KK, KNT, KOLWID, KP, KS, KSHIFT,
     3    L, LASKNT, LBUF1, LBUF2, LENBUF, LENOUT, LINSTR,
     4    M, MAXWID(2), MTEXT(2), MTEXTC, MTEXTR, NLINE,
     5    NSCRN, NTEXTR, NTXTSV
      character ERMSG*63, FMTI*7, FMTIM(2)*7, FMTJ*7, FMTR*7, FMTC*7
      character SC, C
      parameter (SC = '$')
      logical XARG, GOTFMT
      save  FMTI, FMTIM, FMTJ
      save  GOTFMT, I, ICHAR0, ICOL, INERR, IROW, IROW1, KDI, KDJ,
     1   KDILAB, KNT, KSHIFT, LASKNT, LENOUT, M, MAXWID, MTEXT,
     2   NLINE, NTXTSV, XARG
      save /CMESSI/, /CMESSC/
      equivalence (MAXWID(1), LINSTR), (MAXWID(2), KOLWID),
     1   (MTEXT(1), MTEXTR), (MTEXT(2), MTEXTC), (FMTIM(1), FMTR),
     2   (FMTIM(2), FMTC)
c
c ************************** Data from common block ********************
c
      external XMESS
      parameter (LENBUF = 160)
      logical          XARGOK
      integer          EUNIT, IVAR(MEVBAS:MEVLAS), IWF, IWG, KDF,
     1   KDFDEF, KDIAG, KLINE, KSCRN, KSPEC, MAXERR, LASTI, LBUF,
     2   LENLIN, LENTRY, LHEAD, LINERR, LINMSG, LOCBEG, LPRINT, LSTOP,
     3   LSTRT, MDAT(5), MPT, MUNIT, NCOL, NDIM, NFDAT, NIDAT, NMDAT,
     4   NROW, NTEXT, OUNIT, SUNIT, TABSPA
c
      character BUF*(LENBUF), DOLS*72, FMTF*14, FMTG*14, FMTT*14
      common /CMESSI/ SUNIT, LHEAD, KDFDEF, LINMSG, LINERR, MUNIT,
     1   EUNIT, KSCRN, KDIAG, MAXERR, LSTOP, LPRINT, KDF, NTEXT,
     2   NIDAT, NFDAT, NMDAT, MDAT, TABSPA, IWF, IWG, KLINE,
     3   KSPEC, LASTI, LBUF, LENLIN, LENTRY, LOCBEG, LSTRT, MPT, NROW,
     4   NCOL, NDIM, OUNIT, XARGOK
      common /CMESSC / BUF, DOLS, FMTF, FMTG, FMTT
      equivalence (IVAR(MEVBAS), SUNIT)
      integer NROCO(2)
      equivalence (NROCO, NROW)
c ************************** End of stuff from common block ************
c
      data ICHAR0, INERR, KDI, KDJ, NSCRN / -1, 0, 0, 6, 0 /
      data ERMSG(1:32) / ' reports error: Stop level = x, '/,
     1  ERMSG(33:63) /'Print level = y, Error index = ' /
      data FMTI, FMTJ / '(99Ixx)', '(99I06)' /
c                 50  51, 52  53  54 55 56 57 58
      data INCM /  1,  1,  4,  1,  2, 0, 0, 2, 6 /
c
c ************************* Start of Executable Code *******************
c
      go to (5, 10, 20, 850, 1060, 1620, 1130, 1530, 960), LENTRY
      ICHAR0 = ICHAR('0')
c                             First entry for a message
    5 LBUF = 0
      LENLIN = LINMSG
c                             Usual continuation entry
   10 I = 1
      NTEXT = 1
      NIDAT = 1
      NFDAT = 1
      NMDAT = 1
      go to 120
c                     Continuation entry when have a non printing error
c Skip all actions -- Inside non-printing error message.
   20 I = 1
   30 K = MACT(I)
      if (K .le. MERET) then
         if (K .eq. MERET) go to 120
         if (K .eq. MECONT) return
         if (K .le. -MEGBAS) go to 180
         I = I + 2
      else
         if (K .gt. MEIMAT) then
            if (K .gt. MEMAXI) go to 180
            K = MEIVEC + mod(K - MEIVEC, 2)
         end if
         I = I + INCM(K)
      end if
      go to 30
c
c Print BUF
   40 assign 100 to KGO
   50 if (LBUF .ne. 0) then
         if (OUNIT .le. 0) then
            if (KSCRN .gt. 0) then
               if (NSCRN .gt. KSCRN) then
                  print '('' Type "Enter" to continue'')'
                  read (*, *)
                  NSCRN = 0
               end if
               NSCRN = NSCRN + 1
            end if
            print '(1X, A)', BUF(1:LBUF)
            if (OUNIT .eq. 0) go to 55
         end if
         write (abs(OUNIT), '(A)') BUF(1:LBUF)
   55    LBUF = 0
      end if
      go to KGO, (100, 230, 340, 350, 400, 430, 500, 904, 920, 990, 995,
     1            1090, 1420, 1500, 1540)
c                             Get here when done with METEXT action.
   80 NMDAT = 1
      assign 100 to KGO
c                             Usual place to end an action request.
  100 I = I + INCM(M)
c                             Pick up the next action request
  120 M = MACT(I)
      if (M .gt. MEGBAS) go to 140
      I = I + 2
      if (abs(M) .gt. MEVLAS) go to 180
      if (M .gt. 0) then
         IVAR(M) = MACT(I-1)
         if (M .gt. MESLAS) go to 120
         if (M .eq. MEHEAD) then
            if (LHEAD .ne. 0) then
               DOLS(1:4) = TEXT(1)//TEXT(2)//TEXT(3)//TEXT(4)
               do 125 K = 5, 72, 4
                  DOLS(K:K+3) = DOLS(1:4)
  125          continue
            end if
         else if (M .eq. MEDDIG) then
            KDF = KDFDEF
         else
            LENLIN = LINMSG
         end if
         go to 120
      end if
      if (M .eq. -MESUNI) then
         if (SUNIT .le. 0) go to 965
      end if
  130 MACT(I-1) = IVAR(-M)
      go to 120
c  ME ..    CONT  RET EMES ETXT TXTF TABL
  140 go to (170, 200, 310, 400, 902, 910, 180), M-MEGBAS
      if (M .le. MEGMAT) go to 1000
      go to 180
c
c Action MECONT -- Continue message on next entry
  170 LENTRY = 2
      return
c
c Some kind of error in message specification.
  180 BUF(1:57) =
     1   'Actions in MESS terminated due to error in usage of MESS.'
      LBUF = 57
c
c Action MERET -- Finish a message.
  200 LENTRY = 1
      J = INERR
      INERR = 0
      if (J .ge. 2) INERR = -2
      if (J .gt. 0) go to 330
c                       Finish print before exit.
      assign 230 to KGO
      go to 50
  230 return
c
c Action MEEMES -- Start an error message
  310 LENTRY = 3
      call UMESS(TEXT, MACT(I+1), IVAR)
      IOUT = MACT(I+2)
      K = MACT(I+1)
      MAXERR = max(MAXERR, 1000*K + IOUT)
      KS = K / 10
      KP = K - 10 * KS
      if (KS .le. min(LSTOP, 8)) then
         if (KP .le. LPRINT) then
            INERR = -1
            go to 20
         end if
         INERR = 1
      else
         INERR = 2
      end if
      OUNIT = EUNIT
      LENLIN = LINERR
c                        Output a blank line.
      BUF(1:1) = ' '
      LBUF = 1
  330 assign 340 to KGO
      go to 50
c                        Put out line of $'s
  340 if (LHEAD .eq. 0) go to 350
      assign 350 to KGO
      LBUF = min(len(DOLS), LENLIN)
      BUF = DOLS
      if (INERR .lt. 0) BUF(5:37) = ' Fatal error -- Program stopped. '
      go to 50
  350 if (INERR .le. 0) then
c                                 Just finished an error message
         if (INERR .ne. 0) stop 'Stopped in MESS.'
         OUNIT = MUNIT
         return
      end if
c                     Just starting an error message get program name
      NTEXTR = 0
      go to 410
c                     Got the program name in BUF.
  370 ERMSG(30:30) = char(KS + ICHAR0)
      ERMSG(47:47) = char(KP + ICHAR0)
      LBUF = min(LBUF, 40)
      BUF(LBUF+1:LBUF+len(ERMSG)) = ERMSG
      LBUF = LBUF + len(ERMSG)
      go to 720
  380 LBUF = LBUF + KDI
      write (BUF(LSTRT:LBUF), FMTI) IOUT
c          Finish up the start error message action.
      if (MACT(I+3) .lt. 0) go to 40
      if (MACT(I+3) .ne. 0) NTEXT = MACT(I+3)
      KSPEC = 13
      go to 480
c                  Take care of any left over print from error header
  390 if (LBUF .ne. 0) go to 50
c
c Action METEXT -- Print string from TEXT
  400 LENTRY = 4
      NTEXTR = NTEXT
c                  Continue with print from TEXT
  410 NTEXT = NTEXT - LBUF - 1
      do 415 LBUF = LBUF+1, LENBUF
         C = TEXT(NTEXT+LBUF)
         if (C .eq. SC) go to 416
         BUF(LBUF:LBUF) = C
  415 continue
      if (NTEXTR .ne. 0) then
c                           Really long text -- break it
         KSPEC = 12
         NTEXT = NTEXT + LBUF
         if (NTEXT - NTEXTR .lt. 4000) go to 480
         KSPEC = 2
         go to 420
      end if
  416 LBUF = LBUF - 1
      NTEXT = NTEXT + LBUF + 3
      if (NTEXTR .eq. 0) then
         if (LENTRY .eq. 3) go to 370
         go to 1510
      end if
      KSPEC = index('BERNIMFJG(T', TEXT(NTEXT-1))
  420 assign 430 to KGO
  430 if (LBUF .gt. LENLIN) go to 480
c             1   2   3   4   5   6   7   8   9  10  11  12, 13
c             B   E   R   N   I   M   F   J   G   (   T done end err
      go to (80,480,450,460,700,680,900,700,900,600,690,410, 390), KSPEC
c                        No match, continue with the text.
  440 NTEXT = NTEXT - 1
      go to 410
c                        Reset NTEXT for $R
  450 NTEXT = NTEXTR
      go to 80
c           At this point want to output all in BUF
  460 do 470 LBUF = LBUF, 1, -1
         if (BUF(LBUF:LBUF) .ne. ' ') go to 480
  470 continue
  480 LBUF2 = LBUF
      if (LBUF2 .eq. 0) then
         LBUF = 1
         BUF(1:1) = ' '
      else if (LBUF .gt. LENLIN) then
         do 485 K = LENLIN+1, LENLIN/3, -1
            if (BUF(K:K) .eq. ' ') then
               LBUF = K - 1
               go to 490
            end if
  485    continue
         LBUF = LENLIN
      end if
  490 LBUF1 = LBUF
      assign 500 to KGO
      go to 50
  500 if (LBUF1 .ge. LBUF2) then
c                       The entire buffer has been printed.
         if (KSPEC .le. 2) go to 80
         if (KSPEC .ne. 4) go to 420
         go to 410
      end if
c                       Remove trailing blanks
      do 510 LBUF1 = LBUF1+1, LBUF2
         if (BUF(LBUF1:LBUF1) .ne. ' ') go to 520
  510 continue
c                       Shift the contents of the buffer.
  520 LBUF = LBUF2-LBUF1+1
      LSTRT = 1
  530 if (LBUF .ge. LBUF1) then
c                              Take care of overlap.
         K = 2*LBUF1 - LSTRT
         BUF(LSTRT:LBUF1-1) = BUF(LBUF1:K-1)
         LSTRT = LBUF1
         LBUF1 = K
         go to 530
      end if
      if (LBUF .ge. LSTRT) BUF(LSTRT:LBUF) = BUF(LBUF1:LBUF2)
      go to 420
c
c Get information on user format
  600 KSPEC = 9
      L = 0
      FMTT(1:3) = '(99'
      do 609 K = NTEXT, NTEXT+8
         FMTT(K-NTEXT+4:K-NTEXT+4) = TEXT(K)
         go to (601,602,604,604,606,606), index(').PpIi', TEXT(K))
         go to 609
c
  601    if (L .ne. 0) go to 610
         if (KSPEC .eq. 9) go to 440
c                             Get the width
  602    IMAG = 1
         KK = K
  603    KK = KK - 1
         JJ = ichar(TEXT(KK)) - ICHAR0
         if ((JJ .ge. 0) .and. (JJ .le. 9)) then
            L = L + JJ * IMAG
            IMAG = 10 * IMAG
            go to 603
         end if
         if ((L .lt. 1) .or. (L .gt. 40)) go to 440
         if (TEXT(K) .eq. ')') go to 610
         go to 609
c                                       Shift nP to front.
  604    do 605 KK = 2, K-NTEXT+2
            FMTT(KK:KK) = FMTT(KK+2:KK+2)
  605    continue
         FMTT(KK:KK+1) = '99'
         go to 609
c
  606    KSPEC = 8
  609 continue
      go to 440
c
  610 NTEXT = K + 1
      if (KSPEC .eq. 8) then
         KDJ = L
         FMTJ = FMTT
      else
         IWG = L
         FMTG = FMTT
      end if
      if (TEXT(NTEXT) .eq. SC) go to 410
      if (KSPEC .eq. 8) go to 700
      if (XARGOK) return
      go to 440
c
c                         Print from MDAT
  680 IOUT = MDAT(NMDAT)
      if (NMDAT .ge. 6) then
         MDAT(NMDAT) = MDAT(NMDAT) + 1
      else
         NMDAT = NMDAT + 1
      end if
      go to 720
c
c                         Process a tab
  690 LSTRT = LBUF + 1
      LBUF = min(LBUF + TABSPA - mod(LBUF, TABSPA), LENLIN+1)
      BUF(LSTRT:LBUF) = ' '
      go to 850
c                         Print from IDAT
  700 IOUT = IDAT(NIDAT)
      NIDAT = NIDAT + 1
  720 LSTRT = LBUF + 1
      IMAG = IOUT
      if (KSPEC .ge. 8) then
         LBUF = LBUF + KDJ
         write (BUF(LSTRT:LBUF), FMTJ) IOUT
         go to 850
      end if
c
c                Get format for integer output.
  800 KD = 1
  810 K = 10
      if (IMAG .lt. 0) then
         IMAG = -IMAG
         KD = KD + 1
      end if
      go to 830
  820 K = 10 * K
      KD = KD + 1
  830 if (IMAG .ge. K) go to 820
      if (KD .ne. KDI) then
         KDI = KD
         write (FMTI(5:6), '(I2)') KDI
      end if
      go to (380, 840, 1070, 1380, 1020, 1350), LENTRY - 2
  840 LBUF = LBUF + KDI
      write (BUF(LSTRT:LBUF), FMTI) IOUT
c                         Entry here to check line after numeric output.
  850 KSPEC = 12
      if (LBUF .gt. LENLIN) go to 480
      go to 410
c
c                          Take care of output for extra argument.
  900 if (XARGOK) return
      go to 180
c
c Action METXTF -- Print text with Fortran vertical format control.
  902 K = NTEXT + min(MACT(I+1), LENBUF) - 1
      assign 904 to KGO
      if (LBUF .ne. 0) go to 50
      if (TEXT(NTEXT) .eq. '0') then
         NTEXT = NTEXT+1
         BUF(1:1) = ' '
         LBUF = 1
         go to 50
      end if
  904 do 906 NTEXT = NTEXT, K
         LBUF = LBUF + 1
         BUF(LBUF:LBUF) = TEXT(NTEXT)
  906 continue
      go to 100

c
c Action METABL -- Start a table
  910 GOTFMT = MACT(I+1) .ne. 1
      if (.not. GOTFMT) then
         IROW = 0
         KOLWID = 0
      end if
      LENTRY = 9
      assign 920 to KGO
      if (LBUF .ne. 0) go to 50
  920 BUF = ' '
      MTEXTC = 1
      NCOL = MACT(I+3)
      ICOL = I + 3
  940 ICOL = ICOL + 1
      JJ = MACT(ICOL)
      XARG = JJ .lt. 0
      if (XARG) JJ = - JJ
      KLINE = mod(JJ, 100)
      LENOUT = mod(JJ, 10000) / 100
      KF = JJ / 10000
      NCOL = NCOL - max(KLINE, 1)
      if (GOTFMT) then
c                                 Print the data
         do 945 KK = KF, KF + 11
            FMTT(KK-KF+1:KK-KF+1) = TEXT(KK)
            if (TEXT(KK) .eq. ')') go to 947
  945    continue
         go to 180
  947    LSTRT = LBUF + 1
         LBUF = LBUF + KLINE * LENOUT
         if (XARG) then
            if (KLINE .ne. 0) then
               if (.not. XARGOK) go to 180
               MPT = NFDAT
               NFDAT = NFDAT + KLINE
               return
            end if
            NCOL = NCOL - 1
            do 948 JJ = 1, LENOUT 
               LBUF = LBUF + 1
               BUF(LBUF:LBUF) = TEXT(NTEXT)
               NTEXT = NTEXT + 1
  948       continue
         else if (KLINE .eq. 0) then
            LBUF = LBUF + LENOUT
            write (BUF(LSTRT:LBUF), FMTT) MACT(I+1)
         else
            write (BUF(LSTRT:LBUF), FMTT) (IDAT(K), K = NIDAT,
     1          NIDAT+KLINE-1)
            NIDAT = NIDAT + KLINE
         end if
      else
c                                 Print the heading
         KT = 1
         go to 1700
      end if
  960 if ((LBUF .le. MDAT(MTEXTC)) .and. (NCOL .gt. 0)) go to 940
      if (MTEXTC .eq. 1) then
         JJ = LBUF
         LBUF = MDAT(1)
         assign 990 to KGO
         go to 50
      end if
      if (IROW .ne. 0) go to 980
      if (MTEXTC .ne. 2) go to 980
      if (SUNIT .gt. 0) go to 975
c                                 Get a scratch unit assigned.
  965 SUNIT = 31
  970 SUNIT = SUNIT - 1
      if (SUNIT .eq. 0) stop 'Could not assign scratch unit in MESS.'
      open (SUNIT, STATUS='SCRATCH', ACCESS='SEQUENTIAL',
     1    FORM='UNFORMATTED', IOSTAT=J)
      if (J .ne. 0) go to 970
      if (M .lt. 0) go to 130
  975 rewind(SUNIT)
  980 write(SUNIT) BUF(5:MDAT(MTEXTC))
      go to 993
  990 LBUF = JJ
  993 if (LBUF .gt. MDAT(MTEXTC)) then
         BUF(5:LBUF - MDAT(MTEXTC) + 4) = BUF(MDAT(MTEXTC)+1:LBUF)
         LBUF = LBUF - MDAT(MTEXTC) + 4
         MTEXTC = MTEXTC + 1
         if (.not. GOTFMT) then
            if (MTEXTC .gt. 5) go to 180
            MDAT(MTEXTC) = LBUF
         end if
         if (NCOL .eq. 0) go to 960
         go to 940
      end if
      if (.not. GOTFMT) then
         GOTFMT = .true.
         IROW = IROW - 1
         LBUF = 0
         go to 920
      end if
      MACT(I+1) = MACT(I+1) + 1
      if (MACT(I+1) .le. MACT(I+2)) go to 999
      MACT(I+1) = 1
      if (MTEXTC .eq. 1) go to 999
      assign 995 to KGO
      endfile SUNIT
      KK = 1
  994 KK = KK + 1
      if (KK .gt. MTEXTC) go to 999
      rewind(SUNIT)
      IROW = -1
      K = KK
  995 LBUF = 5
      do 996 J = 2, K
         if (J .eq. K) LBUF = MDAT(KK)
         read(SUNIT, END = 994) BUF(5:LBUF)
  996 continue
      K = MTEXTC
      IROW = IROW + 1
      if (IROW .ne. 0) then
         write(BUF(1:4), '(I4)') mod(IROW, 10000)
      else
         BUF(1:4) = ' '
      end if
      go to 50
  999 LENTRY = 1
      return
c
c                          Get started with vector or matrix output
 1000 LOCBEG = NIDAT
      XARG = M .gt. MEJMAT
      if (XARG) then
         M = M - 4
         LOCBEG = NFDAT
         if (.not. XARGOK) go to 40
      end if
      GOTFMT = M .gt. MEIMAT
      if (GOTFMT) M = M - 2
      MPT = LOCBEG
      if (M .eq. MEIMAT) go to 1300
c                           Take care of setup for vector output
      KNT = 0
      LASKNT = MACT(I+1)
      if (LASKNT .le. 0) then
         LASKNT = -LASKNT
         KNT = LOCBEG - 1
         if (LASKNT .le. KNT) go to 40
      end if
      IMAG = LASKNT
      LASTI = LOCBEG + LASKNT - 1 - KNT
      NCOL = 0
c                          Get format for label output.
      LENTRY = 7
      go to 800
 1020 FMTR = FMTI
      KDILAB = KDI+1
      LINSTR = 2*KDILAB+1
      LENTRY = 5
 1025 if (GOTFMT) then
         if (XARG) then
            IWF = IWG
            FMTF = FMTG
            if (LENTRY .eq. 5) go to 1060
            go to 1620
         end if
         KDI = KDJ
         FMTI = FMTJ
         if (LENTRY .eq. 5) go to 1070
         go to 1380
      end if
      if (XARG) return
 1030 K = 1
      IMAX = IDAT(LOCBEG)
      IMIN = IMAX
 1040 do 1050 J = LOCBEG, LASTI
         IMAX = max(IMAX, IDAT(J))
         IMIN = MIN(IMIN, IDAT(J))
 1050 continue
      if (NCOL .ne. 0) then
         K = K + 1
         LOCBEG = LOCBEG + NDIM
         LASTI = LASTI + NDIM
         if (K .le. NCOL) go to 1040
      end if
      IMAG = IMAX
      if (IMAG + 10*IMIN .le. 0) IMAG = IMIN
      KD = 2
      go to 810
c                                          After other format
 1060 LENOUT = IWF
      LENTRY = 7
      NFDAT = LASTI + 1
      go to 1080
c                                          After integer format
 1070 LENOUT = KDI
      NIDAT = LASTI + 1
c                                          Common code continues here
 1080 NLINE = (LENLIN - LINSTR + 1) / LENOUT
      if (LBUF .eq. 0) go to 1090
      K = max(LINSTR, LBUF+1)
      if (((K-LINSTR)/LENOUT + (LENLIN-K+1)/LENOUT) .lt. NLINE) K = K +
     1   LENOUT - mod(K-LINSTR, LENOUT)
      KLINE = (LENLIN - K + 1) / LENOUT
      if (KLINE .lt. min(LASKNT-KNT, NLINE/2)) go to 1140
      LINSTR = K - LENOUT * ((K - LINSTR) / LENOUT)
      if (KLINE .ge. LASKNT-KNT)  then
         KLINE = LASKNT - KNT
         K = LBUF + 1
      end if
      KNT = KNT + KLINE
      BUF(LBUF+1:K) = ' '
      LBUF = K
      go to 1110
 1090 BUF = ' '
      write (BUF(1:KDILAB), FMTR) KNT+1
      BUF(KDILAB:KDILAB) = '-'
      KLINE = min(NLINE, LASKNT - KNT)
      KNT = KNT + KLINE
      write (BUF(KDILAB+1:2*KDILAB), FMTR) KNT
      BUF(2*KDILAB:LINSTR-1) = ':'
      LBUF = LINSTR
 1110 LSTRT = LBUF
      LBUF = LBUF + LENOUT * KLINE - 1
      if (XARG) return
c                                    Integer output
      write (BUF(LSTRT:LBUF), FMTI) (IDAT(K), K = MPT, MPT+KLINE-1)
      MPT = MPT + KLINE
c
c                                     Entry here after vector output.
 1130 if (MPT .gt. LASTI) go to 40
 1140 assign 1090 to KGO
      go to 50
c
c                           Take care of setup for matrix output
 1300 NDIM = MACT(I+1)
      if (NDIM .le. 0) go to 40
      ICOL = 1
      IROW1 = 1
      NROW = MACT(I+2)
      if (NROW .le. 0) then
         if (NROW .eq. 0) go to 40
         IROW1 = -NROW / 100000
         NROW = -NROW - 99999 * IROW1 - 1
      end if
      NCOL = MACT(I+3)
      if (NCOL .le. 0) then
         if (NCOL .eq. 0) go to 40
         ICOL = -NCOL / 100000
         NCOL = -NCOL - 99999 * IROW1 - 1
      end if
      NTXTSV = NTEXT
      IRC = 1
c                        Compute widths for row and column labels
 1320 MAXWID(IRC) = 0
      MTEXT(IRC) = MACT(I+IRC+3)
      IMAG = NROCO(IRC)
      KLINE = IMAG
      LENTRY = 8
 1330 NTEXT = MTEXT(IRC)
      if (NTEXT .le. 0) then
         if (NTEXT .lt. 0) go to 1370
         L = 5
         go to 800
      end if
c                        Go get row/column widths
      KT = 2
      go to 1700
 1340 MTEXT(IRC) = 0
      go to 1330
 1350 MAXWID(IRC) = max(MAXWID(IRC), L - NTEXT + KDI)
      FMTIM(IRC) = FMTI
 1370 IRC = IRC + 1
      if (IRC .eq. 2) go to 1320
c                 Widths for Row and column titles have been computed.
      KSHIFT = 1
      LASTI = LOCBEG + NROW - IROW1
      LENTRY = 6
      if (GOTFMT) go to 1025
      if (XARG) return
      go to 1030
c
 1380 If (KDI .ge. KOLWID) then
         LENOUT = KDI
      else
         KSHIFT = (KOLWID - KDI + 2) /2
         LENOUT = KOLWID
         write (FMTI(5:6), '(I2)') KOLWID
      end if
      NIDAT = NIDAT + NDIM*NCOL
c                              Continue with commmon code
 1390 NLINE = (LENLIN - LINSTR) / LENOUT
      if (LBUF .le. LINSTR) go to 1420
 1400 assign 1420 to KGO
      go to 50
 1420 IROW = IROW1
      KLINE = min(NLINE, NCOL-ICOL+1)
c                       Output column labels (if any)
      if (MTEXTC .lt. 0) go to 1480
      NTEXT = MTEXTC
      KT = 3
      go to 1700
c                       Return from output of column labels.
 1470 MTEXTC = NTEXT
 1480 ICOL = ICOL + KLINE
 1490 assign 1500 to KGO
      go to 50
c
c                      Output row labels (if any)
 1500 if (MTEXTR .lt. 0) go to 1520
      if (MTEXTR .eq. 0) then
         BUF(LBUF+1:LBUF+4) = 'Row '
         LBUF = LBUF + 4
         go to 1515
      end if
      NTEXT = MTEXTR
c                     Go get text for row label
      NTEXTR = 0
      go to 410
c                     Return from getting text for row label
 1510 if (TEXT(NTEXT-1) .ne. 'M') then
         MTEXTR = NTEXT
         BUF(LBUF+1:LINSTR) = ' '
         go to 1520
      end if
 1515 write (BUF(LBUF+1:LINSTR), FMTR) IROW
 1520 LSTRT = LINSTR + 1
      LBUF = LINSTR + LENOUT*KLINE
      LASTI = MPT + NDIM * KLINE - 1
      if (XARG) return
c                                    Integer output
         write (BUF(LSTRT:LBUF), FMTI) (IDAT(K), K=MPT,LASTI,NDIM)
c                                    
c                                     Entry here after matrix output.
 1530 MPT = MPT + 1
      IROW = IROW + 1
c
      if (IROW .le. NROW) go to 1490
      if (ICOL .gt. NCOL) then
         NTEXT = NTXTSV
         go to 40
      end if
      MPT = NDIM*(ICOL-1) + 1
      MTEXTR = MACT(I+4)
      assign 1540 to KGO
      go to 50
 1540 LBUF = 1
      BUF(1:1) = ' '
      go to 1400
c                                Entry after got format for matrix print
 1620 If (IWF .ge. KOLWID) then
         LENOUT = IWF
      else
         KSHIFT = (KOLWID - IWF + 2) /2
         LENOUT = KOLWID
         write (FMTF(7:8), '(I2)') KOLWID
      end if
      NFDAT = NFDAT + NDIM*NCOL
      LENTRY = 8
      go to 1390
c
c Processing of multiple headings:
c     KT = 1 Output table headings
c     KT = 2 Get row/column widths for matrix output
c     KT = 3 Output column headings
c
 1700    do 1900 J = 1, max(1,KLINE)
            L = NTEXT
            if (L .eq. 0) then
               K = KOLWID
               go to 1810
            end if
 1710       do 1720 L = L, NTEXT + 80
               if (TEXT(L) .eq. SC) go to 1730
 1720       continue
            go to (180, 1340,  1470), KT
 1730       KSPEC = index('HM', TEXT(L+1))
            if (KSPEC .eq. 0) go to (1740, 1340, 180), KT
            go to (1750, 1780, 1800), KT
 1740       L = L + 1
            go to 1710
c       
 1750       if (KSPEC .eq. 2) go to 1740
            KOLWID = KOLWID + LENOUT
            if (L .ne. NTEXT) then
               KK = KOLWID-L+NTEXT
               if (XARG)  KK = 1 + KK/2
               LSTRT = LBUF + KK + 1
               LBUF = LBUF + KOLWID
               if (LBUF .le. LENLIN) MDAT(MTEXTC) = LBUF
               KOLWID = 0
               go to 1820
            else
               go to 1850
            end if
c
c                                     Set up column widths
 1780       if (KSPEC .eq. 2) go to 800
            MAXWID(IRC) = max(MAXWID(IRC), L - NTEXT)
            go to 1850
c
c                                     Output matrix column
 1800       K = KOLWID
            if (KSPEC .ne. 2) then
               K = L - NTEXT
            else
               KSPEC = 0
            end if
 1810       KK = LENOUT - KOLWID
            if (J .eq. 1) then
c                           Special setup for the first column.
               if (XARG) KK = (KK + 1) / 2
               KK = KK + KSHIFT + LINSTR - LBUF
            end if
            KK = KK + KOLWID - K
            LSTRT = LBUF + KK + 1
            LBUF = LSTRT + K - 1
c                                     Set initial blanks
 1820       if (KK .gt. 0) BUF(LSTRT-KK:LSTRT-1) = ' '
c                                     Move characters
            if (NTEXT .eq. 0) then
               BUF(LSTRT:LSTRT+3) = 'Col '
               KSPEC = 0
               KK = LSTRT+4
            else
               K = NTEXT - LSTRT
               do 1830 KK = LSTRT, L-K-1
                  BUF(KK:KK) = TEXT(K+KK)
 1830          continue
            end if
            if (KSPEC .eq. 0) then
c                                     Output column index
               write (BUF(KK:LBUF), FMTC) ICOL + J - 1
               go to 1900
            end if
c                                     Set trailing blanks
            if (KK .le. LBUF) BUF(KK:LBUF) = ' '
 1850       NTEXT = L + 2
 1900    continue
         go to (960, 1370, 1470), KT
      end

      block data XMESS
c For comments on these variables, see the listing for MESS.
c
      parameter (LNERR = 79)
      parameter (LNMSG = 128)
      parameter (LENBUF = 160)
      parameter (MEVBAS = 10)
      parameter (MEVLAS = 32)
      logical          XARGOK
      integer          EUNIT, IVAR(MEVBAS:MEVLAS), IWF, IWG, KDF,
     1   KDFDEF, KDIAG, KLINE, KSCRN, KSPEC, MAXERR, LASTI, LBUF,
     2   LENLIN, LENTRY, LHEAD, LINERR, LINMSG, LOCBEG, LPRINT, LSTOP,
     3   LSTRT, MDAT(5), MPT, MUNIT, NCOL, NDIM, NFDAT, NIDAT, NMDAT,
     4   NROW, NTEXT, OUNIT, SUNIT, TABSPA
c
      character BUF*(LENBUF), DOLS*72, FMTF*14, FMTG*14, FMTT*14
      common /CMESSI/ SUNIT, LHEAD, KDFDEF, LINMSG, LINERR, MUNIT,
     1   EUNIT, KSCRN, KDIAG, MAXERR, LSTOP, LPRINT, KDF, NTEXT,
     2   NIDAT, NFDAT, NMDAT, MDAT, TABSPA, IWF, IWG, KLINE,
     3   KSPEC, LASTI, LBUF, LENLIN, LENTRY, LOCBEG, LSTRT, MPT, NROW,
     4   NCOL, NDIM, OUNIT, XARGOK
      common /CMESSC / BUF, DOLS, FMTF, FMTG, FMTT
      equivalence (IVAR(MEVBAS), SUNIT)
      character   DOLE(72)
      equivalence (DOLS,DOLE)
c
      data EUNIT,KDFDEF,MAXERR,LSTOP,LHEAD,LPRINT,LINMSG,LINERR,MUNIT
     1   /     0,     0,     0,    3,    1,     3, LNMSG, LNERR,    0 /
      data KDF, LENLIN, LENTRY, OUNIT, SUNIT, TABSPA
     1  /    0,  LNMSG,      0,     0,    -1,      6 /
      data (DOLE(I), I = 1, 72) / 72*'$' /
      end

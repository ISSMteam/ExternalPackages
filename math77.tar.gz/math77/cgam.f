      SUBROUTINE  CGAM(CARG,CANS,ERREST,MODE)
C>> 1992-04-20 CGAM CLL Edited comments.
C>> 1991-11-11 CGAM CLL Made [Z/C]GAM from CDLGAM
C>> 1991-01-16 CDLGAM Lawson  Removing use of subr D2MACH.
C>> 1985-08-02 CDLGAM Lawson  Initial code.
C 
C *** COMPLEX GAMMA AND LOGGAMMA FUNCTIONS WITH ERROR ESTIMATE
C 
C     -----------------------------------------------------------------
C     SUBROUTINE ARGUMENTS
C     --------------------
C     CARG()   A complex argument, given as an array of 2 floating-point
c              elements consisting of the real component
c              followed by the imaginary component.
c 
c     CANS()   The complex answer, stored as an array of 2
c              floating-point numbers, representing the real and
c              imaginary parts.
c 
c     ERREST   On output ERREST gives an estimate of the absolute
c              (for LOGGAMMA) or the relative (for GAMMA) error
c              of the answer.
c 
c     MODE     Selects function to be computed.  set it to 0 for
c              LOGGAMMA, and 1 for GAMMA.
C     -----------------------------------------------------------------
C     MACHINE DEPENDANT PARAMETERS
C     If the fraction part of a floating point number
C     contains T digits using base B then
C         EPS3  = B ** (-T)
C         EPS4  = B ** (-T+1)
C         OMEGA = overflow limit
C         DESET = 5.0 on a binary machine
C               = 2.0 on a base 16 machine
C     -----------------------------------------------------------------
C     REFERENCE: H.KUKI, Comm.ACM, Vol.15, (1972),
C     pp.262-267, 271-272.  Subroutine name was CDLGAM.
C     Code developed for UNIVAC 1108 by E.W.NG, JPL, 1969.
C     Modified for FORTRAN 77 portability by C.L.LAWSON &
C     S.CHAN, JPL, 1983.
c     -----------------------------------------------------------------
c--   D version uses ZGAM, D1MACH, DERM1, DERV1, dble
c--   S version uses CGAM, R1MACH, SERM1, SERV1, real
c     Both versions use I1MACH
c     -----------------------------------------------------------------
      real CARG(2),CANS(2),COEF(7),F0,F1,G0,G1,
     $    PI,TWOPI,HL2P,AL2P,DELTA,DE0,DE1,Z1,Z2,ZZ1,W1,W2,W3,Y1,
     $    A,B,U,U1,U2,UU1,UU2,UUU1,UUU2,V1,V2,VV1,VV2,T1,T2,
     $    H,H1,H2,AL1,AL2,DN,EPS4,OMEGA,ERREST
      real ONE, ZERO, R1MACH, EPS3, REPS3, ELIMIT, CUT1
      real DESET
      integer I1MACH, J, K, LF1, LF2, LF3, MODE, MULT, N
      logical FIRST
C 
      SAVE FIRST,OMEGA,EPS4,EPS3,REPS3,CUT1,DESET,ELIMIT
C 
      parameter(ONE = 1.0E0, ZERO = 0.0E0)
      parameter(F0 = 840.07385296052619E0, F1 = 20.001230821894200E0)
      parameter(G0 = 1680.1477059210524E0, G1 = 180.01477047052042E0)
      parameter(PI = 3.14159265358979323846E0)
      parameter(TWOPI = 6.283185307179586476925E0)
      parameter(HL2P = 0.918938533204672742E0)
      parameter(AL2P = 1.83787706640934548E0)
      DATA FIRST/.TRUE./
      DATA COEF(1)/+0.641025641025641026E-2/
      DATA COEF(2)/-0.191752691752691753E-2/
      DATA COEF(3)/+0.841750841750841751E-3/
      DATA COEF(4)/-0.595238095238095238E-3/
      DATA COEF(5)/+0.793650793650793651E-3/
      DATA COEF(6)/-0.277777777777777778E-2/
      DATA COEF(7)/+0.833333333333333333E-1/
c     ------------------------------------------------------------------
      IF (FIRST) THEN
        FIRST = .FALSE.
        OMEGA = R1MACH(2)
        EPS3  = R1MACH(3)
        EPS4  = R1MACH(4)
        REPS3 = ONE / EPS3
        ELIMIT = log(OMEGA)
        CUT1  = log(EPS3)
          IF (I1MACH(10) .EQ. 2) THEN
            DESET = 5.E0
          ELSE
            DESET = 2.E0
          ENDIF
      ENDIF
      DE0 = DESET
      DE1 = ZERO
      Z1 = CARG(1)
      Z2 = CARG(2)
C 
C *** Setting DELTA = estimate of uncertainty level of
C                     argument data.
C 
      DELTA = EPS4 * (abs(Z1) + abs(Z2))
      IF (DELTA .EQ. ZERO) DELTA = EPS4
C 
C *** FORCE SIGN OF IMAGINARY PART OF ARG TO NON-NEGATIVE
C 
      LF1 = 0
      IF (Z2 .GE. ZERO) GO TO 20
      LF1 = 1
      Z2 = -Z2
   20 LF2 = 0
      IF (Z1 .GE. ZERO) GO TO 100
C 
C *** CASE WHEN REAL PART OF ARG IS NEGATIVE
C 
      LF2 = 1
      LF1 = LF1-1
      T1 = AL2P - PI*Z2
      T2 = PI*(0.5E0 - Z1)
      U  = -TWOPI*Z2
      IF (U .GE. -0.1054E0) GO TO 40
      A  = ZERO
C 
C *** IF EXP(U) .LE. EPS3, IGNORE IT TO SAVE TIME AND TO AVOID
C     IRRELEVANT UNDERFLOW
C 
      IF (U .LE. CUT1) GO TO 30
      IF (U .GT. ELIMIT) GO TO 550
      A  = exp(U)
   30 H1 = ONE - A
      GO TO 50
   40 U2 = U * U
      A  = -U*(F1*U2 + F0)
      H1 = (A + A)/((U2 + G1)*U2 + G0 + A)
      A  = ONE - H1
   50 B  = Z1 - aint(Z1 - 0.5E0)
      H2 = A*sin(TWOPI*B)
      B  = sin(PI*B)
      H1 = H1 + (B+B)*B*A
      H  = abs(H2) + H1 - TWOPI*A*DELTA
      IF (H .LE. ZERO) GO TO 500
      DE0 = DE0 + abs(T1) + T2
      DE1 = PI + TWOPI*A/H
      Z1 = ONE - Z1
C 
C *** CASE WHEN NEITHER REAL PART NOR IMAGINARY PART OF ARG IS
C     NEGATIVE.  DEFINE THRESHOLD CURVE TO BE THE BROKEN LINES
C     CONNECTING POINTS 10F0*I, 10F4.142*I, 0.1F14.042*I,AND
C     0.1FOMEGA*I
C 
  100 LF3 = 0
      Y1 = Z1 - 0.5E0
      W1 = ZERO
      W2 = ZERO
      K  = 0
      B  = max(0.1E0, min(10.0E0, 14.142E0-Z2)) - Z1
      IF (B .LE. ZERO) GO TO 200
C 
C *** CASE WHEN REAL PART OF ARG IS BETWEEN 0 AND THRESHOLD
C 
      LF3 = 1
      ZZ1 = Z1
      N  = B + ONE
      DN = N
      Z1 = Z1 + DN
      A  = Z1*Z1 + Z2*Z2
      V1 = Z1/A
      V2 = -Z2/A
C 
C *** INITIALIZE U1+U2*I AS THE RIGHTMOST FACTOR 1-1/(Z+N)
C 
      U1 = ONE - V1
      U2 = -V2
      K  = 6.0E0 - Z2*0.6E0 - ZZ1
      IF (K .LE. 0) GO TO 120
C 
C *** FORWARD ASSEMBLY OF FACTORS (Z+J-1)/(Z+N)
C 
      N  = N - K
      UU1 = (ZZ1*Z1 + Z2*Z2) / A
      UU2 = DN*Z2/A
      VV1 = ZERO
      VV2 = ZERO
      DO 110  J = 1,K
        B  = U1*(UU1+VV1) - U2*(UU2+VV2)
        U2 = U1*(UU2+VV2) + U2*(UU1+VV1)
        U1 = B
        VV1 = VV1 + V1
  110   VV2 = VV2 + V2
  120 IF (N .LE. 1) GO TO 140
C 
C *** BACKWARD ASSEMBLY OF FACTORS 1-J/(Z+N)
C 
      VV1 = V1
      VV2 = V2
      DO 130  J = 2,N
        VV1 = VV1 + V1
        VV2 = VV2 + V2
        B  = U1*(ONE - VV1) + U2*VV2
        U2 = -U1*VV2 + U2*(ONE - VV1)
  130   U1 = B
  140 U  = U1*U1 + U2*U2
      IF (U .EQ. ZERO) GO TO 500
      IF (MODE .EQ. 0) GO TO 150
      IF (K .LE. 0) GO TO 200
  150 AL1 = log(U)*0.5E0
      IF (MODE .NE. 0) GO TO 160
      W1 = AL1
      W2 = atan2(U2,U1)
      IF (W2 .LT. ZERO)  W2 = W2 + TWOPI
      IF (K .LE. 0) GO TO 200
  160 A  = ZZ1 + Z2 - DELTA
      IF (A .LE. ZERO) GO TO 500
      DE0 = DE0 - AL1
      DE1 = DE1 + 2.0E0 + ONE/A
C 
C *** CASE WHEN REAL PART OF ARG IS GREATER THAN THRESHOLD
C 
  200 A  = Z1*Z1 + Z2*Z2
      AL1 = log(A)*0.5E0
      AL2 = atan2(Z2,Z1)
      V1 = Y1*AL1 - Z2*AL2
      V2 = Y1*AL2 + Z2*AL1
C 
C *** Evaluate asymptotic terms. Ignore this term,
C     if ABS(ARG)**2 .GT. REPS3, to save time and
C     to avoid irrelevant underflow.
C 
      VV1 = ZERO
      VV2 = ZERO
      IF (A .GT. REPS3) GO TO 220
      UU1 = Z1/A
      UU2 = -Z2/A
      UUU1 = UU1*UU1 - UU2*UU2
      UUU2 = UU1*UU2*2.0E0
      VV1 = COEF(1)
      DO 210  J = 2,7
        B  = VV1*UUU1 - VV2*UUU2
        VV2 = VV1*UUU2 + VV2*UUU1
  210   VV1 = B + COEF(J)
      B  = VV1*UU1 - VV2*UU2
      VV2 = VV1*UU2 + VV2*UU1
      VV1 = B
  220 W1 = (((VV1 + HL2P) - W1) - Z1) + V1
      W2 = ((VV2 - W2) - Z2) + V2
      DE0 = DE0 + abs(V1) + abs(V2)
      IF (K .LE. 0)  DE1 = DE1 + AL1
C FINAL ASSEMBLY
      IF (LF2 .NE. 0) GO TO 310
      IF (MODE .EQ. 0) GO TO 400
      IF (W1 .GT. ELIMIT) GO TO 550
      A  = exp(W1)
      W1 = A*cos(W2)
      W2 = A*sin(W2)
      IF (LF3 .EQ. 0) GO TO 400
      B  = (W1*U1 + W2*U2) / U
      W2 = (W2*U1 - W1*U2) / U
      W1 = B
      GO TO 400
  310 H  = H1*H1 + H2*H2
      IF (H .EQ. ZERO) GO TO 500
      IF (MODE .EQ. 0) GO TO 320
      IF (H .GT. 1.0E-2) GO TO 330
  320 A  = log(H)*0.5E0
      IF (H .LE. 1.0E-2)  DE0 = DE0 - A
      IF (MODE .NE. 0) GO TO 330
      W1 = (T1 - A) - W1
      W2 = (T2 - atan2(H2,H1)) - W2
      GO TO 400
  330 T1 = T1 - W1
      T2 = T2 - W2
      A  = exp(T1)
      IF (T1 .GT. ELIMIT) GO TO 550
      T1 = A*cos(T2)
      T2 = A*sin(T2)
      W1 = (T1*H1 + T2*H2)/H
      W2 = (T2*H1 - T1*H2)/H
      IF (LF3 .EQ. 0) GO TO 400
      B  = W1*U1 - W2*U2
      W2 = W1*U2 + W2*U1
      W1 = B
  400 IF (LF1 .NE. 0)  W2 = -W2
C 
C *** TRUNCATION ERREST OF STIRLINGS FORMULA IS UP TO EPS3.
C 
      DE1 = DE0*EPS4 + EPS3 + DE1*DELTA
      GO TO 600
C 
C *** CASE WHEN ARGUMENT IS TOO CLOSE TO A SINGULARITY
C 
  500 CONTINUE
      CALL SERM1('CGAM',1,0,'Z TOO CLOSE TO A SINGULARITY',
     *           'Z(1)',CARG(1),',')
      CALL SERV1('Z(2)',CARG(2),'.')
      GO TO 580
C 
  550 CONTINUE
      CALL SERM1('CGAM',2,0,'ARG TOO LARGE. EXP FUNCTION OVERFLOW',
     *           'Z(1)',CARG(1),',')
      CALL SERV1('Z(2)',CARG(2),'.')
c                                           Error termination.
  580 continue
      CANS(1) = OMEGA
      CANS(2) = OMEGA
      ERREST = OMEGA
      return
c                                      Normal termination.
  600 continue
c 
c     The imaginary part of the log of a complex number is nonunique
c     to within multiples of 2*Pi.  We prefer a result for loggamma
c     having its imaginary part .gt. -Pi and .le. +Pi.  The result at
c     this point is usually in this range.  If not we will move it
c     into this range.  -- CLL 11/11/91
c 
      if(MODE .eq. 0) then
         if(W2 .le. -PI .or. W2 .gt. PI) then
            W3 = abs(W2)
            MULT = (int(W3/PI) + 1) / 2
            W3 = W3 - real(MULT) * TWOPI
            if(W2 .ge. 0.0e0) then
               W2 = W3
            else
               W2 = -W3
            endif
            if(W2 .le. -PI) then
               W2 = W2 + TWOPI
            elseif(W2 .gt. PI) then
               W2 = W2 - TWOPI
            endif
         endif
      endif
      CANS(1) = W1
      CANS(2) = W2
      ERREST = DE1
      return
      end

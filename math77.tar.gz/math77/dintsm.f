      DOUBLE PRECISION FUNCTION DINTSM (SXMIN)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C     $.TYPE.$ FUNCTION $L1$INTSM (SXMIN)
C>> 1987-11-17 DINTSM Lawson  Initial code.
C
C     CALCULATE THE MINIMUM STEPSIZE TO USE IF ALOCAL WERE SET EQUAL TO
C     SXMIN.
C                                                                       00001000
C     WRITE X = TA + (T-TA)**2/TB.  IF WE LET X2 - X1 BE THE SMALLEST
C     ALLOWED STEP AT X1, SAY SMIN, THEN
C     TB*(X2-X1) = TB*SMIN = (T2-TA)**2 - (T1-TA)**2, OR
C     TB*SMIN = (T2-T1)*(T2-T1+2*(T1-TA)).  SOLVING FOR T2-T1 PROVIDES
C     THE EXPRESSIONS IN THE CODE BELOW.  THE ANALYSIS PROCEEDS
C     SIMILARLY WHEN X = TA + (T-TA)**4/TB**3.
C
C     $.TYPE.$ SXMIN
      DOUBLE PRECISION SXMIN
C                                                                       00002000
C     *****     SPECIALIZER VARIABLES     ******************************
C
C     SPECIALIZER VARIABLES ARE ALL DEFINED IN $L1$INTOP.
C
C     *****     LOCAL VARIABLES     ************************************
C
C SG      IS A TEMPORARY VARIABLE
C     $.TYPE.$ SG
      DOUBLE PRECISION SG
C SMIN    IS THE VALUE THAT WILL BE RETURNED AS THE MINIMUM STEPSIZE.   00003000
C     $.TYPE.$ SMIN
      DOUBLE PRECISION SMIN
C SOLVE   IS AN ARITHMETIC STATEMENT FUNCTION DEFINED BELOW.
C     $.TYPE.$ SOLVE
      DOUBLE PRECISION SOLVE
C SQRTTB  IS SQRT(ABS(TB))
C     $.TYPE.$ SQRTTB
      DOUBLE PRECISION SQRTTB
C SX      IS A LOCAL COPY OF SXMIN.
C     $.TYPE.$ SX                                                       00004000
      DOUBLE PRECISION SX
C TDECR   IS AN ARITHMETIC STATEMENT FUNCTION DEFINED BELOW.
C     $.TYPE.$ TDECR
      DOUBLE PRECISION TDECR
C
C     *****     COMMON VARIABLES     ***********************************
C
C     COMMON /$L1$INTNC/ CONTAINS VARIABLES NOT SEPARATELY SAVED FOR
C     EACH DIMENSION OF A MULTIPLE QUADRATURE.  COMMON /$L1$INTC/
C     CONTAINS VARIABLES THAT MUST BE SAVED FOR EACH DIMENSION OF THE   00004800
C     QUADRATURE.  THE VARIABLES IN EACH COMMON BLOCK ARE STORED IN THE
C     ORDER - ALWAYS DOUBLE, DOUBLE IF DOUBLE PRECISION PROGRAM, DOUBLE
C     IF DOUBLE PRECISION PROGRAM AND EXPONENT RANGE OF DOUBLE AND
C     SINGLE VERY DIFFERENT, SINGLE, INTEGER, LOGICAL.  A PAD OF LOGICAL
C     VARIABLES IS INCLUDED AT THE END OF /$L1$INTC/.  THE DIMENSION OF
C     THE PAD MAY NEED TO BE VARIED SO THAT NO VARIABLES BEYOND THE END
C     OF THE COMMON BLOCK ARE ALTERED.
C
C     DECLARATIONS OF COMMON /$L1$INTNC/ VARIABLES.
C                                                                       00004800
C     $.TYPE.$ AINIT, BINIT, FNCVAL, S, TP
      double precision AINIT, BINIT, FNCVAL, S, TP
C     $DSTYP$  FER, FER1, RELOBT, TPS, XJ, XJP
      double precision FER, FER1, RELOBT, TPS, XJ, XJP
      INTEGER     FEA,       FEA1,      INC,       INC2,      IPRINT,   
     * ISTOP(2,2),JPRINT,    KDIM,      KK,        KMAXF,     NDIM,     
     * NFINDX,    NFMAX,     NFMAXM,    OUT,       RELTOL,    REVERM,   
     * REVERS,    WHEREM
      LOGICAL NEEDH
C
C     DECLARATIONS OF COMMON /$L1$INTC/ VARIABLES.
C
C     4 DOUBLE PRECISION VARIABLES                                      00004800
      DOUBLE PRECISION ACUM, PACUM, RESULT(2)
C     139 $.TYPE.$ VARIABLES
C     $.TYPE.$
      DOUBLE PRECISION                                                  
     * AACUM,     ABSCIS,    DELMIN,    DELTA,     DIFF,      DISCX(2), 
     * END(2),    ERRINA,    ERRINB,    FAT(2),    FSAVE,               
     * FUNCT(24), F1,        F2,        LOCAL(4),  PAACUM,    PF1,      
     * PF2,       PHISUM,    PHTSUM,    PX,        SPACE(6),            
     * STEP(2),   START(2),  SUM,       T,         TA,        TASAVE,   
     * TB,        TEND,      WORRY(2),  X,         X1,                  
     * X2,        XT(17),    FT(17),    PHI(34)
c Note XT, FT, and PHI above are last, because they must be in adjacent
c locations in DINTO.
C     30 $DSTYP$ VARIABLES
C     $DSTYP$
      DOUBLE PRECISION                                                  
     * ABSDIF,    COUNT,     EDUE2A,    EDUE2B,    EP,        EPNOIZ,   
     * EPS,       EPSMAX,    EPSMIN,    EPSO,      EPSR,      EPSS,     
     * ERR,       ERRAT(2),  ERRC,      ERRF,      ERRI,      ERRT(2),  
     * ESOLD,     EXTRA,     PEPSMN,    RE,        RELEPS,    REP,      
     * REPROD,    RNDC,      TLEN,      XJUMP
C     29 INTEGER VARIABLES                                              00004800
      INTEGER     DISCF,     DISCHK,    ENDPTS,    I,         INEW,     
     * IOLD,      IP,        IXKDIM,    J,         J1,        J1OLD,    
     * J2,        J2OLD,     K,         KAIMT,     KMAX,      KMIN,     
     * L,         LENDT,     NFEVAL,    NFJUMP,    NSUB,      NSUBSV,   
     * NXKDIM,    PART,      SEARCH,    TALOC,     WHERE,     WHERE2
C     11 TO 18 LOGICALS (7 ARE PADDING).
      LOGICAL     DID1,      FAIL,      FATS(2),   FSAVED,    HAVDIF,   
     * IEND,      INIT,      ROUNDF,    XCDOBT(2), PAD(7)
C
C     THE COMMON BLOCKS.
C
C     COMMON /$L1$INTNC/
      COMMON /DINTNC/                                                   
     * AINIT,  BINIT,  FNCVAL, S,      TP,     FER,    FER1,   RELOBT,  
     * TPS,    XJ,     XJP,    FEA,    FEA1,   KDIM,    INC,    INC2,   
     * ISTOP,  JPRINT, IPRINT, KK,     KMAXF,  NDIM,   NFINDX, NFMAX,   
     * NFMAXM, OUT,    RELTOL, REVERM, REVERS, WHEREM, NEEDH
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    00004800
     * ACUM,   PACUM,  RESULT
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * AACUM,  LOCAL,  ABSCIS, TA,     DELTA,  DELMIN, DIFF,   DISCX,   
     * END,    ERRINA, ERRINB, FAT,    FSAVE,  FUNCT,  F2,              
     * PAACUM, PF1,    PF2,    PHISUM, PHTSUM, PX,     SPACE,           
     * STEP,   START,  SUM,    T,      TASAVE, TB,     TEND,            
     * WORRY,  X1,     X2,     X,      F1,     COUNT,                   
     * XT, FT, PHI
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * ABSDIF, EDUE2A, EDUE2B, EP,     EPNOIZ, EPSMAX,                  
     * EPSO,   EPSR,   EPSS,   ERRAT,  ERRC,   ERRF,                    
     * ERRT,   ESOLD,  EXTRA,  PEPSMN, RELEPS, REP,                     
     * RNDC,   TLEN,   XJUMP,                                           
     * ERRI,   ERR,    EPSMIN, EPS,    RE,     REPROD
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * DISCF,  DISCHK, ENDPTS, INEW,   IOLD,   IP,     IXKDIM,          
     * J,      J1,     J1OLD,  J2,     J2OLD,  KMAX,                    
     * KMIN,   L,      LENDT,  NFEVAL, NFJUMP, NSUBSV, NXKDIM,          
     * TALOC,  WHERE2,                                                  
     * I,      K,      KAIMT,  NSUB,   PART,   SEARCH, WHERE
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * DID1,   FAIL,   FATS,   FSAVED, HAVDIF, IEND,   INIT,   ROUNDF,  
     * XCDOBT, PAD
C     SAVE /$L1$INTNC/, /$L1$INTC/
      SAVE /DINTNC/, /DINTC/                                            00004800
C
C $   COL1(PORT)
C.    THE VARIABLES HERE DEFINE THE MACHINE ENVIRONMENT.  ALL ARE SET
C.    IN $L1$INTOP.  THE MEANING ATTACHED TO THESE VARIABLES CAN BE
C.    FOUND BY LOOKING AT THE RELATED SPECIALIZER VARIABLES DEFINED IN
C.    $L1$INTOP.
      DOUBLE PRECISION EDMEPS
C     $.TYPE.$
      DOUBLE PRECISION                                                  
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     COMMON /$L1$INTEC/                                                00005000
      COMMON /DINTEC/                                                   
     *  EDMEPS,                                                         
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     SAVE /$L1$INTEC/
      SAVE /DINTEC/
C $   COL1(PORT, 0)
C
C     *****     STATEMENT FUNCTIONS     ********************************
C
C SOLVE   PROVIDES THE SOLUTION OF A QUADRATIC EQUATION.
      SOLVE(SX,SG)=SQRTTB*SX/(SG*SQRTTB+SQRT(ABS(TB)*SG*SG+SX))
C TDECR   IS USED TO TRANSFORM AN ABSCISSA FROM THE CURRENT COORDINATE  00005600
C         SYSTEM TO ONE IN WHICH NSUB IS DECREMENTED BY A FACTOR OF 2.
C     TDECR(SX)=TA+(SX-TA)*((SX-TA)/TB)
      TDECR(SX)=TA*(1.0+TA/TB)+SX*((SX-TA)/TB-TA/TB)
C
C     *****     EXECUTABLE STATEMENTS     ******************************
C
      SX=SXMIN
      IF(NSUB.EQ.0)THEN
C        SMIN=$MEPS$*MAX($DELM1$,ABS(SX))
         SMIN=EMEPS*MAX(EDELM1,ABS(SX))                                 00006600
      ELSE
         SQRTTB=SQRT(ABS(TB))
         SX=TDECR(SX)
      IF(NSUB.EQ.2)THEN
C           SMIN=$MEPS$*MAX($DELM1$,ABS(SX))
            SMIN=EMEPS*MAX(EDELM1,EDELM1*ABS(TB),ABS(SX))
            SG=ABS((SX-TA)/TB)
            SMIN=SOLVE(SMIN,SG)
      ELSE
            SX=TDECR(SX)                                                00007600
C           SMIN=2.0*$MEPS$*MAX($DELM1$,ABS(SX))
            SMIN=2.0*EMEPS*MAX(EDELM1,EDELM1*ABS(TB),ABS(SX))
            SG=ABS((SX-TA)/TB)
            SMIN=SOLVE(SMIN,SG*SG)
            SMIN=SOLVE(SMIN,SG)
      END IF
      END IF
C     $L1$INTSM=$DELM2$*SMIN
      DINTSM=EDELM2*SMIN
C                                                                       00008600
      RETURN
C
      END

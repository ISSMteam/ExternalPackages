      DOUBLE PRECISION FUNCTION DERF (X)
C>> 1991-01-14 CLL Changed to use generic names: abs and sign.
C>> 1990-11-29 CLL
c>> 1989-08-16 DERF   CLL  Changes for Cray
C>> 1986-03-18 DERF   Lawson  Initial code.
C
C     JULY 1977 EDITION. W.FULLERTON, C3,
C     LOS ALAMOS SCIENTIFIC LAB.
C
C     REORGANIZATION OF FULLERTON'S DERF & DERFC                        00001000
C     C.L.LAWSON & S.CHAN, JUNE 2 ,1983, JPL.
C     1989-06-30 CLL Added more digits in PII.  Editing order of data
c     stmts so SERF and DERF are more similar.
c     When DERFC is called with 0.5 .lt. X .le. 1.0 the original code
c     computed erfc from erfce, computing erfce from Cody's rational
c     formula whose coeffs (PS() and QS()) are only given to 18 decimal
c     digits.  For Cray D.P. of 29D precision we can do better by
c     computing DERFC as 1 - erf in this interval, since the coeffs for
c     DERF are good up to 30D.
c     With this change DERFC will also be good up to 30 or 29D for all  00002000
c     X up to XMAX, where it would underflow.
c     We compute DERFCE only for X .ge. 0.  DERFCE is computed from
c     DERF in [0, 1] and from DERFC in [1, XMAX] and so is good to
c     about 30D there.  For X > XMAX we use the Cody rational
c     approximations for DERFCE which have coeffs good only to 18D.
c     Added variable EPS3.
C     ------------------------------------------------------------------
C     MACHINE DEPENDENT VALUES ARE SET ON THE FIRST ENTRY
C     TO THIS CODE. EXAMPLES OF THESE VALUES FOLLOW:
C                                                                       00003000
C     SYSTEM         NTERF   NTERFC   NTERC2   SQEPS   XBIG   XMAX
C     ------         -----   ------   ------   -----   ----   ----
c     IEEE   S.P.      7        9       10    .34E-3   4.01    9.18
c     IEEE   D.P.     12       25       24    .15E-7   6.01   26.53
C     UNIVAC S.P.      8       11       11    .12E-3   4.26   9.29
C     UNIVAC D.P.     14       30       27    .13D-8   6.40   26.58
c     Cray   S.P.     11       21       21    .12E-6   5.66   75.30
c     Cray   D.P.     19       55       45    .10D-13  8.04   74.89
C
c     The above values are derived from the following values:           00004000
C
C     SYSTEM         R1MACH(1)   R1MACH(3)   D1MACH(1)   D1MACH(3)
C     ------         ---------   ---------   ---------   ---------
c     IEEE           2**(-126)   2**(-24)    2**(-1022)  2**(-53)
c     VAX            2**(-128)   2**(-27)    2**(-128)   2**(-56)
c     UNIVAC         2**(-129)   2**(-27)    2**(-1025)  2**(-60)
C     Cray           2**(-8190)  2**(-47)    2**(-8100)  2**(-94)
C
C     ------------------------------------------------------------------
c--   D version uses DERF, DERFC, DERFCE, DINITS, DCSEVL, D1MACH,DERM1  00005000
c--   S version uses SERF, SERFC, SERFCE, SINITS, SCSEVL, R1MACH,SERM1
c     ------------------------------------------------------------------
      integer NTERC2, NTERF, NTERFC
 
      double precision D1MACH, DCSEVL, DERFC, DERFCE
      double precision CUT2, CUT3, EIGHT
      double precision EPS3, ERFCS(21), ERFCCS(59), ERC2CS(49), ETA
      double precision FAC, FIVE, FOUR
      double precision HALF, ONE, PII, PL(6), PS(9), PSUM
      double precision QL(6), QS(10), QSUM                              00006000
      double precision SQEPS, SQRTPI, THREE, TWO, U
      double precision X, XBIG, XMAX, Y, YSQ, ZERO
C
      SAVE EPS3,NTERF,NTERFC,NTERC2,SQEPS,XBIG,XMAX
C
      parameter(ZERO = 0.0D0, HALF = 0.5D0, ONE = 1.0D0)
      parameter(TWO = 2.0D0, THREE = 3.0D0)
      parameter(FOUR = 4.0D0, FIVE = 5.0D0, EIGHT = 8.0D0)
      parameter(SQRTPI = 1.77245 38509 05516 02729 81674 83341 14518D0)
C                                                                       00007000
C          PII = 1/sqrt(PI)
      parameter(PII = 0.56418 95835 47756 28694 80794 51560 77258D0)
C
C          FAC = 2/sqrt(PI)
      parameter(FAC = 1.12837 91670 95512 57389 61589 03121 54516D0)
C
C          CUT1 = 15 / 32 = 0.46875D0 is not used in the DP version.
c          CUT2 = 4.0
C          CUT3 = 10.**16 WILL BE SATISFACTORY FOR ALL
C          MACHINES HAVING RELATIVE PRECISION LESS                      00008000
C          THAN 32 DECIMAL PLACES AND OVERFLOW LIMIT
C          GREATER THAN 10.**32
      parameter(CUT2 = 4.0D0, CUT3 = 1.0D16)
c
      DATA NTERF / 0 /
C
C SERIES FOR ERF        ON THE INTERVAL  0.          TO  1.00000E+00
C                                        WITH WEIGHTED ERROR   1.28E-32
C                                         LOG WEIGHTED ERROR  31.89
C                               SIGNIFICANT FIGURES REQUIRED  31.05     00009000
C                                    DECIMAL PLACES REQUIRED  32.55
C
      DATA ERF CS(  1) / -.4904612123 4691808039 9845440333 76 D-1     /
      DATA ERF CS(  2) / -.1422612051 0371364237 8247418996 31 D+0     /
      DATA ERF CS(  3) / +.1003558218 7599795575 7546767129 33 D-1     /
      DATA ERF CS(  4) / -.5768764699 7674847650 8270255091 67 D-3     /
      DATA ERF CS(  5) / +.2741993125 2196061034 4221607914 71 D-4     /
      DATA ERF CS(  6) / -.1104317550 7344507604 1353812959 05 D-5     /
      DATA ERF CS(  7) / +.3848875542 0345036949 9613114981 74 D-7     /
      DATA ERF CS(  8) / -.1180858253 3875466969 6317518015 81 D-8     /00010000
      DATA ERF CS(  9) / +.3233421582 6050909646 4029309533 54 D-10    /
      DATA ERF CS( 10) / -.7991015947 0045487581 6073747085 95 D-12    /
      DATA ERF CS( 11) / +.1799072511 3961455611 9672454866 34 D-13    /
      DATA ERF CS( 12) / -.3718635487 8186926382 3168282094 93 D-15    /
      DATA ERF CS( 13) / +.7103599003 7142529711 6899083946 66 D-17    /
      DATA ERF CS( 14) / -.1261245511 9155225832 4954248533 33 D-18    /
      DATA ERF CS( 15) / +.2091640694 1769294369 1705002666 66 D-20    /
      DATA ERF CS( 16) / -.3253973102 9314072982 3641600000 00 D-22    /
      DATA ERF CS( 17) / +.4766867209 7976748332 3733333333 33 D-24    /
      DATA ERF CS( 18) / -.6598012078 2851343155 1999999999 99 D-26    /00011000
      DATA ERF CS( 19) / +.8655011469 9637626197 3333333333 33 D-28    /
      DATA ERF CS( 20) / -.1078892517 7498064213 3333333333 33 D-29    /
      DATA ERF CS( 21) / +.1281188399 3017002666 6666666666 66 D-31    /
C
C SERIES FOR ERC2       ON THE INTERVAL  2.50000E-01 TO  1.00000E+00
C                                        WITH WEIGHTED ERROR   2.67E-32
C                                         LOG WEIGHTED ERROR  31.57
C                               SIGNIFICANT FIGURES REQUIRED  30.31
C                                    DECIMAL PLACES REQUIRED  32.42
C                                                                       00012000
      DATA ERC2CS(  1) / -.6960134660 2309501127 3915082619 7 D-1      /
      DATA ERC2CS(  2) / -.4110133936 2620893489 8221208466 6 D-1      /
      DATA ERC2CS(  3) / +.3914495866 6896268815 6114370524 4 D-2      /
      DATA ERC2CS(  4) / -.4906395650 5489791612 8093545077 4 D-3      /
      DATA ERC2CS(  5) / +.7157479001 3770363807 6089414182 5 D-4      /
      DATA ERC2CS(  6) / -.1153071634 1312328338 0823284791 2 D-4      /
      DATA ERC2CS(  7) / +.1994670590 2019976350 5231486770 9 D-5      /
      DATA ERC2CS(  8) / -.3642666471 5992228739 3611843071 1 D-6      /
      DATA ERC2CS(  9) / +.6944372610 0050125899 3127721463 3 D-7      /
      DATA ERC2CS( 10) / -.1371220902 1043660195 3460514121 0 D-7      /00013000
      DATA ERC2CS( 11) / +.2788389661 0071371319 6386034808 7 D-8      /
      DATA ERC2CS( 12) / -.5814164724 3311615518 6479105031 6 D-9      /
      DATA ERC2CS( 13) / +.1238920491 7527531811 8016881795 0 D-9      /
      DATA ERC2CS( 14) / -.2690639145 3067434323 9042493788 9 D-10     /
      DATA ERC2CS( 15) / +.5942614350 8479109824 4470968384 0 D-11     /
      DATA ERC2CS( 16) / -.1332386735 7581195792 8775442057 0 D-11     /
      DATA ERC2CS( 17) / +.3028046806 1771320171 7369724330 4 D-12     /
      DATA ERC2CS( 18) / -.6966648814 9410325887 9586758895 4 D-13     /
      DATA ERC2CS( 19) / +.1620854541 0539229698 1289322762 8 D-13     /
      DATA ERC2CS( 20) / -.3809934465 2504919998 7691305772 9 D-14     /00014000
      DATA ERC2CS( 21) / +.9040487815 9788311493 6897101297 5 D-15     /
      DATA ERC2CS( 22) / -.2164006195 0896073478 0981204700 3 D-15     /
      DATA ERC2CS( 23) / +.5222102233 9958549846 0798024417 2 D-16     /
      DATA ERC2CS( 24) / -.1269729602 3645553363 7241552778 0 D-16     /
      DATA ERC2CS( 25) / +.3109145504 2761975838 3622741295 1 D-17     /
      DATA ERC2CS( 26) / -.7663762920 3203855240 0956671481 1 D-18     /
      DATA ERC2CS( 27) / +.1900819251 3627452025 3692973329 0 D-18     /
      DATA ERC2CS( 28) / -.4742207279 0690395452 2565599996 5 D-19     /
      DATA ERC2CS( 29) / +.1189649200 0765283828 8068307845 1 D-19     /
      DATA ERC2CS( 30) / -.3000035590 3257802568 4527131306 6 D-20     /00015000
      DATA ERC2CS( 31) / +.7602993453 0432461730 1938527709 8 D-21     /
      DATA ERC2CS( 32) / -.1935909447 6068728815 6981104913 0 D-21     /
      DATA ERC2CS( 33) / +.4951399124 7733378810 0004238677 3 D-22     /
      DATA ERC2CS( 34) / -.1271807481 3363718796 0862198988 8 D-22     /
      DATA ERC2CS( 35) / +.3280049600 4695130433 1584165205 3 D-23     /
      DATA ERC2CS( 36) / -.8492320176 8228965689 2479242239 9 D-24     /
      DATA ERC2CS( 37) / +.2206917892 8075602235 1987998719 9 D-24     /
      DATA ERC2CS( 38) / -.5755617245 6965284983 1281950719 9 D-25     /
      DATA ERC2CS( 39) / +.1506191533 6392342503 5414405119 9 D-25     /
      DATA ERC2CS( 40) / -.3954502959 0187969531 0428569599 9 D-26     /00016000
      DATA ERC2CS( 41) / +.1041529704 1515009799 8464505173 3 D-26     /
      DATA ERC2CS( 42) / -.2751487795 2787650794 5017890133 3 D-27     /
      DATA ERC2CS( 43) / +.7290058205 4975574089 9770368000 0 D-28     /
      DATA ERC2CS( 44) / -.1936939645 9159478040 7750109866 6 D-28     /
      DATA ERC2CS( 45) / +.5160357112 0514872983 7005482666 6 D-29     /
      DATA ERC2CS( 46) / -.1378419322 1930940993 8964480000 0 D-29     /
      DATA ERC2CS( 47) / +.3691326793 1070690422 5109333333 3 D-30     /
      DATA ERC2CS( 48) / -.9909389590 6243654206 5322666666 6 D-31     /
      DATA ERC2CS( 49) / +.2666491705 1953884133 2394666666 6 D-31     /
C                                                                       00017000
C SERIES FOR ERFC       ON THE INTERVAL  0.          TO  2.50000E-01
C                                        WITH WEIGHTED ERROR   1.53E-31
C                                         LOG WEIGHTED ERROR  30.82
C                               SIGNIFICANT FIGURES REQUIRED  29.47
C                                    DECIMAL PLACES REQUIRED  31.70
C
      DATA ERFCCS(  1) / +.7151793102 0292477450 3697709496 D-1        /
      DATA ERFCCS(  2) / -.2653243433 7606715755 8893386681 D-1        /
      DATA ERFCCS(  3) / +.1711153977 9208558833 2699194606 D-2        /
      DATA ERFCCS(  4) / -.1637516634 5851788416 3746404749 D-3        /00018000
      DATA ERFCCS(  5) / +.1987129350 0552036499 5974806758 D-4        /
      DATA ERFCCS(  6) / -.2843712412 7665550875 0175183152 D-5        /
      DATA ERFCCS(  7) / +.4606161308 9631303696 9379968464 D-6        /
      DATA ERFCCS(  8) / -.8227753025 8792084205 7766536366 D-7        /
      DATA ERFCCS(  9) / +.1592141872 7709011298 9358340826 D-7        /
      DATA ERFCCS( 10) / -.3295071362 2528432148 6631665072 D-8        /
      DATA ERFCCS( 11) / +.7223439760 4005554658 1261153890 D-9        /
      DATA ERFCCS( 12) / -.1664855813 3987295934 4695966886 D-9        /
      DATA ERFCCS( 13) / +.4010392588 2376648207 7671768814 D-10       /
      DATA ERFCCS( 14) / -.1004816214 4257311327 2170176283 D-10       /00019000
      DATA ERFCCS( 15) / +.2608275913 3003338085 9341009439 D-11       /
      DATA ERFCCS( 16) / -.6991110560 4040248655 7697812476 D-12       /
      DATA ERFCCS( 17) / +.1929492333 2617070862 4205749803 D-12       /
      DATA ERFCCS( 18) / -.5470131188 7543310649 0125085271 D-13       /
      DATA ERFCCS( 19) / +.1589663309 7626974483 9084032762 D-13       /
      DATA ERFCCS( 20) / -.4726893980 1975548392 0369584290 D-14       /
      DATA ERFCCS( 21) / +.1435873376 7849847867 2873997840 D-14       /
      DATA ERFCCS( 22) / -.4449510561 8173583941 7250062829 D-15       /
      DATA ERFCCS( 23) / +.1404810884 7682334373 7305537466 D-15       /
      DATA ERFCCS( 24) / -.4513818387 7642108962 5963281623 D-16       /00020000
      DATA ERFCCS( 25) / +.1474521541 0451330778 7018713262 D-16       /
      DATA ERFCCS( 26) / -.4892621406 9457761543 6841552532 D-17       /
      DATA ERFCCS( 27) / +.1647612141 4106467389 5301522827 D-17       /
      DATA ERFCCS( 28) / -.5626817176 3294080929 9928521323 D-18       /
      DATA ERFCCS( 29) / +.1947443382 2320785142 9197867821 D-18       /
      DATA ERFCCS( 30) / -.6826305642 9484207295 6664144723 D-19       /
      DATA ERFCCS( 31) / +.2421988887 2986492401 8301125438 D-19       /
      DATA ERFCCS( 32) / -.8693414133 5030704256 3800861857 D-20       /
      DATA ERFCCS( 33) / +.3155180346 2280855712 2363401262 D-20       /
      DATA ERFCCS( 34) / -.1157372324 0496087426 1239486742 D-20       /00021000
      DATA ERFCCS( 35) / +.4288947161 6056539462 3737097442 D-21       /
      DATA ERFCCS( 36) / -.1605030742 0576168500 5737770964 D-21       /
      DATA ERFCCS( 37) / +.6063298757 4538026449 5069923027 D-22       /
      DATA ERFCCS( 38) / -.2311404251 6979584909 8840801367 D-22       /
      DATA ERFCCS( 39) / +.8888778540 6618855255 4702955697 D-23       /
      DATA ERFCCS( 40) / -.3447260576 6513765223 0718495566 D-23       /
      DATA ERFCCS( 41) / +.1347865460 2069650682 7582774181 D-23       /
      DATA ERFCCS( 42) / -.5311794071 1250217364 5873201807 D-24       /
      DATA ERFCCS( 43) / +.2109341058 6197831682 8954734537 D-24       /
      DATA ERFCCS( 44) / -.8438365587 9237891159 8133256738 D-25       /00022000
      DATA ERFCCS( 45) / +.3399982524 9452089062 7359576337 D-25       /
      DATA ERFCCS( 46) / -.1379452388 0732420900 2238377110 D-25       /
      DATA ERFCCS( 47) / +.5634490311 8332526151 3392634811 D-26       /
      DATA ERFCCS( 48) / -.2316490434 4770654482 3427752700 D-26       /
      DATA ERFCCS( 49) / +.9584462844 6018101526 3158381226 D-27       /
      DATA ERFCCS( 50) / -.3990722880 3301097262 4224850193 D-27       /
      DATA ERFCCS( 51) / +.1672129225 9444773601 7228709669 D-27       /
      DATA ERFCCS( 52) / -.7045991522 7660138563 8803782587 D-28       /
      DATA ERFCCS( 53) / +.2979768402 8642063541 2357989444 D-28       /
      DATA ERFCCS( 54) / -.1262522466 4606192972 2422632994 D-28       /00023000
      DATA ERFCCS( 55) / +.5395438704 5424879398 5299653154 D-29       /
      DATA ERFCCS( 56) / -.2380992882 5314591867 5346190062 D-29       /
      DATA ERFCCS( 57) / +.1099052830 1027615735 9726683750 D-29       /
      DATA ERFCCS( 58) / -.4867713741 6449657273 2518677435 D-30       /
      DATA ERFCCS( 59) / +.1525877264 1103575676 3200828211 D-30       /
C
      DATA PS/                                                          
     *  1.00000 00000 00368 28D+0,                                      
     *  1.87051 01760 45608 34D+0,                                      
     *  1.74642 36937 00583 20D+0,                                      
     *  1.02438 46480 75980 01D+0,                                      
     *  4.07413 18016 72237 64D-1,                                      
     *  1.11870 87099 10981 65D-1,                                      
     *  2.07045 77578 87198 18D-2,                                      
     *  2.37133 37275 29990 36D-3,                                      
     *  1.29992 51594 57886 42D-4/
C
      DATA QS/                                                          
     *  1.00000 00000 00000 00D+0,                                      
     *  2.99888 93431 47982 53D+0,                                      
     *  4.13030 79528 73211 83D+0,                                      
     *  3.43830 15310 36308 66D+0,                                      
     *  1.91273 58832 87815 33D+0,                                      
     *  7.40352 73816 35087 23D-1,                                      
     *  2.00387 66241 26104 24D-1,                                      
     *  3.68131 01420 21681 26D-2,                                      
     *  4.20307 99629 06482 23D-3,                                      
     *  2.30405 72879 41325 37D-4/
C                                                                       00025900
      DATA PL/                                                          
     * -2.82094 79177 38769 11D-1,                                      
     * -6.88752 60682 43379 11D+0,                                      
     * -5.38632 48575 38185 98D+1,                                      
     * -1.54309 75165 42559 24D+2,                                      
     * -1.30749 39376 37537 16D+2,                                      
     * -6.98670 45090 71253 05D+0/
C
      DATA QL/                                                          
     *  1.00000 00000 00000 00D+0,                                      
     *  2.59156 44205 73502 44D+1,                                      
     *  2.26063 71103 01733 68D+2,                                      
     *  8.02050 72743 38541 73D+2,                                      
     *  1.09991 20926 82302 08D+3,                                      
     *  4.28227 93294 91025 56D+2/
C     ------------------------------------------------------------------
C
      IF (.NOT.(NTERF .EQ. 0)) GO TO 20002
      ASSIGN 20002 TO NPR001
      GO TO 30001
20002 Y = abs(X)
      IF (.NOT.(Y .LE. SQEPS)) GO TO 20004
        U = FAC * X                                                     00028000
      GO TO 20003
20004 IF (.NOT.(Y .LE. ONE)) GO TO 20005
      ASSIGN 20006 TO NPR002
      GO TO 30002
20006 GO TO 20003
20005 IF (.NOT.(Y .LT. XBIG)) GO TO 20007
      ASSIGN 20008 TO NPR003
      GO TO 30003
20008   U = sign( HALF+(HALF-U), X )
      GO TO 20003
20007   U = sign ( ONE,X )
20003 DERF = U
      RETURN
C                                                                       00029100
C
c     ------------------------------------------------------------------
      ENTRY DERFC(X)
C
      IF (.NOT.(NTERF .EQ. 0)) GO TO 20009
      ASSIGN 20009 TO NPR001
      GO TO 30001
20009 IF (.NOT.(X .LE. -XBIG)) GO TO 20011
        U = TWO
      GO TO 20010
20011   Y = abs(X)                                                      00030000
      IF (.NOT.(Y .LE. SQEPS)) GO TO 20013
          U = HALF + (HALF - FAC*X)
      GO TO 20012
20013 IF (.NOT.(Y .LE. ONE)) GO TO 20014
      IF (.NOT.(X .LT. HALF)) GO TO 20016
C
C                       *** Here X is in [-1,-SQEPS] or [SQEPS,0.5]
C
      ASSIGN 20017 TO NPR002
      GO TO 30002
20017       U = HALF + (HALF-U)
      GO TO 20015                                                       00031000
C
C            .           *** Here X is in [0.5,1.0]
c            .  Following test on 1.0D-19 added 8/89 to make better use
c            .  of 28 D precision available on a Cray.  The stored
c            .  approximation for erfce is only good to about 18 D.
c            .  On machines having precision greater than 18 D we get
c            .  a more accurate value for erfc by computing U = erf
c            .  and then HALF - (HALF - U).
c
20016 IF (.NOT.(EPS3 .gt. 1.0D-19)) GO TO 20019                         00032000
      ASSIGN 20020 TO NPR004
      GO TO 30004
20020          U = EXP(-X**2) * U
      GO TO 20018
20019 ASSIGN 20021 TO NPR002
      GO TO 30002
20021          U = HALF + (HALF-U)
20018 CONTINUE
20015 GO TO 20012
20014 IF (.NOT.(Y .LE. XMAX)) GO TO 20022
      ASSIGN 20023 TO NPR003
      GO TO 30003
20023     IF (X .LT. ZERO) U = TWO - U
      GO TO 20012                                                       00033100
20022     U = ZERO
          CALL DERM1('DERFC',1,0,'X SO BIG DERFC UNDERFLOWS',           
     *    'X',X,'.')
20012 CONTINUE
20010 DERFC = U
      RETURN
C
c     ------------------------------------------------------------------
      ENTRY DERFCE(X)
C
      IF (.NOT.(NTERF .EQ. 0)) GO TO 20024                              00034300
      ASSIGN 20024 TO NPR001
      GO TO 30001
20024 Y = X
      IF (.NOT.(X .LT.ZERO)) GO TO 20026
        CALL DERM1('DERFCE',1,0,'X MUST BE .GE. ZERO',                  
     *             'X',X,'.')
        U = ZERO
      GO TO 20025
20026 IF (.NOT.(X .LT. ONE)) GO TO 20027
      ASSIGN 20028 TO NPR002
      GO TO 30002
20028   U = EXP(Y*Y)*(HALF + (HALF-U))
      GO TO 20025
20027 IF (.NOT.(X .LT. XMAX)) GO TO 20029
      GO TO 30005                                                       00035300
20030 GO TO 20025
20029 IF (.NOT.( X .lt. CUT2)) GO TO 20031
      ASSIGN 20032 TO NPR004
      GO TO 30004
20032 GO TO 20025
20031 IF (.NOT.(X .LT. CUT3)) GO TO 20033
      GO TO 30006
20034 GO TO 20025
20033   U = PII / X
20025 DERFCE = U
      RETURN
C
C                                                                       00036400
C     PROCEDURE (SET PARAMETERS)
C
30001 EPS3 = D1MACH(3)
      ETA = 0.1D0 * EPS3
      call DINITS (ERFCS,  21, ETA, NTERF )
      call DINITS (ERFCCS, 59, ETA, NTERFC)
      call DINITS (ERC2CS, 49, ETA, NTERC2)
      SQEPS = sqrt (TWO*EPS3)
      XBIG = sqrt (-log(SQRTPI*EPS3))
      XMAX = sqrt (-log(SQRTPI*D1MACH(1)) )                             00037400
      XMAX = XMAX - HALF*log(XMAX)/XMAX - 0.01D0
C
c     PRINT*,'ETA = ',ETA
c     PRINT*,'NTERF = ',NTERF
c     PRINT*,'NTERFC = ',NTERFC
c     PRINT*,'NTERC2 = ',NTERC2
c     PRINT*,'SQEPS = ',SQEPS
c     PRINT*,'XBIG = ',XBIG
c     PRINT*,'XMAX = ',XMAX
C                                                                       00038400
      GO TO NPR001,(20002,20009,20024)
C
C
C     PROCEDURE (DERF(X) FOR ABS(X) .LE. 1)
30002   U = X + X * DCSEVL ( TWO * X * X - ONE, ERFCS, NTERF )
      GO TO NPR002,(20006,20017,20021,20028)
C
C
C     PROCEDURE (DERFC(X) FOR 1 .LT. X .LT. XMAX)
C                                                                       00039400
C                       *** Here, Y = abs(X)
30003   YSQ = Y * Y
      IF(YSQ .LE. FOUR)THEN
        U = EXP(-YSQ) / Y *                                             
     *     (HALF+DCSEVL((EIGHT/YSQ-FIVE)/THREE,ERC2CS,NTERC2))
      ELSE
          U = EXP(-YSQ)/Y*(HALF + DCSEVL(EIGHT/YSQ-ONE, ERFCCS, NTERFC))
      END IF
      GO TO NPR003,(20008,20023)
C
C                                                                       00040500
C     PROCEDURE (DERFCE(X) FOR 1 .LT. X .LT. XMAX)
C
C                       *** Here, Y = abs(X)
30005   YSQ = Y * Y
      IF(YSQ .LE. FOUR)THEN
        U =  (ONE/X) *                                                  
     *     (HALF+DCSEVL((EIGHT/YSQ-FIVE)/THREE,ERC2CS,NTERC2))
      ELSE
          U = (ONE/X) * (HALF + DCSEVL(EIGHT/YSQ-1., ERFCCS, NTERFC))
      END IF
      GO TO 20030                                                       00041600
C
C
C     PROCEDURE (DERFCE(X) FOR 15/32 .LE. X .LE. 4)
30004   PSUM=PS(1)+Y*(PS(2)+Y*(PS(3)+Y*(PS(4)+Y*(PS(5)+Y*(PS(6)         
     *    +Y*(PS(7)+Y*(PS(8)+Y*PS(9))))))))
        QSUM=QS(1)+Y*(QS(2)+Y*(QS(3)+Y*(QS(4)+Y*(QS(5)+Y*(QS(6)         
     *    +Y*(QS(7)+Y*(QS(8)+Y*(QS(9)+Y*QS(10)))))))))
        U=PSUM/QSUM
      GO TO NPR004,(20020,20032)
C
C
C     PROCEDURE (DERFCE(X) FOR 4 .LE. X .LE. 10**16)                    00042800
30006   YSQ=1.D0/Y/Y
        PSUM=PL(1)+YSQ*(PL(2)+YSQ*(PL(3)+YSQ*(PL(4)+YSQ*(PL(5)          
     *    +YSQ*PL(6)))))
        QSUM=QL(1)+YSQ*(QL(2)+YSQ*(QL(3)+YSQ*(QL(4)+YSQ*(QL(5)          
     *    +YSQ*QL(6)))))
        U=(PII+YSQ*PSUM/QSUM)/Y
      GO TO 20034
C
C
      END        

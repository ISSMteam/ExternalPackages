      subroutine IMATPR(A, IDIMA, M, N, TEXT, LWIDTH, LUNIT)
c Copyright (C) 1989, California Institute of Technology.  U. S.
c Government sponsorship under NASA contract NAS7-918 is acknowledged.
c>> 1992-04-08 IMATPR Krogh Replaced dummy K with MACT in MESS call.
c>> 1991-11-22 IMATPR F. Krogh   Initial code
c
c Makes use of external message routine MESS.
c
c     *****     Formal Arguments     ***********************************
c
c A      Matrix to be output, A = A(I,J), I = 1, M; J = 1, N
c IDIMA  Declared row dimension of A
c N      Number of columns in the matrix.
c M      Number of rows in the matrix.
c TEXT   a variable length character type that gives a message to print.
c LWIDTH Line width in characters.  If this or any of the following
c        parameter are < 0, then current defaults set in MESS are used.
c LUNIT  Logical unit number.  (0 prints to the standard output.)
c
c  ******************** Parameter for interfacing to MESS  *************
c
      parameter (MEMLIN =13)
      parameter (MEMUNI =15)
      parameter (METDIG =22)
      parameter (MERET  =51)
      parameter (METXTF =54)
      parameter (MEIMAT =58)
c
      integer           N, LWIDTH, LUNIT
      integer           A(IDIMA, N)
      character*(*)     TEXT
      integer           MACT(17), K, L
c
      K = 1
      if (LWIDTH .gt. 20) then
         MACT(1) = -MEMLIN
         MACT(3) = MEMLIN
         MACT(4) = LWIDTH
         K = 5
      end if
      if (LUNIT .ge. 0) then
         MACT(K) = -MEMUNI
         MACT(K+2) = MEMUNI
         MACT(K+3) = LUNIT
         K = K + 4
      end if
      L = len(TEXT)
      if (L .ne. 0) then
         MACT(K) = METXTF
         MACT(K+1) = L
         K = K + 2
      end if
      MACT(K) = MEIMAT
      MACT(K+1) = IDIMA
      MACT(K+2) = max(M, 0)
      MACT(K+3) = max(N, 0)
      MACT(K+4) = 0
      MACT(K+5) = 0
      MACT(K+6) = MERET
      call MESS(MACT, TEXT, A)
      if (MACT(1) .lt. 0) then
c                           Restore MESS parameters to original state
         MACT(1) = - MACT(1)
         MACT(3) = MERET
         if (MACT(5) .lt. 0) then
            MACT(3) = MEMUNI
            MACT(4) = MACT(6)
            MACT(5) = MERET
         end if
         call MESS(MACT, TEXT, MACT)
      end if
      return
      END

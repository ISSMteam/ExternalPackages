      SUBROUTINE SMPDRV (C,NC,D,ND)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1987-12-09 SMPDRV Lawson  Initial code.
      REAL             D(*), C(*), FAC
C     DERIVATIVE OF POLYNOMIAL REPRESENTED BY COEFFS REL TO THE
C     MONOMIAL BASIS INCLUDING A LINEAR TRANSFORMATION OF THE
C     ARGUMENT.
C     C.L.LAWSON, JPL, 1973 DEC 6
C
C     (C(I),I=1,2)       SCALE FACTORS
C     (C(I+2),I=1,NA+1)  COEFS OF POLY
C     NC                 DEGREE OF POLY
C     (D(I),I=1,2)       OUTPUT..  SCALE FACTORS
C     (D(I+2),I=1,ND+1)OUTPUT..COEFSOFDIFFERENTIATED
C                                  POLY
C     ND                 OUTPUT..  DEGREE OF POLY
C
      IF (NC .LT. 0) THEN
        CALL IERM1('SMPDRV',1,0,'REQUIRE NC .GE. 0','NC',NC,'.')
      ELSE
        D(1)=C(1)
        D(2)=C(2)
        IF (NC .EQ. 0) THEN
          ND=0
          D(3)=0.E0
          RETURN
        ELSE
          NCP2=NC+2
          ND  =NCP2-3
          FAC =0.E0
          DO 20 I=3,NCP2
            FAC=FAC+1.E0
   20     D(I)=C(I+1)*FAC/D(2)
        END IF
      END IF
      RETURN
      END

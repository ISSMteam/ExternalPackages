      subroutine SSORT (R, M, N)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1988-11-22  SSORT  Snyder  Initial code.
c-- S version uses SSORT, R, r, RTEMP, rtemp, SSORTP
c-- & "real numbers"
c-- D version uses DSORT, D, d, DTEMP, dtemp, DSORTP
c-- & "double precision numbers"
c                                                                       00001100
c     Sort the M:N-vector of real numbers R into
c     ascending order.
c
c     To sort an array R' into descending order, let R = -R'
c     To sort an array R' into ascending order according to the
c     absolute value of the elements let R = ABS(R').
c     To sort an array R' into decending order according to the
c     absolute value of the elements let R = -ABS(R').
c
c     To keep track of the original elements, use SSORTP.               00002100
c
      integer M, N
      real R(*)
c
c     *****     Local Variables     ************************************
c
c BL      is the left bound of the sub-array to be sorted at the next
c         step.
c BR      is the right bound of the sub array to be sorted at the next
c         step.                                                         00003100
c CL      is the current left bound of the unsorted sub-array.
c CR      is the current right bound of the unsorted sub-array.
c PARTN   is the partition element.
c RTEMP   holds elements of R during exchanges.
c STACKL  keeps track of the left bounds of sub-arrays waiting to be
c         sorted.
c STACKR  keeps track of the right bounds of sub-arrays waiting to be
c         sorted.
c STKTOP  keeps track of the top of the stacks.
c                                                                       00004100
      integer BL,BR,CL,CR
      real PARTN,RTEMP
      integer STACKL(32),STACKR(32),STKTOP
c
c     *****     Executable Statements     ******************************
c
      IF(n-m.ge.10)THEN
         stktop=1
         stackl(1)=m
         stackr(1)=n                                                    00005200
      GO TO 20006
20004 IF (stktop.eq.0) GO TO 20005
20006       bl=stackl(stktop)
            br=stackr(stktop)
            stktop=stktop-1
c           Choose a partitioning element.  Use the median of the first,
c           middle and last elements.  Sort them so the extreme elements
c           serve as sentinels during partitioning.
            cl=(bl+br)/2
            partn=r(cl)                                                 00006100
      IF(r(bl).gt.partn)THEN
               r(cl)=r(bl)
               r(bl)=partn
               partn=r(cl)
      END IF
      IF(r(bl).gt.r(br))THEN
               rtemp=r(br)
               r(br)=r(bl)
               r(bl)=rtemp
      END IF                                                            00007100
      IF(partn.gt.r(br))THEN
               r(cl)=r(br)
               r(br)=partn
               partn=r(cl)
      END IF
            r(cl)=r(br-1)
            r(br-1)=partn
c           Partition the sub-array around PARTN.  Exclude the above
c           considered elements from partitioning because they're al-
c           ready in the correct subfiles.  Stop scanning on equality to00008100
c           prevent files containing equal values from causing a loop.
            cl=bl
            cr=br-1
20013 GO TO 20017
20015 IF (r(cl).ge.partn) GO TO 20016
20017             cl=cl+1
      GO TO 20015
20016 GO TO 20020
20018 IF (r(cr).le.partn) GO TO 20019
20020             cr=cr-1                                               00009000
      GO TO 20018
20019 IF (cl.gt.cr) GO TO 20014
               rtemp=r(cl)
               r(cl)=r(cr)
               r(cr)=rtemp
      GO TO 20013
c           Put sub-arrays on the stack if they're big enough.  Put the
c           larger under the smaller, so the smaller will be done next.
c           This makes the upper bound of the stack depth log2 (n-m+1).
c           (The "Hibbard" modification of quicksort).                  00010000
20014 IF(cl-bl .gt. br-cr)THEN
      IF(cl-bl.gt.10)THEN
                  stktop=stktop+1
                  stackl(stktop)=bl
                  stackr(stktop)=cr
      END IF
      IF(br-cr.gt.10)THEN
                  stktop=stktop+1
                  stackl(stktop)=cl
                  stackr(stktop)=br                                     00011000
      END IF
      ELSE
      IF(br-cr.gt.10)THEN
                  stktop=stktop+1
                  stackl(stktop)=cl
                  stackr(stktop)=br
      END IF
      IF(cl-bl.gt.10)THEN
                  stktop=stktop+1
                  stackl(stktop)=bl                                     00012000
                  stackr(stktop)=cr
      END IF
      END IF
      GO TO 20004
20005 CONTINUE
      END IF
c     Clean up small subfiles using insertion sort on everything.
      DO 20031 cr = m+1, n
         partn=r(cr)
         cl=cr                                                          00012900
20034 IF(r(cl-1).gt.partn)THEN
            r(cl)=r(cl-1)
            cl=cl-1
      IF (cl.le.m) GO TO 20035
      GO TO 20034
      END IF
20035    r(cl)=partn
20031 CONTINUE
c
      return                                                            00013800
c
      end        

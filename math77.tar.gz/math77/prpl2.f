      SUBROUTINE PRPL2(XY,IDIM,KC,JX,JY,NP,SYMBOL,TITLE,
     *XNAME,YNAME,ROW1,ROW2,NR)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C>> 1992-02-18 PRPL1 CLL Added msg about phasing out PRPL2.
C>> 1990-10-29 PRPL1 CLL More changes to formatting of x-grid labels.
C>> 1990-10-22 PRPL2 CLL Adding x and y rounding to position point.
C>> 1988-05-24 PRPL2  Lawson  Initial code.
C
C     PRPL2       This replaces KCPL of JPL$.
C     Only first 51 characters of YNAME() are used.
C     C.L.Lawson & Stella Chan,JPL,April 4,1983
c     Coded for Fortran 77.
C
C     Use T Edit Descriptor in WRITE(...) YPART,GRIDY,... to overcome
C     a defect of the G Edit Descriptor in UNIVAC FTN
C     compiler. April 5,1983
C
C     1990 Oct.  Reworked formatting of labels for the x-grid lines.
c     No. of major subdivisions, KMAJX, returned by SCALK8 will be
c     3, 4, 5, 6, 7, or 8.  Generally we print KMAJX+1 labels, but print
c     only 5 for KMAJX = 8.  
c     Will print numbers in the form -1.2345E-201 except when KMAJX = 7
c     in which case we reduce to     -1.234E-201.  Provides one or more
c     spaces between numbers.
c     Also reduced spacing between the ROW1() & ROW2() items.
C     ------------------------------------------------------------------
C     SUBROUTINE ARGUMENTS
C     --------------------
C
C     XY()      Array of values from which (x,y) coordinates of
C               points to be plotted will be obtained under
C               control of the parameters JX(),JY(),and NP().
C
C     IDIM      Dimension of the first subscript in the XY array.
C               IDIM.GE.max(NP(k),K=1,KC).
C
C     KC        Number of curves to be plotted,KC .GT. 0. KC = 0
C               is used to signal that options are to be
C               exercised.Usage of each option is described
C               separately below.
C
C     JX()      JX(K) specifies the column (second subscript) of
C               XY( , ) to be used as x coordinates for the Kth
C               curve.
C
C     JY()      JY(K) specifies the column (second subscript) of
C               XY( , ) to be used as y coordinates for the Kth
C               curve.
C
C     NP()      NP(K) specifies the number of (x,y) coordinate
C               pairs in XY( , ) to be used for the Kth curve.
C               (NP(K).GE.1 .AND. NP(K).LE.IDIM)
C
C     SYMBOL()  SYMBOL(K) contains a single character to be
C               used to identify the Kth curve.The character
C               in SYMBOL(K) will be plotted at each (x,y) point
C               of the curve.
C
C     TITLE     Character variables of up to 84 characters to be
C               printed above the plot grid as a title for the
C               graph.
C
C     XNAME     Character variables of up to 84 characters to be
C               printed below the plot grid to identify the
C               abscissa variable.
C
C     YNAME     Character variables of up to 51 characters to be
C               printed in a vertical column at the left of the
C               plot grid to identify the ordinate variable.
C
C     ROW1()    Array of up to eight 12-character labels, to be
C               printed for identification of the numeric
C               parameters provided in ROW2.
C
C     ROW2()    Array of REAL parameters to be printed at the
C               bottom of the plot frame to aid in the
C               identification of the graph.
C
C     NR        Number of REAL parameters from ROW2 and associated
C               labels from ROW1 to be printed. NR must satisfy
C               (NR.GE.0 .AND. NR.LE.8)
C
C     ------------------------------------------------------------------
C
      integer TOTX,TOTY,TOTX1,TOTY1,TOTY2
      parameter (TOTX=84,TOTY=51,TOTX1=TOTX-1,TOTY1=TOTY-1,TOTY2=TOTY+1)
      integer I, IDIM, INC, IZX, IZY, J, JX(*), JX1, JY(*), JY1
      integer K, KC, KMAJX, KMAJY, KMIN
      integer NP(*), NR, TLEN, TPAD
      integer XINDEX, XLEN, YLEN, XPAD, YPAD, XKEY, YKEY
      real DELX, DELY
      real FAC, FKMAJX, FKMAJY, FXIND, GRIDX(0:20), GRIDY, ROW2(*)
      real XMAX, XMIN, XSMALL, XY(IDIM,*)
      real YINDEX, YMAX, YMIN, YSMALL, ZERO
      character*1 Z(TOTX,TOTY),SYMBOL(KC)
      character*1 BLANK,BAR,DASH,YPART,ARROW1,ARROW2
      character*12 ROW1(*)
      character*14 FMT(3:8)
      character*(*) TITLE,XNAME,YNAME
      character*(TOTX) PAD
      logical FIRST
      save    FIRST
      DATA BLANK/' '/
      DATA BAR/'|'/
      DATA DASH/'-'/
      DATA PAD/' '/
      DATA ARROW1/'>'/
      DATA ARROW2/'<'/
      DATA FAC/0.00001/
      DATA ZERO/0.0/
      data FMT / '(12x,1p4g26.4)',
     *           '(21x,1p5g19.4)',
     *           '(26x,1p6g15.4)',
     *           '(26x,1p7g13.4)',
     *           '(24x,1p8g12.3)',
     *           '(21x,1p5g19.4)'/
      data FIRST / .true. /
C     ------------------------------------------------------------------
      if(FIRST) then
         FIRST = .false.
         print'(1x,a)',
     *      '==================================================',
     *      'PRPL2..  February, 1992.  This subroutine is being',
     *      'phased out of the MATH77 library.',
     *      'Please use SPRPL2 instead.',
     *      'call SPRPL2(XY,IDIM,KC,JX,JY,NP,SYMBOL,TITLE,',
     *      '    XNAME, YNAME, NLINES, NCHARS, IMAGE, IERR)',
     *      '=================================================='
      endif
C
      DO 10 I=1,TOTX
      DO 10 J=1,TOTY
        Z(I,J)=BLANK
        IF (J.NE.1 .AND. J.NE.TOTY) THEN
          IF (I.EQ.1 .OR. I.EQ.TOTX) THEN
            Z(I,J)=BAR
          ENDIF
        ELSE
          Z(I,J)=DASH
        ENDIF
   10 CONTINUE
C
C     FIND LIMITS OF PLOT
C
      XMIN=XY(1,JX(1))
      XMAX=XMIN
      YMIN=XY(1,JY(1))
      YMAX=YMIN
      DO 20 K=1,KC
        JX1=JX(K)
        JY1=JY(K)
        DO 30 I=1,NP(K)
          XMAX=MAX(XMAX,XY(I,JX1))
          XMIN=MIN(XMIN,XY(I,JX1))
          YMAX=MAX(YMAX,XY(I,JY1))
          YMIN=MIN(YMIN,XY(I,JY1))
   30   CONTINUE
   20 CONTINUE
C
C     SELECT SCALE
C
      CALL SCALK8 (XMIN,XMAX,XMIN,XMAX,KMAJX,KMIN)
      CALL SCALK8 (YMIN,YMAX,YMIN,YMAX,KMAJY,KMIN)
      XSMALL=MAX(ABS(XMIN),ABS(XMAX))*FAC
      YSMALL=MAX(ABS(YMIN),ABS(YMAX))*FAC
      FKMAJX=REAL(KMAJX)
      DO 40 XINDEX=0,KMAJX
        FXIND=REAL(XINDEX)
        XKEY=INT( FXIND * (TOTX-1.) / FKMAJX + 1.5 )
        Z(XKEY,1)=BAR
        Z(XKEY,TOTY)=BAR
        GRIDX(XINDEX)=XMIN + FXIND * (XMAX-XMIN) / FKMAJX
        IF (ABS(GRIDX(XINDEX)).LT.XSMALL) GRIDX(XINDEX)=ZERO
   40 CONTINUE
C
      DELX=(XMAX-XMIN)/TOTX1
      DELY=(YMAX-YMIN)/TOTY1
C

C     LOOP TO PLOT ONE CURVE
C
      DO 50 K=1,KC
        JX1=JX(K)
        JY1=JY(K)
        DO 60 I=1,NP(K)
          IZY=(XY(I,JY1)-YMIN)/DELY + 0.5
          IZX=(XY(I,JX1)-XMIN)/DELX + 0.5
          Z(IZX+1,IZY+1)=SYMBOL(K)
   60   CONTINUE
   50 CONTINUE
C
C     BEGIN..OUTPUT
C
      YINDEX=0.0
      FKMAJY=REAL(KMAJY)
      TLEN=MIN(TOTX,LEN(TITLE))
      TPAD=(TOTX-TLEN)/2
      WRITE (*,'(a,30x,a,a)') '1',PAD(1:TPAD),TITLE(1:TLEN)
      YLEN=MIN(TOTY2,LEN(YNAME))
      YPAD=(TOTY-YLEN)/2
      DO 70 K=1,TOTY
        I=TOTY2-K
        IF (K.GT.YPAD .AND. K.LE.YPAD+YLEN) THEN
          YPART=YNAME(K-YPAD:K-YPAD)
        ELSE
          YPART=' '
        ENDIF
          YKEY=INT( YINDEX * (TOTY-1.) / FKMAJY + 1.5 )
          IF (K.EQ.YKEY) THEN
            GRIDY=YMAX-YINDEX*(YMAX-YMIN)/FKMAJY
            IF (ABS(GRIDY).LT.YSMALL) GRIDY=ZERO
            WRITE (*,'(1x,T8,A1,6X,1PG15.4,T31,86A1)') 
     *         YPART,GRIDY,ARROW1,(Z(J,I),J=1,TOTX),ARROW2
            YINDEX=YINDEX+1.
          ELSE
            WRITE (*,'(7X,A1,23X,84A1)') YPART,(Z(J,I),J=1,TOTX)
          ENDIF
   70 CONTINUE
      if(KMAJX .eq. 8) then
         INC = 2
      else
         INC = 1
      endif
      write(*,FMT(KMAJX)) (GRIDX(I),I=0,KMAJX,INC)
      XLEN=MIN(TOTX,LEN(XNAME))
      XPAD=(TOTX-XLEN)/2
      WRITE (*,'(31X,A,A)') PAD(1:XPAD),XNAME(1:XLEN)
      IF (NR.NE.0) WRITE (*,'(4X,8(A14))') (ROW1(J),J=1,NR)
      IF (NR.NE.0) WRITE (*,'(4X,8(1PG14.4))') (ROW2(I),I=1,NR)
      RETURN
      END

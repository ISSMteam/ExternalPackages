      real function  SRANG ()
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
c>> 1992-03-16 CLL
c>> 1991-11-26 CLL Reorganized common. Using RANCM[A/D/S].
c>> 1991-11-22 CLL Added call to RAN0, and SGFLAG in common.
c>> 1991-01-15 CLL Reordered common contents for efficiency.
C>> 1990-01-23 CLL  Making names in common same in all subprogams.
C>> 1987-06-09 SRANG  Lawson  Initial code.
C 
c     Returns one pseudorandom number from the Gausian (Normal)
c     distribution with zero mean and unit standard deviation.
c     Method taken from Algorithm 334, Comm. ACM, July 1968, p. 498.
c     Implemented at JPL in Univac Fortran V in 1969 by Wiley R. Bunton
c     of JPL and Stephen L. Richie of Heliodyne Corp.
c 
c     Adapted to Fortran 77 for the MATH 77 library by C. L. Lawson and
c     S. Y. Chiu, JPL, April 1987, 6/9/87.
C     ------------------------------------------------------------------
c--   D version uses DRANG, DRANUA, RANCMD, DPTR, DNUMS, DGFLAG
c--   S version uses SRANG, SRANUA, RANCMS, SPTR, SNUMS, SGFLAG
C     RANCMS is a common block.
c     Uses intrinsic functions, log and sqrt.
C     Calls SRANUA to obtain an array of uniform random numbers.
c     Calls RAN0 to initialize SPTR and SGFLAG.
C     ------------------------------------------------------------------
c                        Important common variables
c 
c     SPTR [integer] and SGFLAG [logical]
c 
c          Will be set to SPTR = 1 and SGFLAG = .false.
c          when RAN0 is called from this subr if this
c          is the first call to RAN0.  Also set to these values when
c          RAN1 or RANPUT is called by a user.
c 
c          SGFLAG will be set true on return from this subr when the
c          algorithm has values that it can save to reduce the amount
c          of computation needed the next time this function is
c          referenced.  Will be set false in the contrary case.
c 
c          SPTR is the index of the last location used in the
c          common array SNUMS().  This index is counted down.
c 
c     SNUMS() [floating point]  Buffer of previously computed uniform
c          random numbers.
C     ------------------------------------------------------------------
      integer M
      parameter(M = 97)
      real    ONE, TWO
      parameter(ONE = 1.0E0, TWO = 2.0E0)
      real    SNUMS(M), R, S, U3, X, XX, Y, YY
      logical FIRST
      common/RANCMS/SNUMS
c--   Begin mask code changes.
      integer DPTR, SPTR
      logical DGFLAG, SGFLAG
      common/RANCMA/DPTR, SPTR, DGFLAG, SGFLAG
c--   End mask code changes.
      save  /RANCMA/, /RANCMS/, FIRST
      save    R, X, Y
      data  FIRST/.true./
c     ------------------------------------------------------------------
      if(FIRST) then
         FIRST = .false.
         call RAN0
      endif
c 
      if (.not. SGFLAG .or. SPTR .eq. 1) then
C 
C     Use the Von Neuman rejection method for choosing a random point
c     (X,Y) in the unit circle, X**2 + Y**2 .le. 1.0.
c     Then the angle Theta = arctan(Y/X) is random, uniform in
c     (-Pi/2, Pi/2), and Phi = 2*Theta is random, uniform in (-Pi, Pi).
C     Define S = X**2 + Y**2, then
c     sin(Theta) = Y/sqrt(S),    cos(Theta) = X/sqrt(S),
c     sin(Phi) = 2*X*Y/S,    and cos(Phi) = (X**2 - Y**2)/S.
c 
   10    continue
c                              Set X = random, uniform in [0., 1.]
      SPTR = SPTR - 1
      if(SPTR .eq. 0) then
         call SRANUA(SNUMS, M)
         SPTR = M
      endif
            X = SNUMS(SPTR)
c                              Set Y = random, uniform in [-1., 1.]
            SPTR = SPTR - 1
            if(SPTR .eq. 0) then
               call SRANUA(SNUMS,M)
               SPTR = M
            endif
            Y = TWO*SNUMS(SPTR) - ONE
c 
            XX=X*X
            YY=Y*Y
            S=XX+YY
         if(S .gt. ONE) go to 10
C 
C     Choose R randomly from Chi-squared distribution and
c     normalize with S.
C 
c                              Set U3 = random, uniform in [0., 1.]
         SPTR = SPTR - 1
         if(SPTR .eq. 0) then
            call SRANUA(SNUMS,M)
            SPTR = M
         endif
         U3 = SNUMS(SPTR)
         R = sqrt(-TWO*log(U3))/S
C 
C                                Compute result as  R*Sin(PHI)
C 
         SRANG = (XX-YY)*R
         SGFLAG = .true.
         return
      endif
C     -- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
c        Come here when SGFLAG is true and SPTR is not 1.
c 
C                                Compute result as  R*Cos(PHI)
      SRANG = TWO*X*Y*R
      SGFLAG=.false.
      return
      end

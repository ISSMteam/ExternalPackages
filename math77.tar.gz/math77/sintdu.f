      SUBROUTINE SINTDU
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C     SUBROUTINE $L1$INTDU
C>> 1987-11-20 SINTDU Snyder  Initial code.
C
C     THIS SUBROUTINE UPDATES DIFFERENCE LINES FOR SINTA DURING
C     THE SEARCHES.
C                                                                       00001100
C     *****    SPECIALIZER VARIABLES     *******************************
C
C     SPECIALIZER VARIABLES ARE ALL DEFINED IN SINTOP (OR DINTOP)
C
C     *****     INTERNAL AND COMMON VARIABLES   ************************
C
C EPSCOR  IS A CORRECTION TO BE ADDED ONTO EPSMIN.
C     $DSTYP$ EPSCOR
      REAL EPSCOR
C FATA    THE FUNCTION VALUE AT THE ALOCAL END OF THE INTERVAL.         00002100
C FATB    THE FUNCTION VALUE AT THE BLOCAL END OF THE INTERVAL.
C     $.TYPE.$ FATA,FATB
      REAL FATA,FATB
C PHIT    IS THE BACKWARD DIFFERENCE LINE.
C     $.TYPE.$ PHIT(17)
      REAL PHIT(17)
C
C     *****    COMMON STORAGE ******************************************
C
C     COMMON /$L1$INTNC/ CONTAINS VARIABLES NOT SEPARATELY SAVED FOR    00003100
C     EACH DIMENSION OF A MULTIPLE QUADRATURE.  COMMON /$L1$INTC/
C     CONTAINS VARIABLES THAT MUST BE SAVED FOR EACH DIMENSION OF THE
C     QUADRATURE.  THE VARIABLES IN EACH COMMON BLOCK ARE STORED IN THE
C     ORDER - ALWAYS DOUBLE, DOUBLE IF DOUBLE PRECISION PROGRAM, DOUBLE
C     IF DOUBLE PRECISION PROGRAM AND EXPONENT RANGE OF DOUBLE AND
C     SINGLE VERY DIFFERENT, SINGLE, INTEGER, LOGICAL.  A PAD OF LOGICAL
C     VARIABLES IS INCLUDED AT THE END OF /$L1$INTC/.  THE DIMENSION OF
C     THE PAD MAY NEED TO BE VARIED SO THAT NO VARIABLES BEYOND THE END
C     OF THE COMMON BLOCK ARE ALTERED.
C                                                                       00003100
C     DECLARATIONS OF COMMON /$L1$INTNC/ VARIABLES.
C
C     $.TYPE.$ AINIT, BINIT, FNCVAL, S, TP
      REAL             AINIT, BINIT, FNCVAL, S, TP
C     $DSTYP$  FER, FER1, RELOBT, TPS, XJ, XJP
      REAL             FER, FER1, RELOBT, TPS, XJ, XJP
      INTEGER     FEA,       FEA1,      INC,       INC2,      IPRINT,   
     * ISTOP(2,2),JPRINT,    KDIM,      KK,        KMAXF,     NDIM,     
     * NFINDX,    NFMAX,     NFMAXM,    OUT,       RELTOL,    REVERM,   
     * REVERS,    WHEREM
      LOGICAL NEEDH
C
C     DECLARATIONS OF COMMON /$L1$INTC/ VARIABLES.                      00003100
C
C     4 DOUBLE PRECISION VARIABLES
      DOUBLE PRECISION ACUM, PACUM, RESULT(2)
C     139 $.TYPE.$ VARIABLES
C     $.TYPE.$
      REAL                                                              
     * AACUM,     ABSCIS,    DELMIN,    DELTA,     DIFF,      DISCX(2), 
     * END(2),    ERRINA,    ERRINB,    FAT(2),    FSAVE,               
     * FUNCT(24), F1,        F2,        LOCAL(4),  PAACUM,    PF1,      
     * PF2,       PHISUM,    PHTSUM,    PX,        SPACE(6),            
     * STEP(2),   START(2),  SUM,       T,         TA,        TASAVE,   
     * TB,        TEND,      WORRY(2),  X,         X1,                  
     * X2,        XT(17),    FT(17),    PHI(34)
c Note XT, FT, and PHI above are last, because they must be in adjacent
c locations in SINTO.
C     30 $DSTYP$ VARIABLES
C     $DSTYP$                                                           00003100
      REAL                                                              
     * ABSDIF,    COUNT,     EDUE2A,    EDUE2B,    EP,        EPNOIZ,   
     * EPS,       EPSMAX,    EPSMIN,    EPSO,      EPSR,      EPSS,     
     * ERR,       ERRAT(2),  ERRC,      ERRF,      ERRI,      ERRT(2),  
     * ESOLD,     EXTRA,     PEPSMN,    RE,        RELEPS,    REP,      
     * REPROD,    RNDC,      TLEN,      XJUMP
C     29 INTEGER VARIABLES
      INTEGER     DISCF,     DISCHK,    ENDPTS,    I,         INEW,     
     * IOLD,      IP,        IXKDIM,    J,         J1,        J1OLD,    
     * J2,        J2OLD,     K,         KAIMT,     KMAX,      KMIN,     
     * L,         LENDT,     NFEVAL,    NFJUMP,    NSUB,      NSUBSV,   
     * NXKDIM,    PART,      SEARCH,    TALOC,     WHERE,     WHERE2
C     11 TO 18 LOGICALS (7 ARE PADDING).
      LOGICAL     DID1,      FAIL,      FATS(2),   FSAVED,    HAVDIF,   
     * IEND,      INIT,      ROUNDF,    XCDOBT(2), PAD(7)
C
C     THE COMMON BLOCKS.
C
C     COMMON /$L1$INTNC/
      COMMON /SINTNC/                                                   00003100
     * AINIT,  BINIT,  FNCVAL, S,      TP,     FER,    FER1,   RELOBT,  
     * TPS,    XJ,     XJP,    FEA,    FEA1,   KDIM,    INC,    INC2,   
     * ISTOP,  JPRINT, IPRINT, KK,     KMAXF,  NDIM,   NFINDX, NFMAX,   
     * NFMAXM, OUT,    RELTOL, REVERM, REVERS, WHEREM, NEEDH
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * ACUM,   PACUM,  RESULT
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * AACUM,  LOCAL,  ABSCIS, TA,     DELTA,  DELMIN, DIFF,   DISCX,   
     * END,    ERRINA, ERRINB, FAT,    FSAVE,  FUNCT,  F2,              
     * PAACUM, PF1,    PF2,    PHISUM, PHTSUM, PX,     SPACE,           
     * STEP,   START,  SUM,    T,      TASAVE, TB,     TEND,            
     * WORRY,  X1,     X2,     X,      F1,     COUNT,                   
     * XT, FT, PHI
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * ABSDIF, EDUE2A, EDUE2B, EP,     EPNOIZ, EPSMAX,                  
     * EPSO,   EPSR,   EPSS,   ERRAT,  ERRC,   ERRF,                    
     * ERRT,   ESOLD,  EXTRA,  PEPSMN, RELEPS, REP,                     
     * RNDC,   TLEN,   XJUMP,                                           
     * ERRI,   ERR,    EPSMIN, EPS,    RE,     REPROD
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    
     * DISCF,  DISCHK, ENDPTS, INEW,   IOLD,   IP,     IXKDIM,          
     * J,      J1,     J1OLD,  J2,     J2OLD,  KMAX,                    
     * KMIN,   L,      LENDT,  NFEVAL, NFJUMP, NSUBSV, NXKDIM,          
     * TALOC,  WHERE2,                                                  
     * I,      K,      KAIMT,  NSUB,   PART,   SEARCH, WHERE
C     COMMON /$L1$INTC/
      COMMON /SINTC/                                                    00003100
     * DID1,   FAIL,   FATS,   FSAVED, HAVDIF, IEND,   INIT,   ROUNDF,  
     * XCDOBT, PAD
C     SAVE /$L1$INTNC/, /$L1$INTC/
      SAVE /SINTNC/, /SINTC/
C
C $   COL1(PORT)
C.    THE VARIABLES HERE DEFINE THE MACHINE ENVIRONMENT.  ALL ARE SET
C.    IN $L1$INTOP.  THE MEANING ATTACHED TO THESE VARIABLES CAN BE
C.    FOUND BY LOOKING AT THE RELATED SPECIALIZER VARIABLES DEFINED IN
C.    $L1$INTOP.
      DOUBLE PRECISION EDMEPS
C     $.TYPE.$                                                          00003300
      REAL                                                              
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     COMMON /$L1$INTEC/
      COMMON /SINTEC/                                                   
     *  EDMEPS,                                                         
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     SAVE /$L1$INTEC/
      SAVE /SINTEC/
C $   COL1(PORT, 0)
C
C     *****    EQUIVALENCE STATEMENTS    *******************************
C
      EQUIVALENCE (PHI(18),PHIT)                                        00003700
      EQUIVALENCE (FAT(1),FATA), (FAT(2),FATB)
C
C     *****    PROCEDURES     ******************************************
C
      IF (WHERE-5) 200,40,10
C
C     UPDATE BY ADDING A FUNCTION VALUE IN THE MIDDLE.
C
10    HAVDIF=.FALSE.
      IF(NFEVAL.GT.NFJUMP+6)THEN                                        00004800
         WHERE=0
         L=MIN(L,LENDT+1)
         IF (L.GE.LENDT+1) GO TO 180
         I=LENDT
         EPSCOR=0.5*(-ABS(XT(L-1)*(FT(L)-FT(L-1)))                      
     *   +ABS(XT(L-1)*(FNCVAL-FT(L-1)))+ABS(X*(FT(L)-FNCVAL)))
C        EPSCOR=EPSCOR*$MEPS$
         EPSCOR=EPSCOR*EMEPS
         EPSCOR=EPSCOR+ABS(FNCVAL*RNDC*(XT(L)-XT(L-1)))
         IF (FEA.NE.0) EPSCOR=EPSCOR+ABS(0.5*ERRF*(XT(L)-XT(L-1)))
         EPSMIN=EPSMIN+MAX(EPSCOR,0.0)                                  00005900
20004       XT(I+1)=XT(I)
            FT(I+1)=FT(I)
            IF (I.EQ.L) GO TO 180
            I=I-1
      GO TO 20004
      END IF
      IF (L-LENDT-1) 80,50,50
C
C     UPDATE BY ADDING A FUNCTION VALUE ON THE BLOCAL END.
C                                                                       00007000
40    IF (WHERE2.EQ.1) GO TO 70
      FNCVAL=FATB
      L=LENDT+1
C     ADD ONE AT THE BLOCAL END
50    PHIT(L)=FNCVAL
      TP=1.0
      PHIT(LENDT)=FNCVAL-PHIT(LENDT)
      I=LENDT
60       TP=TP*((X-XT(I))/(XT(LENDT)-XT(I-1)))
         PHIT(I-1)=PHIT(I)-TP*PHIT(I-1)                                 00008000
         I=I-1
      IF (I.GE.2) GO TO 60
      GO TO 140
C
C     UPDATE BY ADDING A FUNCTION VALUE ON THE ALOCAL END.
C
70    FNCVAL=FATA
      L=1
C     ADD ONE IN THE MIDDLE OR AT THE ALOCAL END.
80    I=LENDT                                                           00009000
      TP=PHIT(I)-FNCVAL
      S=XT(I)-X
20006    XT(I+1)=XT(I)
         FT(I+1)=FT(I)
         PHIT(I+1)=PHIT(I)
         PHI(I+1)=PHI(I)
         I=I-1
      IF (I.LT.L) GO TO 20007
         TP=TP+(S/(X-XT(I)))*(TP-PHIT(I))
      GO TO 20006                                                       00010100
20007 PHIT(L)=TP
      IF(L.EQ.1)THEN
C        ADD ONE AT THE ALOCAL END.
         PHI(1)=FNCVAL
         TP=1.0
         PHI(2)=FNCVAL-PHI(2)
         I=2
110         TP=TP*((X-XT(I))/(XT(1)-XT(I+1)))
            PHI(I+1)=PHI(I)-TP*PHI(I+1)
            I=I+1                                                       00011100
         IF (I.LE.LENDT) GO TO 110
         GO TO 180
      END IF
C     UPDATE PHIT FOR ADDING ONE IN THE INTERIOR.
      I=L-1
130      PHIT(I)=PHIT(I+1)+(S/(X-XT(I)))*(PHIT(I+1)-PHIT(I))
         I=I-1
      IF (I.GT.0) GO TO 130
C     UPDATE PHI FOR ADDING ONE IN THE INTERIOR OR AT THE BLOCAL END.
140   TP=PHI(1)-FNCVAL                                                  00012100
      S=XT(1)-X
      I=2
      IF(L.NE.2)THEN
150         TP=TP+(S/(X-XT(I)))*(TP-PHI(I))
            I=I+1
         IF (I.LT.L) GO TO 150
      END IF
      PHI(L)=TP
      IF(L.NE.LENDT+1)THEN
C        I = L AT THIS TIME.                                            00013100
170         PHI(I+1)=PHI(I)+(S/(X-XT(I+1)))*(PHI(I)-PHI(I+1))
            I=I+1
         IF (I.LE.LENDT) GO TO 170
      END IF
180   LENDT=LENDT+1
      XT(L)=X
      FT(L)=FNCVAL
      IF(J1OLD.NE.18)THEN
         IF (J1OLD.GE.L) J1OLD=J1OLD+1
      END IF                                                            00014100
      IF (J2OLD.GE.L) J2OLD=J2OLD+1
      IF (WHERE.NE.0) GO TO 230
C
C     REFORM THE DIFFERENCE LINES.
C
200   NFJUMP=NFEVAL
      PHI(1)=FT(1)
      PHIT(1)=FT(2)-FT(1)
      PHI(2)=-PHIT(1)
      PHIT(2)=FT(2)                                                     00015100
      DO 20016 J=3,LENDT
         TP=1.0
         S=1.0
         PHIT(J)=FT(J)
      DO 20019 I=3,J
            PHIT(J-I+2)=PHIT(J-I+3)-TP*PHIT(J-I+2)
            TP=TP*((XT(J)-XT(J-I+2))/(XT(J-1)-XT(J-I+1)))
            S=S*((XT(1)-XT(J-I+2))/(XT(J)-XT(J-I+2)))
20019 CONTINUE
         PHIT(1)=PHIT(2)-TP*PHIT(1)                                     00016100
         PHI(J)=-S*PHIT(1)
20016 CONTINUE
C
230   CONTINUE
      RETURN
C
      END

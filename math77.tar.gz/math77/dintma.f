      SUBROUTINE DINTMA (ANSWER,WORK,IFLAG)
C     .  Copyright (C) 1989, California Institute of Technology.
C     .  All rights reserved.  U. S. Government sponsorship under
C     .  NASA contract NAS7-918 is acknowledged.
C     SUBROUTINE $L1$INTMA (ANSWER,WORK,IFLAG)
C>> 1992-04-09 DINTMA Krogh added error message processing.
C>> 1991-09-20 DINTMA Krogh converted '(1)' dimensioning to '(*)'.
C>> 1989-02-28 DINTMA Snyder  Dimensioned MOVE
C>> 1988-04-28 DINTMA Snyder  Initial code.
C                                                                       00001100
C     MULTIDIMENSIONAL QUADRATURE SUPERVISION PROGRAM.
C
C     *****    SPECIALIZER VARIABLES     *******************************
C
C     SPECIALIZER VARIABLES ARE ALL DEFINED IN SINTOP (OR DINTOP).
C
C     *****     PARAMETERS     *****************************************
C
C KWORK   IS THE AMOUNT OF WORKING STORAGE NEEDED FOR EVERY DIMENSION
C         OTHER THAN THE INNERMOST.  THE TOTAL SIZE OF WORK MUST BE AT  00002100
C         LEAST 3*NDIMI + KWORK*(NDIMI-1).  THE VALUE OF KWORK DEPENDS
C         ON THE MACHINE AND THE PRECISION OF THE PROGRAM, BUT FOR
C         PORTABILITY, THE USAGE SHOULD ALWAYS ASSUME THE WORST CASE FOR
C         EACH PRECISION.  VALUES OF KWORK ARE
C           SINGLE PRECISION, KWORK=217
C           SINGLE PRECISION, HALFWORD INTEGERS AND LOGICALS, KWORK=?
C           PARTLY DOUBLE, KWORK=?
C           PARTLY DOUBLE, HALFWORD INTEGERS AND LOGICALS, KWORK=?
C           DOUBLE PRECISION, KWORK=193.
C           DOUBLE PRECISION, HALFWORD INTEGERS AND LOGICALS, KWORK=?   00003100
C
C $   COL1(L1='S',1,1)
C     PARAMETER (KWORK=217)
      PARAMETER (KWORK=193)
C
C     *****     FORMAL ARGUMENTS     ***********************************
C
C ANSWER  THE INTEGRAL OVER ALL DIMENSIONS WHEN THE INTEGRATION IS
C         COMPLETE.  THE INTEGRAL OVER THE INNER DIMENSIONS WHEN
C         THE INTEGRATION IS IN PROGRESS.                               00004100
C     $.TYPE.$ ANSWER
      DOUBLE PRECISION ANSWER
C WORK    WORKING STORAGE AS DESCRIBED IN $L1$INTM.
C     $.TYPE.$ WORK(*)
      DOUBLE PRECISION WORK(*)
C IFLAG   INDICATES THE ACTION OR STATUS, AS DESCRIBED IN $L1$INTM.
      INTEGER IFLAG(*)
C
C     *****     COMMON VARIABLES     ***********************************
C                                                                       00005100
C MOVE    IS EQUIVALENCED TO ACUM.  MOVE IS USED TO PASS THE CORRECT
C         TYPE VARIABLE TO $L1$COPY, AND TO MAKE $L1$INTC THE CORRECT
C         LENGTH.
C     $.TYPE.$ MOVE(KWORK)
      DOUBLE PRECISION MOVE(KWORK)
C
C     THE VARIABLES BELOW ARE NOT SEPARATELY SAVED FOR EACH DIMENSION
C     OF THE INTEGRATION, OR ARE ONLY USED FOR THE MULTIDIMENSIONAL
C     QUADRATURE.  SEE $L1$INTA FOR DESCRIPTIONS OF VARIABLES NOT
C     EXPLAINED BELOW.                                                  00006100
C
C ERRF    IS THE ERROR COMMITTED ON AN INNER INTEGRAL.  IT IS USED AS
C         THE ESTIMATED ERROR IN THE INTEGRAND FOR AN OUTER INTEGRAL.
C FEA1    STORES THE VALUE OF FEA FOR THE INNER INTEGRAL.
C FER1    STORES THE VALUE OF FER FOR THE INNER INTEGRAL.
C IPRINT  IS THE CURRENT DIAGNOSTIC PRINT LEVEL.  SEE $L1$INTA.
C IXKDIM  INDEX IN IFLAG (=IOPT) IN WHICH UNUSUAL DIMENSION CHANGES ARE
C         TO BE STORED.  THIS IS SET BY OPTION 12, BUT THE DEFAULT IS 1.
C JPRINT  IS AN NDIM DIGIT INTEGER SPECIFYING ALL DIAGNOSTIC PRINT
C         LEVELS.  THE LOW ORDER DIGIT IS FOR THE INNER DIMENSION.      00007100
C         SEE $L1$INTM.
C KDIM    IS THE CURRENT DIMENSION.
C NDIM    IS THE NUMBER OF DIMENSIONS.
C NFMAXM  IS THE TOTAL NUMBER OF FUNCTION VALUES ALLOWED IN THE INNER
C         INTEGRAL.  BY CONTRAST, NFMAX IS THE NUMBER OF FUNCTION VALUES
C         ALLOWED ON A SINGLE ITERATION OF THE INNER INTEGRAL.
C NXKDIM  INDEX-1 OF THE DIMENSION TO RESUME WHEN CALCULATION OF THE
C         INTEGRAL OVER THE CURRENT DIMENSION IS COMPLETE.  NXKDIM IS
C         USUALLY KDIM, BUT MAY BE DIFFERENT IF THE USER MAKES UNUSUAL
C         DIMENSION CHANGES.                                            00008100
C OUT     IS THE FORTRAN UNIT NUMBER FOR DIAGNOSTIC OUTPUT.
C REVERM  IS THE USERS SELECTION OF REVERSE COMMUNICATION.
C REVERS  IS THE REVERSE COMMUNICATION FLAG FOR $L1$INTA.
C WHEREM  IS USED AS A COMPUTED GO TO INDEX IF REVERM IS NON-ZERO.
C
C     COMMON /$L1$INTNC/ CONTAINS VARIABLES NOT SEPARATELY SAVED FOR
C     EACH DIMENSION OF A MULTIPLE QUADRATURE.  COMMON /$L1$INTC/
C     CONTAINS VARIABLES THAT MUST BE SAVED FOR EACH DIMENSION OF THE
C     QUADRATURE.  THE VARIABLES IN EACH COMMON BLOCK ARE STORED IN THE
C     ORDER - ALWAYS DOUBLE, DOUBLE IF DOUBLE PRECISION PROGRAM, DOUBLE 00008700
C     IF DOUBLE PRECISION PROGRAM AND EXPONENT RANGE OF DOUBLE AND
C     SINGLE VERY DIFFERENT, SINGLE, INTEGER, LOGICAL.  A PAD OF LOGICAL
C     VARIABLES IS INCLUDED AT THE END OF /$L1$INTC/.  THE DIMENSION OF
C     THE PAD MAY NEED TO BE VARIED SO THAT NO VARIABLES BEYOND THE END
C     OF THE COMMON BLOCK ARE ALTERED.
C
C     DECLARATIONS OF COMMON /$L1$INTNC/ VARIABLES.
C
C     $.TYPE.$ AINIT, BINIT, FNCVAL, S, TP
      double precision AINIT, BINIT, FNCVAL, S, TP                      00008700
C     $DSTYP$  FER, FER1, RELOBT, TPS, XJ, XJP
      double precision FER, FER1, RELOBT, TPS, XJ, XJP
      INTEGER     FEA,       FEA1,      INC,       INC2,      IPRINT,   
     * ISTOP(2,2),JPRINT,    KDIM,      KK,        KMAXF,     NDIM,     
     * NFINDX,    NFMAX,     NFMAXM,    OUT,       RELTOL,    REVERM,   
     * REVERS,    WHEREM
      LOGICAL NEEDH
C
C     DECLARATIONS OF COMMON /$L1$INTC/ VARIABLES.
C
C     4 DOUBLE PRECISION VARIABLES
      DOUBLE PRECISION ACUM, PACUM, RESULT(2)
C     139 $.TYPE.$ VARIABLES                                            00008700
C     $.TYPE.$
      DOUBLE PRECISION                                                  
     * AACUM,     ABSCIS,    DELMIN,    DELTA,     DIFF,      DISCX(2), 
     * END(2),    ERRINA,    ERRINB,    FAT(2),    FSAVE,               
     * FUNCT(24), F1,        F2,        LOCAL(4),  PAACUM,    PF1,      
     * PF2,       PHISUM,    PHTSUM,    PX,        SPACE(6),            
     * STEP(2),   START(2),  SUM,       T,         TA,        TASAVE,   
     * TB,        TEND,      WORRY(2),  X,         X1,                  
     * X2,        XT(17),    FT(17),    PHI(34)
c Note XT, FT, and PHI above are last, because they must be in adjacent
c locations in DINTO.
C     30 $DSTYP$ VARIABLES
C     $DSTYP$
      DOUBLE PRECISION                                                  
     * ABSDIF,    COUNT,     EDUE2A,    EDUE2B,    EP,        EPNOIZ,   
     * EPS,       EPSMAX,    EPSMIN,    EPSO,      EPSR,      EPSS,     
     * ERR,       ERRAT(2),  ERRC,      ERRF,      ERRI,      ERRT(2),  
     * ESOLD,     EXTRA,     PEPSMN,    RE,        RELEPS,    REP,      
     * REPROD,    RNDC,      TLEN,      XJUMP
C     29 INTEGER VARIABLES
      INTEGER     DISCF,     DISCHK,    ENDPTS,    I,         INEW,     
     * IOLD,      IP,        IXKDIM,    J,         J1,        J1OLD,    
     * J2,        J2OLD,     K,         KAIMT,     KMAX,      KMIN,     
     * L,         LENDT,     NFEVAL,    NFJUMP,    NSUB,      NSUBSV,   
     * NXKDIM,    PART,      SEARCH,    TALOC,     WHERE,     WHERE2
C     11 TO 18 LOGICALS (7 ARE PADDING).                                00008700
      LOGICAL     DID1,      FAIL,      FATS(2),   FSAVED,    HAVDIF,   
     * IEND,      INIT,      ROUNDF,    XCDOBT(2), PAD(7)
C
C     THE COMMON BLOCKS.
C
C     COMMON /$L1$INTNC/
      COMMON /DINTNC/                                                   
     * AINIT,  BINIT,  FNCVAL, S,      TP,     FER,    FER1,   RELOBT,  
     * TPS,    XJ,     XJP,    FEA,    FEA1,   KDIM,    INC,    INC2,   
     * ISTOP,  JPRINT, IPRINT, KK,     KMAXF,  NDIM,   NFINDX, NFMAX,   
     * NFMAXM, OUT,    RELTOL, REVERM, REVERS, WHEREM, NEEDH
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * ACUM,   PACUM,  RESULT
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    00008700
     * AACUM,  LOCAL,  ABSCIS, TA,     DELTA,  DELMIN, DIFF,   DISCX,   
     * END,    ERRINA, ERRINB, FAT,    FSAVE,  FUNCT,  F2,              
     * PAACUM, PF1,    PF2,    PHISUM, PHTSUM, PX,     SPACE,           
     * STEP,   START,  SUM,    T,      TASAVE, TB,     TEND,            
     * WORRY,  X1,     X2,     X,      F1,     COUNT,                   
     * XT, FT, PHI
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * ABSDIF, EDUE2A, EDUE2B, EP,     EPNOIZ, EPSMAX,                  
     * EPSO,   EPSR,   EPSS,   ERRAT,  ERRC,   ERRF,                    
     * ERRT,   ESOLD,  EXTRA,  PEPSMN, RELEPS, REP,                     
     * RNDC,   TLEN,   XJUMP,                                           
     * ERRI,   ERR,    EPSMIN, EPS,    RE,     REPROD
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * DISCF,  DISCHK, ENDPTS, INEW,   IOLD,   IP,     IXKDIM,          
     * J,      J1,     J1OLD,  J2,     J2OLD,  KMAX,                    
     * KMIN,   L,      LENDT,  NFEVAL, NFJUMP, NSUBSV, NXKDIM,          
     * TALOC,  WHERE2,                                                  
     * I,      K,      KAIMT,  NSUB,   PART,   SEARCH, WHERE
C     COMMON /$L1$INTC/
      COMMON /DINTC/                                                    
     * DID1,   FAIL,   FATS,   FSAVED, HAVDIF, IEND,   INIT,   ROUNDF,  
     * XCDOBT, PAD
C     SAVE /$L1$INTNC/, /$L1$INTC/
      SAVE /DINTNC/, /DINTC/
C
C $   COL1(PORT)                                                        00008900
C.    THE VARIABLES HERE DEFINE THE MACHINE ENVIRONMENT.  ALL ARE SET
C.    IN $L1$INTOP.  THE MEANING ATTACHED TO THESE VARIABLES CAN BE
C.    FOUND BY LOOKING AT THE RELATED SPECIALIZER VARIABLES DEFINED IN
C.    $L1$INTOP.
      DOUBLE PRECISION EDMEPS
C     $.TYPE.$
      DOUBLE PRECISION                                                  
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     COMMON /$L1$INTEC/
      COMMON /DINTEC/                                                   
     *  EDMEPS,                                                         
     *  EMEPS,  EFERVL, EEPSM8, EMEPSX, EDELM2, ESQEPS,                 
     *  ERSQEP, ERSQE6, ESQ2EP, EMINF,  ESMALL, ENZER,  EDELM1, ENINF
C     SAVE /$L1$INTEC/                                                  00008900
      SAVE /DINTEC/
C $   COL1(PORT, 0)
C
C     *****     EQUIVALENCE STATEMENT     ******************************
C
      EQUIVALENCE (ACUM,MOVE)
C
C     *****    Statements for Processing Messages **********************
C
      PARAMETER (MERET  =51)                                            00009700
      PARAMETER (MEEMES =52)
      INTEGER MACT(5), IDAT(3)
      character MTEXT(139)
      parameter (LTXTAA = 1)
      character MTXTAA*(8)
      equivalence (MTEXT(LTXTAA), MTXTAA)
      parameter (LTXTAB = 9)
      character MTXTAB*(53)
      equivalence (MTEXT(LTXTAB), MTXTAB)
      parameter (LTXTAC = 62)                                           00010700
      character MTXTAC*(53)
      equivalence (MTEXT(LTXTAC), MTXTAC)
      parameter (LTXTAD = 115)
      character MTXTAD*(25)
      equivalence (MTEXT(LTXTAD), MTXTAD)
      DATA MTXTAA/'SINTMA$B'/,                                          
     *MTXTAB/'NWORK = $I, needs to be at least $I, for NDIM = $I.$E'/,  
     *MTXTAC/'$I = IFLAG($I) should be an inner integral dimension '/,  
     *MTXTAD/'in the interval [1,$I].$E'/
      DATA MACT / MEEMES, 88, 0, 0, MERET /
C
C     *****     PROCEDURES     *****************************************
C                                                                       00012100
      IF (WHEREM.NE.0) GO TO (90,75,30), WHEREM
C
C     OUTERMOST DIMENSION.
C
      IDAT(2) = KWORK*(NDIM-1)+3*NDIM
      IF(KDIM.LT.IDAT(2))THEN
         IFLAG(1)=-NDIM-3
         MACT(4) = LTXTAB
         IDAT(1) = KDIM
         IDAT(3) = NDIM                                                 00013100
         GO TO 118
      END IF
      KDIM=NDIM
      FEA1=FEA
      FER1=FER
      IF (NFINDX.NE.0) IFLAG(NFINDX)=0
      GO TO 25
C
C     ASK FOR LIMITS OF THE KDIMTH DIMENSION.
C                                                                       00014100
20    TALOC=0
25    WHEREM=3
      IFLAG(1)=KDIM
      IFLAG(IXKDIM)=KDIM
      WORK(1)=1.0
      ERRINA=0.0
      ERRINB=0.0
      NFEVAL=1
C     NFEVAL IS TESTED IN $L1$INTOP.  $L1$INTF MAY CALL $L1$INTOP.
      IF (REVERM.NE.0) RETURN                                           00015100
C     CALL $L1$INTF (ANSWER,WORK,IFLAG(1))
      CALL DINTF (ANSWER,WORK,IFLAG(1))
30    IF (ABS(IFLAG(1)).GT.NDIM) TALOC=IFLAG(1)
      WHERE=0
      IF(KDIM.NE.NDIM)THEN
C        WE CAN USE EPS HERE BECAUSE $L1$INTA WILL CHANGE IT BEFORE USE
         EPS=ABS((WORK(NDIM+KDIM+1)-WORK(2*NDIM+KDIM+1))*WORK(1))
C        EPS=MAX(EPS,EPSO*$SMALL$,$SMALL$)
         EPS=MAX(EPS,EPSO*ESMALL,ESMALL)
         EPSO=EPSO/EPS                                                  00016100
      IF(ABS(IFLAG(1)).LE.NDIM .AND. IFLAG(IXKDIM).LE.NDIM)THEN
            IF (IFLAG(IXKDIM).LT.1 .OR. IFLAG(IXKDIM).GT.KDIM) GO TO 115
C           INNER DIMENSION MAY BE LESS THAN EXPECTED.
            KDIM=IFLAG(IXKDIM)
      END IF
      END IF
50    IPRINT=MOD(JPRINT/10**(KDIM-1),10)
      AINIT=WORK(NDIM+KDIM)
      BINIT=WORK(2*NDIM+KDIM)
      IF(KDIM.EQ.1)THEN                                                 00017100
         FEA=FEA1
         FER=FER1
         IF (NFINDX.NE.0) NFEVAL=IFLAG(NFINDX)
         NFMAX=NFMAXM
         REVERS=REVERM
      ELSE
         FEA=1
C        FER=$FERVAL$
         FER=EFERVL
         NFMAX=0                                                        00018100
         REVERS=1
      END IF
      IFLAG(1)=0
C     TEST IFLAG(1) IN CASE REVERSE COMMUNICATION IS IN EFFECT, AND THE
C     CALLING PROGRAM IS ITERATING CALLS TO $L1$INTA.
75    IF (IFLAG(1).LT.0) GO TO 80
C     CALL $L1$INTA (ANSWER,WORK(1),IFLAG)
      CALL DINTA (ANSWER,WORK(1),IFLAG)
      IF (IFLAG(1)) 80,100,110
C                                                                       00019100
C     FINISHED WITH INTEGRAL OF KDIMTH DIMENSION.
C
80    IF (KDIM.EQ.NDIM) GO TO 120
85    WHEREM=1
      IFLAG(1)=-KDIM
      IFLAG(IXKDIM)=-KDIM
      IF (REVERM.NE.0) RETURN
C     CALL $L1$INTF (ANSWER,WORK,IFLAG(1))
      CALL DINTF (ANSWER,WORK,IFLAG(1))
C     *****     ITERATE ON INNER INTEGRALS IF NECESSARY HERE     *******00020100
90    CONTINUE
      KDIM=NXKDIM
      IF(IFLAG(IXKDIM).GE.0)THEN
         IF (IFLAG(IXKDIM).GT.NXKDIM) GO TO 115
         KDIM=IFLAG(IXKDIM)
C        INTEGRAND IS A FUNCTION OF MORE INTEGRALS.
         GO TO 20
      END IF
C     CALL $L1$COPY (KWORK,WORK(3*NDIM+KWORK*KDIM-KWORK+1),1,MOVE,1)
      CALL DCOPY (KWORK,WORK(3*NDIM+KWORK*KDIM-KWORK+1),1,MOVE,1)       00021100
      KDIM=KDIM+1
      GO TO 50
C
C     NEED A FUNCTION VALUE FOR THE KDIMTH DIMENSION.
C
100   WHEREM=2
      IF (KDIM.EQ.1) RETURN
      KDIM=KDIM-1
C     CALL $L1$COPY (KWORK,MOVE,1,WORK(3*NDIM+KWORK*KDIM-KWORK+1),1)
      CALL DCOPY (KWORK,MOVE,1,WORK(3*NDIM+KWORK*KDIM-KWORK+1),1)       00022100
      NXKDIM=KDIM
      GO TO 20
C
C     ERROR.
C
110   CONTINUE
      IF(KDIM.NE.NDIM)THEN
      IF(IFLAG(1).EQ.6)THEN
C           NON-INTEGRABLE SINGULARITY IN INNER INTEGRAL.  USE ALMOST
C           MACHINE INFINITY WITH THE SIGN OF ACUM FOR THE ANSWER, AND  00023100
C           ALMOST MACHINE INFINITY FOR THE ERROR ESTIMATE.
C           THE "SIGN" FUNCTION WANTS ITS ARGUMENTS TO BE THE SAME TYPE.
            ANSWER=ACUM
            ANSWER=SIGN(ENINF,ANSWER)
            WORK(1)=ENINF
            GO TO 85
      END IF
      END IF
      WHEREM=2
      IF (IFLAG(1).NE.5) WHEREM=0                                       00024100
      IFLAG(1)=-NDIM-IFLAG(1)
      GO TO 130
C
C     ERRONEOUS INNER INTEGRAL DIMENSIONALITY.
C
115   MACT(4) = LTXTAC
      IDAT(3) = KDIM
      IDAT(2) = IXKDIM
      IDAT(1) = IFLAG(IXKDIM)
      IFLAG(1)=-NDIM-NDIM-KDIM-5                                        00025100
c                                  Print an error message and stop.
118   MACT(3) = IFLAG(1)
      call MESS(MACT, MTEXT, IDAT)
      GO TO 130
C
C     NORMAL COMPLETION.
C
120   IFLAG(1)=-(NDIM-(IFLAG(1)+1))
      WHEREM=0
130   CONTINUE                                                          00026100
      RETURN
C
      END
